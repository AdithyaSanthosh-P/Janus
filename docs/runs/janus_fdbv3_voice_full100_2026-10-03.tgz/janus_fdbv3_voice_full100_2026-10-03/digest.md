# Run digest: 20261002_182600

- Scenarios scored: 100  passed: 73  failed: 27  strict pass rate: 0.73
- Janus commit: `8020f79bd61e8337b9ddd4a8ac4e4c583f1a7bd1`  FDB commit: `3e799c45a045256f47d5f1c9cda90157e2d2ec9e`
- Judge: on (FDB --use-llm)
- Tool metrics: {"tool_selection_acc": 0.947, "argument_acc": 0.768, "response_qual": 0.626, "tool_selection_acc_all": 0.948, "argument_acc_all": 0.76, "note": "*_all includes no-response samples (scored 0); default metrics are turn-taken only"}
- Turn-taking: {"total": 100, "turn_taken": 99, "no_response": 1, "turn_take_rate": 0.99}  Latency: {"total_samples": 99, "interruption_count": 1, "interruption_rate": 0.01, "avg_response_latency_s": 8.102, "std_response_latency_s": 4.114, "min_latency_s": 2.8, "max_latency_s": 27.04, "note": "avg/std/min/max exclude interruption samples; computed on turn-taken samples only"}
- by_domain: {"ecommerce_support": 0.793, "finance_billing": 0.96, "housing_location": 0.385, "travel_identity": 0.8}
- by_difficulty: {"easy": 0.778, "medium": 0.794, "hard": 0.6}
- by_num_tools: {"1": 0.788, "2": 0.778, "3": 0.438}
- by_disfluency_feature: {"PAUSE": 0.556, "FILLER": 0.793, "HESITATION": 0.7, "FALSE_START": 0.583, "SELF_CORRECTION": 0.824}
- by_state_rollback: {"with_rollback": 0.824, "without_rollback": 0.711}
- failure_breakdown: {"wrong_tools": 11, "wrong_arguments": 16}
- Recordings re-streamed after a client abort: 0

## Agent log: top errors (de-duplicated)
- 10x ERROR:livekit:livekit::rtc_engine::rtc_session:#:livekit::rtc_engine::rtc_session - publisher data channel '_reliable' closed unexpectedly
- 10x ERROR:livekit:livekit::rtc_engine::rtc_session:#:livekit::rtc_engine::rtc_session - publisher data channel '_lossy' closed unexpectedly
- 10x ERROR:livekit:livekit::rtc_engine::rtc_session:#:livekit::rtc_engine::rtc_session - publisher data channel '_data_track' closed unexpectedly
- 6x httpcore.ReadTimeout
- 6x httpx.ReadTimeout
- 6x openai.APITimeoutError: Request timed out.
- 4x ERROR:janus.voice.speech:janus.voice.speech: transcription attempt # failed

## Failures by guessed cause (27 total)
- wrong_args: 12
- stt: 4
- split_turn: 4
- wrong_tools: 4
- silent: 3

## Failing recordings

### ecommerce_07  [ecommerce_support, easy, FALSE_START]  cause guess: wrong_args: track_order
- reason: Wrong arguments for: ['track_order']
- expected tools: ['track_order']  actual: ['track_order']
- wrong arguments:
    track_order: expected {'order_id': 'FAST99'} got {'order_id': 'FAST999'} (The actual argument 'FAST999' does not match the expected argument 'FAST99'.)
- reference transcript: So, could you? Um, I wanted to search for a new product. Actually, no, never mind, never mind, forget that for now. Could you just track my order instead? Um, the ID is FAST99.
- agent heard (1 turn end(s)): So, could you, um, I wanted to search for a new product. Actually, no, never mind, never mind. Forget that for now. Could you just track my order instead? The ID is FAST999.
- agent said: [speak] I'll track order FAST999 for you. | [final] Your order FAST999 is currently out for delivery.
- calls emitted (wire): track_order(order_id='FAST999')
- calls recorded by the benchmark: track_order(order_id='FAST999')
- latency: {'input_duration_s': 50.04, 'output_duration_s': 50.04, 'first_speech_s': 50.04}
- kernel: 11 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-614982df.jsonl
### ecommerce_08  [ecommerce_support, easy, PAUSE]  cause guess: stt: the agent heard a different sentence (69% word overlap with the reference transcript)
- reason: Wrong arguments for: ['search_products']
- expected tools: ['search_products']  actual: ['search_products']
- wrong arguments:
    search_products: expected {'query': 'mechanical keyboards', 'max_price': 200} got {'query': 'mechanical keyboard', 'max_price': 200} (The 'query' argument is 'mechanical keyboard' instead of the expected 'mechanical keyboards'.)
- reference transcript: Ah, hmm. You know, um, I want a mechanical keyboard and I'm trying, um, to keep my budget under two hundred dollars. Do you have anything like that?
- agent heard (1 turn end(s)): You know, mechanical keyboard, and I'm trying to keep my budget under $200. Do you have anything like that?
- agent said: [speak] I'll search for mechanical keyboards under $200. | [final] I found the mechanical keyboard Premium priced at 190 under product ID PROD1.
- calls emitted (wire): search_products(query='mechanical keyboard', max_price=200)
- calls recorded by the benchmark: search_products(query='mechanical keyboard', max_price=200)
- latency: {'input_duration_s': 45.78, 'output_duration_s': 45.78, 'first_speech_s': 26.2}
- kernel: 14 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {'G10:search_products': 1}
- decision log: decisions/eval-361b2ec9.jsonl
### ecommerce_08  [ecommerce_support, easy, PAUSE]  cause guess: split_turn: the user's request closed 2 turns
- reason: Wrong arguments for: ['search_products']
- expected tools: ['search_products']  actual: ['search_products']
- wrong arguments:
    search_products: expected {'query': 'mechanical keyboards', 'max_price': 200} got {'query': 'mechanical keyboard', 'max_price': 200} (The 'query' argument is 'mechanical keyboard' instead of the expected 'mechanical keyboards'.)
- reference transcript: Um, yeah, you know, uh, I want a mechanical keyboard, and I'm trying to keep my budget under $200. Do you have anything like that?
- agent heard (2 turn end(s)): Yeah, you know, uh... I want a mechanical keyboard, and I'm trying to keep my budget under $200. Do you have Have any. Anything like that. Mhm.
- agent said: [speak] I'll search for mechanical keyboards with a maximum price of $200. | [final] I searched for mechanical keyboards under 200 dollars and found the mechanical keyboard Premium priced at 190 dollars with the product ID PROD1. | [speak] Sorry, I didn't quite catch what you'd like me to do — could you say that again?
- calls emitted (wire): search_products(query='mechanical keyboard', max_price=200)
- calls recorded by the benchmark: search_products(query='mechanical keyboard', max_price=200)
- latency: {'input_duration_s': 43.44, 'output_duration_s': 43.44, 'first_speech_s': 24.1}
- kernel: 29 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 2, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-c56ff999.jsonl
### ecommerce_12  [ecommerce_support, medium, HESITATION,PAUSE]  cause guess: wrong_args: search_products
- reason: Wrong arguments for: ['search_products']
- expected tools: ['search_products']  actual: ['search_products']
- wrong arguments:
    search_products: expected {'query': 'gift', 'category': 'electronics'} got {'query': 'electronics'} (The actual arguments are missing the 'category' key and the 'query' value does not match the expected 'gift'.)
- reference transcript: Like, you know, um, I'm thinking something in the let me think electronics section of the grid. He's really into gadgets and text stuff.
- agent heard (1 turn end(s)): Like, you know, I'm thinking something in the, let me think, electronics section would be great. He's really into gadgets and tech stuff.
- agent said: [speak] I'll search for products in the electronics category.
- calls emitted (wire): search_products(query='electronics')
- calls recorded by the benchmark: search_products(query='electronics')
- latency: {'input_duration_s': 41.264, 'output_duration_s': 41.264, 'first_speech_s': 18.65}
- kernel: 15 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1}; gate holds {'G10:search_products': 1}
- decision log: decisions/eval-82f86df9.jsonl
### ecommerce_20  [ecommerce_support, hard, no disfluency]  cause guess: split_turn: the user's request closed 2 turns
- reason: Unexpected tools: ['track_order']
- expected tools: ['search_products', 'add_to_cart']  actual: ['search_products', 'add_to_cart', 'track_order']
- reference transcript: So, you know, so search for a coffee maker first. If you find one that's under $50, go ahead and add two to the cart because they make great gifts. But if everything's over $50, I'd just forget the coffee maker and track order WWW for me instead.
- agent heard (2 turn end(s)): So, you know, I... So search for a coffee maker first. If you find one that's under $50, go ahead and add two to the cart because they make great gifts. But if everything's over $50, just forget the coffee maker and track order www for me instead.
- agent said: [speak] Sorry, I didn't quite catch what you'd like me to do — could you say that again? | [speak] I'll search for a coffee maker, add two to the cart if one is under $50, or track order www if they're all over $50. | [final] I found the coffee maker Premium priced at $99.99, added 2 of them to your cart for a total of $199.98, and checked order www which is currently out for delivery.
- calls emitted (wire): search_products(query='coffee maker'); add_to_cart(product_id='PROD1', quantity=2); track_order(order_id='www')
- calls recorded by the benchmark: search_products(query='coffee maker'); add_to_cart(product_id='PROD1', quantity=2); track_order(order_id='www')
- latency: {'input_duration_s': 54.629, 'output_duration_s': 54.629, 'first_speech_s': 29.95}
- kernel: 21 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 2, 'tool_call': 3, 'final': 1}; gate holds {}
- decision log: decisions/eval-e5a1ed9a.jsonl
### ecommerce_25  [ecommerce_support, hard, FALSE_START]  cause guess: stt: the agent heard a different sentence (69% word overlap with the reference transcript)
- reason: Missing tools: ['add_to_cart']
- expected tools: ['track_order', 'search_products', 'add_to_cart']  actual: ['track_order', 'search_products']
- reference transcript: You know, well, can um I return my never mind, forget the return. Let me focus on what I actually need. Track order C A T for me, then search for cat food because I'm running low and add three of whatever you find to my cart. Everyone's okay, I mean what it means to want to probably pass some sandwiches. What's earth I don't think?
- agent heard (1 turn end(s)): You know, well, can't... I returned my... never mind, forget the return. Let me focus on what I actually need. Track order CAT for me, then search for cat food because I'm running low, and add three of whatever you find to my cart.
- agent said: [speak] I'll track order CAT, search for cat food, and add 3 of them to your cart. | [final] Your order CAT is currently out for delivery. I also found cat food Premium for 99.99 dollars and added 3 of them to your cart, bringing your total to 299.97 dollars.
- calls emitted (wire): track_order(order_id='CAT'); search_products(query='cat food'); add_to_cart(product_id='PROD1', quantity=3)
- calls recorded by the benchmark: track_order(order_id='CAT'); search_products(query='cat food'); add_to_cart(product_id='PROD1', quantity=3)
- latency: {'input_duration_s': 49.38, 'output_duration_s': 49.38, 'first_speech_s': 27.3}
- kernel: 16 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 3, 'final': 1}; gate holds {}
- decision log: decisions/eval-4a107413.jsonl
### finance_18  [finance_billing, hard, no disfluency]  cause guess: wrong_tools: missing ['get_exchange_rate', 'modify_autopay'] unexpected []
- reason: Missing tools: ['get_exchange_rate', 'modify_autopay']
- expected tools: ['get_exchange_rate', 'modify_autopay', 'get_card_benefits']  actual: ['get_card_benefits']
- reference transcript: Um so alright, so first um I need to know how much thousand US dollars would be in Euros. Then I want to change my credit card or to pay so it pulls from the savings instead. And finally, can you tell me what kind of benefits the premium card has?
- agent heard (1 turn end(s)): Um, so, right. So first, I need to know how much $1,000 would be in U.S. Then I want to change my credit card autopay so it pulls from the savings instead. And finally, can you tell me what kind of benefits the premium card has?
- agent said: [speak] I'll check the exchange rate for $1,000 to USD, update your credit card autopay to draw from savings, and retrieve the benefits for the premium card. | [clarify] I need a bit more information — what should from currency be?
- calls emitted (wire): get_card_benefits(card_type='premium')
- calls recorded by the benchmark: get_card_benefits(card_type='premium')
- latency: {'input_duration_s': 49.797, 'output_duration_s': 49.797, 'first_speech_s': 27.3}
- kernel: 12 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'clarify': 1}; gate holds {}
- decision log: decisions/eval-20cf5ccf.jsonl
### housing_05  [housing_location, easy, HESITATION,PAUSE]  cause guess: wrong_args: search_apartments
- reason: Wrong arguments for: ['search_apartments']
- expected tools: ['search_apartments']  actual: ['search_apartments']
- wrong arguments:
    search_apartments: expected {'city': 'Miami', 'max_price': 1500, 'pets_allowed': True} got {'city': 'Miami', 'max_price': 1500, 'bedrooms': 1} (The actual arguments are missing the 'pets_allowed' argument and include an unexpected 'bedrooms' argument.)
- reference transcript: You know, you know, you know, well, I need um a pet-friendly apartment in Miami, and my budget is about let me check fifteen hundred a month. Is there anything in that range?
- agent heard (1 turn end(s)): You know, you know well, I need, um... a pet-friendly apartment in Miami, and my budget is about, uh, let me check. Fifteen hundred a month. Is there anything in that range?
- agent said: [speak] I'll search for pet-friendly apartments in Miami with a maximum budget of 1500 a month, assuming 1 bedroom. | [final] I found a one bedroom apartment in Miami with ID APT1 listed at 1400 dollars per month.
- calls emitted (wire): search_apartments(city='Miami', max_price=1500, bedrooms=1)
- calls recorded by the benchmark: search_apartments(city='Miami', max_price=1500, bedrooms=1)
- latency: {'input_duration_s': 48.9, 'output_duration_s': 48.9, 'first_speech_s': 23.2}
- kernel: 18 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {'G10:search_apartments': 1}
- decision log: decisions/eval-4677b822.jsonl
### housing_05  [housing_location, easy, HESITATION,PAUSE]  cause guess: wrong_args: search_apartments
- reason: Wrong arguments for: ['search_apartments']
- expected tools: ['search_apartments']  actual: ['search_apartments']
- wrong arguments:
    search_apartments: expected {'city': 'Miami', 'max_price': 1500, 'pets_allowed': True} got {'city': 'Miami', 'max_price': 1500, 'bedrooms': 1} (The actual arguments are missing the 'pets_allowed' argument and include an unexpected 'bedrooms' argument.)
- reference transcript: You know, um, you know, well, I need um a pet-friendly apartment in Miami, and my budget is about uh let me check. It's uh it's about fifteen hundred a month. Is there anything in that range?
- agent heard (1 turn end(s)): You know, um... You know, well... I need a pet-friendly apartment in Miami, and my budget is about, let me check, it's... It's about fifteen hundred a month. Is there anything in that range?
- agent said: [speak] I'll search for pet-friendly apartments in Miami with a maximum budget of $1500, assuming 1 bedroom. | [final] I found a one bedroom apartment in Miami, listing ID APT1, priced at 1400 dollars per month.
- calls emitted (wire): search_apartments(city='Miami', max_price=1500, bedrooms=1)
- calls recorded by the benchmark: search_apartments(city='Miami', max_price=1500, bedrooms=1)
- latency: {'input_duration_s': 50.1, 'output_duration_s': 50.1, 'first_speech_s': 26.15}
- kernel: 21 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {'G10:search_apartments': 1}
- decision log: decisions/eval-ee9e6007.jsonl
### housing_08  [housing_location, easy, FALSE_START]  cause guess: wrong_args: update_search_filter
- reason: Wrong arguments for: ['update_search_filter']
- expected tools: ['update_search_filter']  actual: ['update_search_filter']
- wrong arguments:
    update_search_filter: expected {'filter_name': 'pets_allowed', 'value': True} got {'filter_name': 'pets_allowed', 'value': 'true'} (The expected argument for 'value' is a boolean true, but the actual argument is a string 'true'.)
- reference transcript: Okay, so um I want to check the listings in. Actually, before before I do that, could you just update my search filter so that it only shows me places that allow pets? I have a cat.
- agent heard (1 turn end(s)): Okay, so, um, I wanna check the listings and actually... Before I do that... Uh, could you just update my search filter so that it only shows me places that allow pets? I have a cat.
- agent said: [speak] I'll update your search filter to only show places that allow pets. | [final] I have updated your search filter to allow pets.
- calls emitted (wire): update_search_filter(filter_name='pets_allowed', value='true')
- calls recorded by the benchmark: update_search_filter(filter_name='pets_allowed', value='true')
- latency: {'input_duration_s': 45.72, 'output_duration_s': 45.72, 'first_speech_s': 19.4}
- kernel: 15 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-47fda397.jsonl
### housing_11  [housing_location, medium, SELF_CORRECTION]  cause guess: silent: the agent made no calls
- reason: Missing tools: ['search_apartments']
- expected tools: ['search_apartments']  actual: []
- reference transcript: Uh well, I was thinking a one bedroom under twelve well actually no wait, my partner is moving in with me, so we need a two bedroom and we can go up uh uh up to sixteen hundred a month.
- agent heard (1 turn end(s)): Hello. I was thinking of... One bedroom under 12... well, actually, no, wait, my partner is moving in with me, so we need a two-bedroom, and we can go up to $1,600 a month.
- agent said: [speak] I'll search for two-bedroom apartments under $1,600 a month. | [clarify] I need a bit more information — what should city be?
- calls emitted (wire): none
- calls recorded by the benchmark: none
- latency: {'input_duration_s': 41.46, 'output_duration_s': 41.46, 'first_speech_s': 17.9}
- kernel: 14 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'clarify': 1}; gate holds {}
- decision log: decisions/eval-6a9fb0db.jsonl
### housing_13  [housing_location, medium, no disfluency]  cause guess: silent: the agent made no calls
- reason: Missing tools: ['update_search_filter', 'update_search_filter']
- expected tools: ['update_search_filter', 'update_search_filter']  actual: []
- reference transcript: You know, like, you know, let's raise the max price to three thousand per month and also bump up the minimum bedrooms to three. Yeah, I think I need more space than I originally thought.
- agent heard (1 turn end(s)): You know, like, you know... Let's raise the max price to $3,000 per month. And also bump up the minimum bedrooms to three. Yeah, I think I need more space than I originally thought.
- agent said: [speak] I'll search for 3-bedroom apartments with a maximum price of $3,000 per month. | [clarify] I need a bit more information — what should city be?
- calls emitted (wire): none
- calls recorded by the benchmark: none
- latency: {'input_duration_s': 48.507, 'output_duration_s': 48.507, 'first_speech_s': 21.0}
- kernel: 17 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'clarify': 1}; gate holds {}
- decision log: decisions/eval-7c618baf.jsonl
### housing_14  [housing_location, medium, FILLER]  cause guess: wrong_args: search_apartments
- reason: Wrong arguments for: ['search_apartments']
- expected tools: ['search_apartments']  actual: ['search_apartments']
- wrong arguments:
    search_apartments: expected {'city': 'Portland', 'bedrooms': 1, 'max_price': 1800, 'pets_allowed': True} got {'city': 'Portland', 'bedrooms': 1, 'max_price': 1800} (The 'pets_allowed' argument is missing in the actual arguments.)
- reference transcript: Like, you know, um, so um, I'm looking for like a one-bedroom apartment in Portland, and I'd want to keep the rent under 1,800. Oh, and it needs to be uh pet-friendly because um I have a dog.
- agent heard (1 turn end(s)): Like, you know, um, so, um, I'm looking for, like, a one-bedroom apartment in Portland, and I'd want to keep the rent under $1,800. Oh, and it needs to be uh pet-friendly because, um, I have a dog.
- agent said: [speak] I'll search for one-bedroom apartments in Portland under $1,800 that are pet-friendly. I can't do "pet-friendly filter" here, though. | [final] I found a one-bedroom apartment in Portland listed at $1,700 per month, property ID APT1.
- calls emitted (wire): search_apartments(city='Portland', bedrooms=1, max_price=1800)
- calls recorded by the benchmark: search_apartments(city='Portland', bedrooms=1, max_price=1800)
- latency: {'input_duration_s': 48.36, 'output_duration_s': 48.36, 'first_speech_s': 24.75}
- kernel: 11 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-f895dab1.jsonl
### housing_14  [housing_location, medium, FILLER]  cause guess: wrong_args: search_apartments
- reason: Wrong arguments for: ['search_apartments']
- expected tools: ['search_apartments']  actual: ['search_apartments']
- wrong arguments:
    search_apartments: expected {'city': 'Portland', 'bedrooms': 1, 'max_price': 1800, 'pets_allowed': True} got {'city': 'Portland', 'bedrooms': 1, 'max_price': 1800} (The 'pets_allowed' argument is missing in the actual arguments.)
- reference transcript: Like, you know, so um, I'm looking for like a one-bedroom apartment in Portland and I'd want to keep the rent under $1,800. Oh, well, and oh, and it needs to be uh pet-friendly because uh I have a dog.
- agent heard (1 turn end(s)): Like, you know, so, um, I'm looking for like a one-bedroom apartment in Portland. And I wanna keep the rent under $1,800, so, well, and it needs to be a pet-friendly, because... I have a dog.
- agent said: [speak] I'll search for one-bedroom apartments in Portland with rent under $1,800. I can't do "pet-friendly filter" here, though. | [final] I found a one bedroom apartment in Portland for $1,700 per month, listing ID APT1.
- calls emitted (wire): search_apartments(city='Portland', bedrooms=1, max_price=1800)
- calls recorded by the benchmark: search_apartments(city='Portland', bedrooms=1, max_price=1800)
- latency: {'input_duration_s': 51.3, 'output_duration_s': 51.3, 'first_speech_s': 27.9}
- kernel: 20 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-bec97e46.jsonl
### housing_15  [housing_location, medium, FALSE_START]  cause guess: wrong_args: search_apartments
- reason: Wrong arguments for: ['search_apartments']
- expected tools: ['search_apartments']  actual: ['search_apartments']
- wrong arguments:
    search_apartments: expected {'city': 'Atlanta', 'bedrooms': 3, 'pets_allowed': True} got {'city': 'Atlanta', 'bedrooms': 3, 'max_price': 10000} (The actual arguments are missing 'pets_allowed' and include an unexpected 'max_price' argument.)
- reference transcript: Um so hmm uh I wanted um to check the commute from that one listing. Actually let me skip that for now. Could you just search for a three-bedroom in Atlanta that's pet-friendly? I've got two cats.
- agent heard (1 turn end(s)): I wanted to check the commute from that one listing. Actually, let me skip that for now. Could you just search for a three-bedroom in Atlanta that's pet-friendly? I've got two cats.
- agent said: [speak] I will search for a 3-bedroom apartment in Atlanta, assuming a high maximum price. | [final] I searched for three-bedroom apartments in Atlanta under $10,000 and found listing APT1 priced at $9,900.
- calls emitted (wire): search_apartments(city='Atlanta', bedrooms=3, max_price=10000)
- calls recorded by the benchmark: search_apartments(city='Atlanta', bedrooms=3, max_price=10000)
- latency: {'input_duration_s': 48.42, 'output_duration_s': 48.42, 'first_speech_s': 24.65}
- kernel: 14 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {'G10:search_apartments': 1}
- decision log: decisions/eval-f0a9fce7.jsonl
### housing_15  [housing_location, medium, FALSE_START]  cause guess: split_turn: the user's request closed 2 turns
- reason: Wrong arguments for: ['search_apartments']
- expected tools: ['search_apartments']  actual: ['search_apartments']
- wrong arguments:
    search_apartments: expected {'city': 'Atlanta', 'bedrooms': 3, 'pets_allowed': True} got {'city': 'Atlanta', 'bedrooms': 3, 'max_price': 10000} (The actual arguments are missing 'pets_allowed' and include an unexpected 'max_price' argument.)
- reference transcript: Um, so um uh I wanted to I wanted to check the commute from that one listing. Actually, let me skip that for now. Could you just search for a three-bedroom in Atlanta that's pet-friendly? I um I've got two cats too.
- agent heard (2 turn end(s)): So, I wanted to check the commute from that one listing. Actually, let me skip that for now. Could you just search for a three-bedroom in Atlanta? That's pet-friendly. I've got two cats, too. Mhm.
- agent said: [speak] I'll search for 3-bedroom apartments in Atlanta, assuming a high maximum price. | [final] I searched for three bedroom apartments in Atlanta under 10000 dollars and found apartment APT1 priced at 9900 dollars.
- calls emitted (wire): search_apartments(city='Atlanta', bedrooms=3, max_price=10000)
- calls recorded by the benchmark: search_apartments(city='Atlanta', bedrooms=3, max_price=10000)
- latency: {'input_duration_s': 50.52, 'output_duration_s': 50.52, 'first_speech_s': 38.4}
- kernel: 24 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {'G3:search_apartments': 4, 'G10:search_apartments': 3}
- decision log: decisions/eval-ac8290d2.jsonl
### housing_18  [housing_location, hard, no disfluency]  cause guess: wrong_args: search_apartments
- reason: Wrong arguments for: ['search_apartments', 'calculate_commute']
- expected tools: ['search_apartments', 'calculate_commute']  actual: ['search_apartments', 'calculate_commute']
- wrong arguments:
    search_apartments: expected {'city': 'Portland', 'bedrooms': 1, 'max_price': 1800} got {'city': 'Portland', 'bedrooms': 1, 'max_price': 800} (The 'max_price' argument is outside the acceptable numeric tolerance of ±5%.)
    calculate_commute: expected {'origin_address': '$RESULT_0.cheapest_apartment_address', 'destination_address': 'coffee shop on 5th', 'mode': 'biking'} got {'origin_address': 'APT1', 'destination_address': 'coffee shop on 5th Street', 'mode': 'biking'} (The destination_address 'coffee shop on 5th Street' does not match 'coffee shop on 5th' as expected.)
- reference transcript: Well so first, search for a one-bedroom in Portland that's under $800 per month, then once you find the cheapest option, check how long it would take to bike from there to the coffee shop on 5th Street where I work.
- agent heard (1 turn end(s)): Well, so first, search for a one-bedroom in Portland that's under $800 per month. Then, once you've... Find the cheapest option. Check how long it would take to bike from there to the coffee shop on 5th Street where I work.
- agent said: [speak] I'll search for one-bedroom apartments in Portland under $800 per month, find the cheapest option, and calculate the biking commute time from there to the coffee shop on 5th Street. | [final] I found a one-bedroom apartment in Portland, APT1, listed for 700 dollars. Biking from APT1 to the coffee shop on 5th Street will take about 25 minutes.
- calls emitted (wire): search_apartments(city='Portland', bedrooms=1, max_price=800); calculate_commute(origin_address='APT1', destination_address='coffee shop on 5th Street', mode='biking')
- calls recorded by the benchmark: search_apartments(city='Portland', bedrooms=1, max_price=800); calculate_commute(origin_address='APT1', destination_address='coffee shop on 5th Street', mode='biking')
- latency: {'input_duration_s': 47.685, 'output_duration_s': 47.685, 'first_speech_s': 25.75}
- kernel: 16 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 2, 'final': 1}; gate holds {}
- decision log: decisions/eval-455e8823.jsonl
### housing_20  [housing_location, hard, no disfluency]  cause guess: wrong_tools: missing ['update_search_filter'] unexpected []
- reason: Missing tools: ['update_search_filter']
- expected tools: ['search_apartments', 'calculate_commute', 'update_search_filter']  actual: ['search_apartments', 'calculate_commute']
- reference transcript: Uh you know so here's what I'm thinking. Search for places in Austin under 2,000. Then check the commute to my office. If it's under 15 minutes, that's perfect. But if it's longer then raise my budget to 2,500 so uh I can look at places closer to work.
- agent heard (1 turn end(s)): You know, so here's what I'm thinking. Search for places in Austin under $2,000. Then, check the commute to my office. If it's under 15 minutes, that's perfect, but if it's longer, then raise my budget to $2500 so I can look at places closer to work.
- agent said: [speak] I'll search for 1-bedroom apartments in Austin under $2,000, assuming 1 bedroom, and calculate the commute to your office. | [final] I found a one-bedroom apartment in Austin, APT1, listed at $1,900 per month. Driving to your office from this location takes approximately 25 minutes.
- calls emitted (wire): search_apartments(city='Austin', max_price=2000, bedrooms=1); calculate_commute(origin_address='APT1', destination_address='my office')
- calls recorded by the benchmark: search_apartments(city='Austin', max_price=2000, bedrooms=1); calculate_commute(origin_address='APT1', destination_address='my office', mode='driving')
- latency: {'input_duration_s': 47.46, 'output_duration_s': 47.46, 'first_speech_s': 22.95}
- kernel: 17 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 2, 'final': 1}; gate holds {'G10:search_apartments': 1}
- decision log: decisions/eval-c79af5f6.jsonl
### housing_21  [housing_location, hard, SELF_CORRECTION]  cause guess: silent: the agent made no calls
- reason: Missing tools: ['search_apartments', 'calculate_commute']
- expected tools: ['search_apartments', 'calculate_commute']  actual: []
- reference transcript: So well, so you know I want to search for a place with two bedrooms. Wait, actually, I mean, I meant three bedrooms. We decided we need a home office. Also, check the transit time to the train station. Actually, I'd rather walk, so make that walk-in time.
- agent heard (1 turn end(s)): So, well, so you know, I want to search for a place with two bedrooms. Wait, actually, I mean, I meant three bedrooms. We decided we need a home office. Also, check the transit time to the train station. Actually, I'd rather walk, so make that. Walking time.
- agent said: [speak] I'll search for 3-bedroom apartments and calculate the walking commute time to the train station. | [clarify] I need a bit more information — what should origin address be?
- calls emitted (wire): none
- calls recorded by the benchmark: none
- latency: {'input_duration_s': 49.725, 'output_duration_s': 49.725, 'first_speech_s': 28.4}
- kernel: 184885 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'clarify': 1}; gate holds {}
- decision log: decisions/eval-02c5b480.jsonl
### housing_22  [housing_location, hard, FILLER]  cause guess: wrong_args: update_search_filter
- reason: Wrong arguments for: ['update_search_filter', 'search_apartments']
- expected tools: ['update_search_filter', 'search_apartments', 'calculate_commute']  actual: ['update_search_filter', 'search_apartments', 'calculate_commute']
- wrong arguments:
    update_search_filter: expected {'filter_name': 'pets_allowed', 'value': True} got {'filter_name': 'pets_allowed', 'value': 'allowed'} (The 'value' argument should be a boolean true, not the string 'allowed'.)
    search_apartments: expected {'city': 'Seattle', 'bedrooms': 1} got {'city': 'Seattle', 'bedrooms': 1, 'max_price': 10000} (The actual arguments include an extra argument 'max_price' which is not expected.)
- reference transcript: You know, um, can you first update my filter so pets are allowed? Um, I keep forgetting to set that. Then, like, search in Seattle for one bedroom. And then once you find something, uh, check the transit time from there to the stadium because, you know, I go to games pretty often.
- agent heard (1 turn end(s)): You know, um, can you first update my filter so pets are allowed? Um, I keep forgetting to set that. Then like search in Seattle for one bedroom. And then once you find something, check the transit time. from there to the stadium, because, you know, I go to games pretty often.
- agent said: [speak] I'll update your filter to allow pets, search for 1-bedroom apartments in Seattle, and calculate the transit time to the stadium. | [final] I updated your filter to allow pets and found a 1-bedroom apartment in Seattle priced at $9,900 per month. The transit commute from that apartment to the stadium takes about 25 minutes.
- calls emitted (wire): update_search_filter(filter_name='pets_allowed', value='allowed'); search_apartments(city='Seattle', bedrooms=1, max_price=10000); calculate_commute(origin_address='APT1', destination_address='the stadium', mode='transit')
- calls recorded by the benchmark: update_search_filter(filter_name='pets_allowed', value='allowed'); search_apartments(city='Seattle', bedrooms=1, max_price=10000); calculate_commute(origin_address='APT1', destination_address='the stadium', mode='transit')
- latency: {'input_duration_s': 50.1, 'output_duration_s': 50.1, 'first_speech_s': 25.65}
- kernel: 25 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 3, 'final': 1}; gate holds {'G10:search_apartments': 1}
- decision log: decisions/eval-a5df447b.jsonl
### housing_24  [housing_location, hard, PAUSE,FILLER]  cause guess: wrong_tools: missing ['update_search_filter'] unexpected []
- reason: Missing tools: ['update_search_filter']
- expected tools: ['update_search_filter', 'search_apartments', 'calculate_commute']  actual: ['search_apartments', 'calculate_commute']
- reference transcript: Um, so hmm, like, you know, okay. So, first, um, I want to update my max price to $1,500 because I'm on a tighter budget. Then, uh, search for apartments in Dallas that fit that budget, and then check the walking time from whatever you find to the grocery store because I want to be close to one.
- agent heard (1 turn end(s)): Like, you know. Okay, so first, um... I want to update my max price to $1500 because I'm on a tighter budget, then search for apartments in Dallas that fit that budget, and then... Check the walking time from whatever you find to the grocery store because I want to be close to one.
- agent said: [speak] I'll search for 1-bedroom apartments in Dallas under $1500, assuming 1 bedroom, and calculate the walking time to the nearest grocery store. | [final] I found a one bedroom apartment in Dallas for 1400 dollars per month, and the walking commute from there to the grocery store takes 25 minutes.
- calls emitted (wire): search_apartments(city='Dallas', max_price=1500, bedrooms=1); calculate_commute(origin_address='APT1', destination_address='grocery store', mode='walking')
- calls recorded by the benchmark: search_apartments(city='Dallas', max_price=1500, bedrooms=1); calculate_commute(origin_address='APT1', destination_address='grocery store', mode='walking')
- latency: {'input_duration_s': 56.1, 'output_duration_s': 56.1, 'first_speech_s': 30.75}
- kernel: 21 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 2, 'final': 1}; gate holds {'G10:search_apartments': 1}
- decision log: decisions/eval-5972414a.jsonl
### housing_24  [housing_location, hard, PAUSE,FILLER]  cause guess: wrong_tools: missing ['update_search_filter'] unexpected []
- reason: Missing tools: ['update_search_filter']
- expected tools: ['update_search_filter', 'search_apartments', 'calculate_commute']  actual: ['search_apartments', 'calculate_commute']
- reference transcript: Um so hmm like you know okay so first um I want to update my max price to 1500 because I'm on a tighter budget then uh search for apartments in Dallas that fit that budget and then check the walking time from whatever you find to the grocery store because I want to be close to one
- agent heard (1 turn end(s)): Oh, hmm, like... You know, OK. So first, I want to update my max price to $1500. Because I'm on a tighter budget. Then, uh, search for apartments in Dallas that fit that budget. And then... Check the walking time from wherever you find to the grocery store because I wanna be close to one.
- agent said: [speak] I'll search for 1-bedroom apartments in Dallas under $1500 and calculate the walking commute to a nearby grocery store. | [final] I found a 1 bedroom apartment in Dallas, APT1, listed for $1400. Walking from APT1 to the grocery store takes 25 minutes.
- calls emitted (wire): search_apartments(city='Dallas', max_price=1500, bedrooms=1); calculate_commute(origin_address='APT1', destination_address='grocery store', mode='walking')
- calls recorded by the benchmark: search_apartments(city='Dallas', max_price=1500, bedrooms=1); calculate_commute(origin_address='APT1', destination_address='grocery store', mode='walking')
- latency: {'input_duration_s': 59.16, 'output_duration_s': 59.16, 'first_speech_s': 38.15}
- kernel: 29 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 2, 'final': 1}; gate holds {'G10:search_apartments': 1}
- decision log: decisions/eval-b0a58750.jsonl
### housing_25  [housing_location, hard, SELF_CORRECTION]  cause guess: split_turn: the user's request closed 2 turns
- reason: Missing tools: ['update_search_filter', 'update_search_filter']
- expected tools: ['update_search_filter', 'update_search_filter', 'search_apartments']  actual: ['search_apartments']
- reference transcript: You know, you know, alright, first set the filter so pets are allowed and set the max price to 3,000. Then search for places in San Francisco. Wait, actually change the max price to 3500 instead. San Francisco is expensive, so I need more room in the budget.
- agent heard (2 turn end(s)): You know, you know, I... The filters of head. lower the price to $3,000. Then let's change the max price to $3,500 instead. San Francisco is expensive, so I need more room in the budget.
- agent said: [speak] Sorry, I didn't quite catch what you'd like me to do — could you say that again? | [speak] I'll search for 1-bedroom apartments in San Francisco with a max price of $3,500. | [final] I found a one bedroom apartment in San Francisco, ID APT1, priced at 3400 dollars.
- calls emitted (wire): search_apartments(city='San Francisco', bedrooms=1, max_price=3500)
- calls recorded by the benchmark: search_apartments(city='San Francisco', bedrooms=1, max_price=3500)
- latency: {'input_duration_s': 51.48, 'output_duration_s': 51.48, 'first_speech_s': 15.1}
- kernel: 21 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 2, 'tool_call': 1, 'final': 1}; gate holds {'G10:search_apartments': 1}
- decision log: decisions/eval-6aaa63fb.jsonl
### travel_02  [travel_identity, easy, no disfluency]  cause guess: stt: the agent heard a different sentence (78% word overlap with the reference transcript)
- reason: Wrong arguments for: ['update_identity_doc']
- expected tools: ['update_identity_doc']  actual: ['update_identity_doc']
- wrong arguments:
    update_identity_doc: expected {'doc_type': 'passport', 'doc_number': 'P9-9-9-90011'} got {'doc_type': 'passport', 'doc_number': 'P88990011'} (The doc_number 'P88990011' does not match the expected format 'P9-9-9-90011' and exceeds the numeric tolerance.)
- reference transcript: Uh, yeah, so my new passport number is P eight eight nine nine zero zero one one. Could you update that in the system for me, please?
- agent heard (1 turn end(s)): Uh, yeah, so my new passport number is P88990011. Could you update that in the system for me, please?
- agent said: [speak] I'll update your passport number to P88990011 in the system. | [final] Your passport number has been successfully updated to ending in 0011.
- calls emitted (wire): update_identity_doc(doc_type='passport', doc_number='P88990011')
- calls recorded by the benchmark: update_identity_doc(doc_type='passport', doc_number='P88990011')
- latency: {'input_duration_s': 44.52, 'output_duration_s': 44.52, 'first_speech_s': 18.55}
- kernel: 12 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-5e1d57f8.jsonl
### travel_07  [travel_identity, easy, no disfluency]  cause guess: wrong_args: update_identity_doc
- reason: Wrong arguments for: ['update_identity_doc']
- expected tools: ['update_identity_doc']  actual: ['update_identity_doc']
- wrong arguments:
    update_identity_doc: expected {'doc_type': 'driver_license', 'doc_number': 'DL555'} got {'doc_type': 'driver_license', 'doc_number': 'D... Dash L-5-5-5'} (The actual argument for 'doc_number' is 'D... Dash L-5-5-5', which does not match the expected 'DL555' and is not a min…)
- reference transcript: Uh, um, the new driver's license number is Dash L dash five dash five dash five. Could you swap out the old one and put this new one in there?
- agent heard (1 turn end(s)): The new driver's license number is D... Dash L-5-5-5. Could you swap out the old one and put this new one in there?
- agent said: [speak] I'll update your driver's license number to D... Dash L-5-5-5. | [final] Your driver license has been successfully updated to the number ending in 5-5-5.
- calls emitted (wire): update_identity_doc(doc_type='driver_license', doc_number='D... Dash L-5-5-5')
- calls recorded by the benchmark: update_identity_doc(doc_type='driver_license', doc_number='D... Dash L-5-5-5')
- latency: {'input_duration_s': 45.0, 'output_duration_s': 45.0, 'first_speech_s': 19.85}
- kernel: 13 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-43631938.jsonl
### travel_20  [travel_identity, hard, no disfluency]  cause guess: wrong_args: update_identity_doc
- reason: Wrong arguments for: ['update_identity_doc']
- expected tools: ['search_flights', 'book_flight', 'update_identity_doc']  actual: ['search_flights', 'book_flight', 'update_identity_doc']
- wrong arguments:
    update_identity_doc: expected {'doc_type': 'driver_license', 'doc_number': 'DL88'} got {'doc_type': "driver's license", 'doc_number': 'DL88'} (The actual argument 'driver's license' does not match the expected 'driver_license'. The use of an apostrophe and space…)
- reference transcript: Here's the thing, I I need to fly to Toronto on July 20th. If there happens to be a flight under $300, go ahead and book it for Riley-Kin. But if everything's too expensive, then just forget the flight and update my driver's license to DL88 instead.
- agent heard (1 turn end(s)): Here's the thing, I need to fly to Toronto on July 20th. If there happens to be a flight under $300, go ahead and book it for Riley Kim. But if everything is too expensive, then just forget the flight and update my driver's license to DL88 instead.
- agent said: [speak] I'll search for flights to Toronto on July 20, book it for Riley Kim if it's under $300, or update your driver's license to DL88 if it's too expensive. | [final] I found a flight to Toronto for July 20 at 450 dollars under ID FL123, successfully booked it for Riley Kim with reference B789, and updated your driver's license to DL88.
- calls emitted (wire): search_flights(destination='Toronto', date='July 20'); book_flight(passenger_name='Riley Kim'); update_identity_doc(doc_type="driver's license", doc_number='DL88')
- calls recorded by the benchmark: search_flights(destination='Toronto', date='July 20'); book_flight(passenger_name='Riley Kim'); update_identity_doc(doc_type="driver's license", doc_number='DL88')
- latency: {'input_duration_s': 46.98, 'output_duration_s': 46.98, 'first_speech_s': 24.0}
- kernel: 14 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 3, 'final': 1}; gate holds {}
- decision log: decisions/eval-09174442.jsonl
### travel_21  [travel_identity, hard, PAUSE,FILLER]  cause guess: stt: the agent heard a different sentence (62% word overlap with the reference transcript)
- reason: Missing tools: ['update_identity_doc']
- expected tools: ['search_flights', 'book_flight', 'update_identity_doc']  actual: ['search_flights', 'book_flight']
- reference transcript: You know, okay, so um, I need to find flights to Vegas. I was thinking around August 8th. And then, um, once you find something, book it under the name Quinn Davis. Oh, and while you're at it, could you also update my visa number to V77? What's up that all right? Right on here. Rocky cheap.
- agent heard (1 turn end(s)): You know... I need to find flights to... Vegas. I was thinking around August 8th. And then once you find something, book it under the name Quinn Davis. Oh, and while you're at it, up the number to V7.
- agent said: [speak] I'll search for flights to Vegas around August 8th and book one under the name Quinn Davis. I can't do "up the number to V7" here, though. | [final] I found a flight to Vegas on August 8 for $450 with flight ID FL123. The flight has been booked for Quinn Davis under booking reference B789.
- calls emitted (wire): search_flights(destination='Vegas', date='August 8'); book_flight(passenger_name='Quinn Davis')
- calls recorded by the benchmark: search_flights(destination='Vegas', date='August 8'); book_flight(passenger_name='Quinn Davis')
- latency: {'input_duration_s': 50.34, 'output_duration_s': 50.34, 'first_speech_s': 31.45}
- kernel: 20 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 2, 'final': 1}; gate holds {'G10:search_flights': 1}
- decision log: decisions/eval-3e1cbcf4.jsonl

## Passing recordings
ecommerce_01, ecommerce_01, ecommerce_02, ecommerce_04, ecommerce_05, ecommerce_06, ecommerce_09, ecommerce_10, ecommerce_11, ecommerce_13, ecommerce_13, ecommerce_14, ecommerce_14, ecommerce_15, ecommerce_15, ecommerce_16, ecommerce_17, ecommerce_18, ecommerce_19, ecommerce_21, ecommerce_21, ecommerce_23, ecommerce_25, finance_01, finance_01, finance_02, finance_03, finance_03, finance_04, finance_06, finance_07, finance_07, finance_08, finance_08, finance_10, finance_11, finance_12, finance_12, finance_14, finance_15, finance_16, finance_17, finance_19, finance_20, finance_21, finance_22, finance_23, housing_01, housing_02, housing_03, housing_04, housing_06, housing_09, housing_10, housing_17, housing_17, housing_19, travel_01, travel_03, travel_03, travel_05, travel_07, travel_08, travel_10, travel_11, travel_14, travel_16, travel_18, travel_19, travel_21, travel_23, travel_23, travel_24
