# Run digest: 20261004_151517

- Scenarios scored: 100  passed: 74  failed: 26  strict pass rate: 0.74
- Janus commit: `1500c2317d59976938d589e06c4149a0c67cd445`  FDB commit: `3e799c45a045256f47d5f1c9cda90157e2d2ec9e`
- Judge: on (FDB --use-llm)
- Tool metrics: {"tool_selection_acc": 0.964, "argument_acc": 0.807, "response_qual": 0.69, "tool_selection_acc_all": 0.964, "argument_acc_all": 0.807, "note": "*_all includes no-response samples (scored 0); default metrics are turn-taken only"}
- Turn-taking: {"total": 100, "turn_taken": 100, "no_response": 0, "turn_take_rate": 1.0}  Latency: {"total_samples": 100, "interruption_count": 0, "interruption_rate": 0.0, "avg_response_latency_s": 7.11, "std_response_latency_s": 3.927, "min_latency_s": 4.72, "max_latency_s": 28.4, "note": "avg/std/min/max exclude interruption samples; computed on turn-taken samples only"}
- by_domain: {"ecommerce_support": 0.828, "travel_identity": 0.85, "finance_billing": 0.92, "housing_location": 0.385}
- by_difficulty: {"easy": 0.833, "medium": 0.794, "hard": 0.567}
- by_num_tools: {"1": 0.803, "2": 0.722, "3": 0.5}
- by_disfluency_feature: {"FALSE_START": 0.667, "FILLER": 0.828, "HESITATION": 0.7, "SELF_CORRECTION": 0.765, "PAUSE": 0.611}
- by_state_rollback: {"with_rollback": 0.765, "without_rollback": 0.735}
- failure_breakdown: {"wrong_tools": 7, "wrong_arguments": 19}
- Recordings re-streamed after a client abort: 0

## Agent log: top errors (de-duplicated)
- 8x ERROR:livekit:livekit::rtc_engine::rtc_session:#:livekit::rtc_engine::rtc_session - publisher data channel '_reliable' closed unexpectedly
- 8x ERROR:livekit:livekit::rtc_engine::rtc_session:#:livekit::rtc_engine::rtc_session - publisher data channel '_lossy' closed unexpectedly
- 8x ERROR:livekit:livekit::rtc_engine::rtc_session:#:livekit::rtc_engine::rtc_session - publisher data channel '_data_track' closed unexpectedly

## Failures by guessed cause (26 total)
- wrong_args: 16
- wrong_tools: 4
- split_turn: 3
- silent: 2
- stt: 1

## Failing recordings

### ecommerce_08  [ecommerce_support, easy, PAUSE]  cause guess: wrong_args: search_products
- reason: Wrong arguments for: ['search_products']
- expected tools: ['search_products']  actual: ['search_products']
- wrong arguments:
    search_products: expected {'query': 'mechanical keyboards', 'max_price': 200} got {'query': 'mechanical keyboard', 'max_price': 200} (The 'query' argument is 'mechanical keyboard' instead of the expected 'mechanical keyboards'.)
- reference transcript: Ah, hmm. You know, um, I want a mechanical keyboard and I'm trying, um, to keep my budget under two hundred dollars. Do you have anything like that?
- agent heard (1 turn end(s)): You know, um... I want a mechanical keyboard, and I'm trying to keep my budget under... Two hundred dollars? Do you have anything like that?
- agent said: [speak] I'll search for mechanical keyboards under $200. | [final] I found the mechanical keyboard Premium priced at $190 under product ID PROD1.
- calls emitted (wire): search_products(query='mechanical keyboard', max_price=200)
- calls recorded by the benchmark: search_products(query='mechanical keyboard', max_price=200)
- latency: {'input_duration_s': 45.78, 'output_duration_s': 45.78, 'first_speech_s': 20.65}
- kernel: 15 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-d270f330.jsonl
### ecommerce_08  [ecommerce_support, easy, PAUSE]  cause guess: wrong_args: search_products
- reason: Wrong arguments for: ['search_products']
- expected tools: ['search_products']  actual: ['search_products']
- wrong arguments:
    search_products: expected {'query': 'mechanical keyboards', 'max_price': 200} got {'query': 'mechanical keyboard', 'max_price': 200} (The query argument 'mechanical keyboard' does not match the expected 'mechanical keyboards'.)
- reference transcript: Um, yeah, you know, uh, I want a mechanical keyboard, and I'm trying to keep my budget under $200. Do you have anything like that?
- agent heard (1 turn end(s)): Yeah, you know, uh... I want a mechanical keyboard, and I'm trying to keep my budget under $200. Do you have anything like that?
- agent said: [speak] I'll search for mechanical keyboards under $200. | [final] I searched for mechanical keyboards under 200 dollars and found the mechanical keyboard Premium priced at 190 dollars with the product ID PROD1.
- calls emitted (wire): search_products(query='mechanical keyboard', max_price=200)
- calls recorded by the benchmark: search_products(query='mechanical keyboard', max_price=200)
- latency: {'input_duration_s': 43.44, 'output_duration_s': 43.44, 'first_speech_s': 20.05}
- kernel: 16 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {'G10:search_products': 1}
- decision log: decisions/eval-c774bad6.jsonl
### ecommerce_12  [ecommerce_support, medium, HESITATION,PAUSE]  cause guess: wrong_args: search_products
- reason: Wrong arguments for: ['search_products']
- expected tools: ['search_products']  actual: ['search_products']
- wrong arguments:
    search_products: expected {'query': 'gift', 'category': 'electronics'} got {'query': 'electronics'} (The actual arguments are missing the 'category' key and the 'query' value does not match the expected 'gift'.)
- reference transcript: Like, you know, um, I'm thinking something in the let me think electronics section of the grid. He's really into gadgets and text stuff.
- agent heard (1 turn end(s)): Like, you know, I'm thinking something in the, let me think, electronics section would be great. He's really into gadgets and tech stuff.
- agent said: [speak] I'll search for products in electronics. | [final] I searched for electronics and found electronics Premium with product ID PROD1 priced at 99.99.
- calls emitted (wire): search_products(query='electronics')
- calls recorded by the benchmark: search_products(query='electronics')
- latency: {'input_duration_s': 41.264, 'output_duration_s': 41.264, 'first_speech_s': 18.7}
- kernel: 12 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {'G10:search_products': 1}
- decision log: decisions/eval-ce390f49.jsonl
### ecommerce_20  [ecommerce_support, hard, no disfluency]  cause guess: wrong_tools: missing ['add_to_cart'] unexpected ['track_order']
- reason: Missing tools: ['add_to_cart']; Unexpected tools: ['track_order']
- expected tools: ['search_products', 'add_to_cart']  actual: ['search_products', 'track_order']
- reference transcript: So, you know, so search for a coffee maker first. If you find one that's under $50, go ahead and add two to the cart because they make great gifts. But if everything's over $50, I'd just forget the coffee maker and track order WWW for me instead.
- agent heard (1 turn end(s)): So, you know, I... So search for a coffee maker first. If you find one that's under $50, go ahead and add two to the cart because they make great gifts. But if everything's over $50, just forget the coffee maker and track order www for me instead.
- agent said: [speak] I'll search for coffee makers, add two to the cart if one is found under $50, or track order www if they are all over $50. | [final] I searched for a coffee maker and found the coffee maker Premium for $99.99, and I tracked order www which is currently out for delivery. I did not add the coffee maker to your cart because its price is not under $50.
- calls emitted (wire): search_products(query='coffee maker'); track_order(order_id='www')
- calls recorded by the benchmark: search_products(query='coffee maker'); track_order(order_id='www')
- latency: {'input_duration_s': 54.629, 'output_duration_s': 54.629, 'first_speech_s': 31.55}
- kernel: 17 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 2, 'final': 1}; gate holds {}
- decision log: decisions/eval-a2ddb1b8.jsonl
### ecommerce_25  [ecommerce_support, hard, FALSE_START]  cause guess: wrong_args: track_order
- reason: Wrong arguments for: ['track_order']
- expected tools: ['track_order', 'search_products', 'add_to_cart']  actual: ['track_order', 'search_products', 'add_to_cart']
- wrong arguments:
    track_order: expected {'order_id': 'CAT'} got {'order_id': 'ZAT'} (The actual argument 'order_id' is 'ZAT', which does not match the expected 'CAT'.)
- reference transcript: You know, um, well, can um I return my never mind, uh, forget the return. Let me focus on what I actually need. Track order CAT for me, then search for cat food because I'm running low and add three of whatever you find to my card.
- agent heard (1 turn end(s)): You know, um, well... Can, um... I return my... Never mind, uh, forget the return. Let me focus on what I actually need. Track order ZAT for me. And search for cat food because I'm running low. and add three of whatever you find to my cart.
- agent said: [speak] I'll track order ZAT, search for cat food, and add 3 of whatever I find to your cart. | [final] Your order ZAT is currently out for delivery, and I have added 3 items of cat food Premium to your cart for a total of 299.97.
- calls emitted (wire): track_order(order_id='ZAT'); search_products(query='cat food'); add_to_cart(product_id='PROD1', quantity=3)
- calls recorded by the benchmark: track_order(order_id='ZAT'); search_products(query='cat food'); add_to_cart(product_id='PROD1', quantity=3)
- latency: {'input_duration_s': 53.7, 'output_duration_s': 53.7, 'first_speech_s': 29.8}
- kernel: 29 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 3, 'final': 1}; gate holds {}
- decision log: decisions/eval-72e40b6b.jsonl
### finance_18  [finance_billing, hard, no disfluency]  cause guess: wrong_args: get_exchange_rate
- reason: Wrong arguments for: ['get_exchange_rate']
- expected tools: ['get_exchange_rate', 'modify_autopay', 'get_card_benefits']  actual: ['get_exchange_rate', 'modify_autopay', 'get_card_benefits']
- wrong arguments:
    get_exchange_rate: expected {'amount': 1000, 'from_currency': 'USD', 'to_currency': 'EUR'} got {'amount': 1000, 'from_currency': 'USD', 'to_currency': 'UAH'} (The 'to_currency' argument is 'UAH' instead of the expected 'EUR'.)
- reference transcript: Um so alright, so first um I need to know how much thousand US dollars would be in Euros. Then I want to change my credit card or to pay so it pulls from the savings instead. And finally, can you tell me what kind of benefits the premium card has?
- agent heard (1 turn end(s)): Um, so right, so first, I need to know how much thousand US dollars would be in UAH. Then I want to change my credit card autopay so it pulls from the savings instead. And finally, can you tell me what kind of benefits the premium card has?
- agent said: [speak] I'll check the exchange rate for 1000 USD to UAH, update your credit card autopay to pull from savings, and look up the benefits for the premium card. | [final] The exchange of 1000 USD yields 900 UAH at a rate of 0.9, and autopay from your savings account for the credit card bill has been confirmed. Additionally, your premium card includes benefits such as 2% cashback and no foreign transaction fees.
- calls emitted (wire): get_exchange_rate(amount=1000, from_currency='USD', to_currency='UAH'); modify_autopay(bill_type='credit_card', source_account='savings'); get_card_benefits(card_type='premium')
- calls recorded by the benchmark: get_exchange_rate(amount=1000, from_currency='USD', to_currency='UAH'); modify_autopay(bill_type='credit_card', source_account='savings'); get_card_benefits(card_type='premium')
- latency: {'input_duration_s': 49.797, 'output_duration_s': 49.797, 'first_speech_s': 27.4}
- kernel: 14 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 3, 'final': 1}; gate holds {}
- decision log: decisions/eval-b79224c1.jsonl
### finance_20  [finance_billing, hard, no disfluency]  cause guess: wrong_tools: missing ['modify_autopay'] unexpected []
- reason: Missing tools: ['modify_autopay']
- expected tools: ['get_exchange_rate', 'modify_autopay']  actual: ['get_exchange_rate']
- reference transcript: Well, here's my situation. I want to check what 1,000 US dollars is in Euros right now. If the exchange rate looks good to me, then go ahead and change my mortgage auto pay to pull from checking. But if the rate isn't great, just leave everything as is and keep it on the savings.
- agent heard (1 turn end(s)): Well, here's my situation. I want to check what $1,000 US is in euros right now. If the exchange rate looks good to me, then go ahead and change my mortgage auto-pay to pull from checking, but if the rate isn't great, just leave everything as is and keep it on the savings.
- agent said: [speak] I'll check the exchange rate for $1,000 USD to EUR, and if the rate looks good to you, I'll update your mortgage auto-pay source account to checking. | [final] I checked the exchange rate and converted 1,000 USD to 900 EUR at a rate of 0.9. I did not update your autopay since that depended on whether you liked the exchange rate, but I can do that for you now if you'd like.
- calls emitted (wire): get_exchange_rate(amount=1000, from_currency='USD', to_currency='EUR')
- calls recorded by the benchmark: get_exchange_rate(amount=1000, from_currency='USD', to_currency='EUR')
- latency: {'input_duration_s': 52.576, 'output_duration_s': 52.576, 'first_speech_s': 29.9}
- kernel: 12 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-cc97357c.jsonl
### housing_05  [housing_location, easy, HESITATION,PAUSE]  cause guess: wrong_args: search_apartments
- reason: Wrong arguments for: ['search_apartments']
- expected tools: ['search_apartments']  actual: ['search_apartments']
- wrong arguments:
    search_apartments: expected {'city': 'Miami', 'max_price': 1500, 'pets_allowed': True} got {'city': 'Miami', 'max_price': 1500, 'bedrooms': 1} (The actual arguments are missing the 'pets_allowed' argument and include an unexpected 'bedrooms' argument.)
- reference transcript: You know, you know, you know, well, I need um a pet-friendly apartment in Miami, and my budget is about let me check fifteen hundred a month. Is there anything in that range?
- agent heard (1 turn end(s)): You know? You know, you know well, I need, um... a pet-friendly apartment in Miami, and my budget is about, uh, let me check. Fifteen hundred a month. Is there anything in that range?
- agent said: [speak] I'll search for pet-friendly apartments in Miami with a budget of 1500 a month, assuming 1 bedroom. I can't do "filter by pet-friendly" here, though. | [final] I found a one-bedroom apartment in Miami for $1,400 per month, with the listing ID APT1.
- calls emitted (wire): search_apartments(city='Miami', max_price=1500, bedrooms=1)
- calls recorded by the benchmark: search_apartments(city='Miami', max_price=1500, bedrooms=1)
- latency: {'input_duration_s': 48.9, 'output_duration_s': 48.9, 'first_speech_s': 24.6}
- kernel: 20 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {'G10:search_apartments': 1}
- decision log: decisions/eval-d1dd6e26.jsonl
### housing_05  [housing_location, easy, HESITATION,PAUSE]  cause guess: split_turn: the user's request closed 3 turns
- reason: Wrong arguments for: ['search_apartments']
- expected tools: ['search_apartments']  actual: ['search_apartments']
- wrong arguments:
    search_apartments: expected {'city': 'Miami', 'max_price': 1500, 'pets_allowed': True} got {'city': 'Miami', 'max_price': 1500, 'bedrooms': 1} (The actual arguments are missing 'pets_allowed' and include an unexpected 'bedrooms' argument.)
- reference transcript: You know, um, you know, well, I need um a pet-friendly apartment in Miami, and my budget is about uh let me check. It's uh it's about fifteen hundred a month. Is there anything in that range?
- agent heard (3 turn end(s)): You know, um... You know, well, I need a pet-friendly apartment in Miami, and my budget is about, let me check, it's... It's about $1,500 a month. Is there anything in that range?
- agent said: [speak] I'll search for pet-friendly apartments in Miami under $1,500 a month, assuming 1 bedroom. I can't do "pet-friendly filter" here, though. | [final] I found a one bedroom apartment in Miami with ID APT1 listed for 1400 dollars per month.
- calls emitted (wire): search_apartments(city='Miami', max_price=1500, bedrooms=1)
- calls recorded by the benchmark: search_apartments(city='Miami', max_price=1500, bedrooms=1)
- latency: {'input_duration_s': 50.1, 'output_duration_s': 50.1, 'first_speech_s': 28.4}
- kernel: 23 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-1c993fae.jsonl
### housing_08  [housing_location, easy, FALSE_START]  cause guess: wrong_args: update_search_filter
- reason: Wrong arguments for: ['update_search_filter']
- expected tools: ['update_search_filter']  actual: ['update_search_filter']
- wrong arguments:
    update_search_filter: expected {'filter_name': 'pets_allowed', 'value': True} got {'filter_name': 'pets_allowed', 'value': 'true'} (The expected argument for 'value' is a boolean true, but the actual argument is a string 'true'.)
- reference transcript: Okay, so um I want to check the listings in. Actually, before before I do that, could you just update my search filter so that it only shows me places that allow pets? I have a cat.
- agent heard (1 turn end(s)): Okay, so I wanna check the listings and actually, before I do that... could you just update my search filter so that it only shows me places that allow pets? I have a cat.
- agent said: [speak] I'll update your search filter to allow pets. | [final] I have updated your search filter to allow pets.
- calls emitted (wire): update_search_filter(filter_name='pets_allowed', value='true')
- calls recorded by the benchmark: update_search_filter(filter_name='pets_allowed', value='true')
- latency: {'input_duration_s': 45.72, 'output_duration_s': 45.72, 'first_speech_s': 18.35}
- kernel: 12 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-8aa20646.jsonl
### housing_11  [housing_location, medium, SELF_CORRECTION]  cause guess: silent: the agent made no calls
- reason: Missing tools: ['search_apartments']
- expected tools: ['search_apartments']  actual: []
- reference transcript: Uh well, I was thinking a one bedroom under twelve well actually no wait, my partner is moving in with me, so we need a two bedroom and we can go up uh uh up to sixteen hundred a month.
- agent heard (1 turn end(s)): Well, I was thinking of one bedroom under 12, but actually, no, wait, my partner is moving in with me, so we need a two-bedroom, and we can go up to $1,600 a month.
- agent said: [speak] I'll search for two-bedroom apartments with a maximum rent of $1,600 a month. | [clarify] I need a bit more information — what should city be?
- calls emitted (wire): none
- calls recorded by the benchmark: none
- latency: {'input_duration_s': 41.46, 'output_duration_s': 41.46, 'first_speech_s': 16.25}
- kernel: 9 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'clarify': 1}; gate holds {}
- decision log: decisions/eval-aa3237a0.jsonl
### housing_13  [housing_location, medium, no disfluency]  cause guess: wrong_args: update_search_filter
- reason: Wrong arguments for: ['update_search_filter']
- expected tools: ['update_search_filter', 'update_search_filter']  actual: ['update_search_filter', 'update_search_filter']
- wrong arguments:
    update_search_filter: expected {'filter_name': 'min_bedrooms', 'value': 3} got {'filter_name': 'bedrooms', 'value': '3'} (The expected argument 'filter_name' is 'min_bedrooms', but the actual argument is 'bedrooms'. Also, the expected 'value…)
- reference transcript: You know, like, you know, let's raise the max price to three thousand per month and also bump up the minimum bedrooms to three. Yeah, I think I need more space than I originally thought.
- agent heard (1 turn end(s)): You know, like, you know, let's raise the max price to $3,000 per month. And also bump up the minimum bedrooms to three. Yeah, I think I need more space than I originally thought.
- agent said: [speak] I'll update your max price filter to 3000 and your bedrooms filter to 3. | [final] I have updated your search filters to a maximum price of 3000 and 3 bedrooms.
- calls emitted (wire): update_search_filter(filter_name='max_price', value='3000'); update_search_filter(filter_name='bedrooms', value='3')
- calls recorded by the benchmark: update_search_filter(filter_name='max_price', value='3000'); update_search_filter(filter_name='bedrooms', value='3')
- latency: {'input_duration_s': 48.507, 'output_duration_s': 48.507, 'first_speech_s': 23.0}
- kernel: 17 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 2, 'final': 1}; gate holds {}
- decision log: decisions/eval-5b7797c3.jsonl
### housing_14  [housing_location, medium, FILLER]  cause guess: wrong_args: search_apartments
- reason: Wrong arguments for: ['search_apartments']
- expected tools: ['search_apartments']  actual: ['search_apartments']
- wrong arguments:
    search_apartments: expected {'city': 'Portland', 'bedrooms': 1, 'max_price': 1800, 'pets_allowed': True} got {'city': 'Portland', 'bedrooms': 1, 'max_price': 1800} (The 'pets_allowed' argument is missing in the actual arguments.)
- reference transcript: Like, you know, um, so um, I'm looking for like a one-bedroom apartment in Portland, and I'd want to keep the rent under 1,800. Oh, and it needs to be uh pet-friendly because um I have a dog.
- agent heard (1 turn end(s)): Like, you know, um, so, um, I'm looking for, like, a one-bedroom apartment in Portland, and I'd want to keep the rent under $1,800. Oh, and it needs to be pet-friendly because I have a dog.
- agent said: [speak] I'll search for one-bedroom apartments in Portland under $1,800 per month. I can't do "filter for pet-friendly apartments" here, though. | [final] I found a one-bedroom apartment in Portland listed at $1700 per month with the ID APT1.
- calls emitted (wire): search_apartments(city='Portland', bedrooms=1, max_price=1800)
- calls recorded by the benchmark: search_apartments(city='Portland', bedrooms=1, max_price=1800)
- latency: {'input_duration_s': 48.36, 'output_duration_s': 48.36, 'first_speech_s': 24.1}
- kernel: 13 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-7ab82b49.jsonl
### housing_14  [housing_location, medium, FILLER]  cause guess: split_turn: the user's request closed 2 turns
- reason: Wrong arguments for: ['search_apartments']
- expected tools: ['search_apartments']  actual: ['search_apartments']
- wrong arguments:
    search_apartments: expected {'city': 'Portland', 'bedrooms': 1, 'max_price': 1800, 'pets_allowed': True} got {'city': 'Portland', 'bedrooms': 1, 'max_price': 1800} (The 'pets_allowed' argument is missing in the actual arguments.)
- reference transcript: Like, you know, so um, I'm looking for like a one-bedroom apartment in Portland and I'd want to keep the rent under $1,800. Oh, well, and oh, and it needs to be uh pet-friendly because uh I have a dog.
- agent heard (2 turn end(s)): Like, and you know, so, um, I'm looking for like a one-bedroom apartment in Portland. And I wanna keep the rent under $1,800, so, well, and it needs to be pet-friendly because... I have a dog.
- agent said: [speak] I'll search for one-bedroom apartments in Portland under $1,800. I can't do "pet-friendly filter" here, though. | [final] I found a one-bedroom apartment in Portland listed at $1,700 per month under ID APT1.
- calls emitted (wire): search_apartments(city='Portland', bedrooms=1, max_price=1800)
- calls recorded by the benchmark: search_apartments(city='Portland', bedrooms=1, max_price=1800)
- latency: {'input_duration_s': 51.3, 'output_duration_s': 51.3, 'first_speech_s': 32.4}
- kernel: 21 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {'G3:search_apartments': 1}
- decision log: decisions/eval-93c4dca6.jsonl
### housing_15  [housing_location, medium, FALSE_START]  cause guess: wrong_args: search_apartments
- reason: Wrong arguments for: ['search_apartments']
- expected tools: ['search_apartments']  actual: ['search_apartments']
- wrong arguments:
    search_apartments: expected {'city': 'Atlanta', 'bedrooms': 3, 'pets_allowed': True} got {'city': 'Atlanta', 'bedrooms': 3, 'max_price': 10000} (The actual arguments are missing 'pets_allowed' and include an unexpected 'max_price' argument.)
- reference transcript: Um so hmm uh I wanted um to check the commute from that one listing. Actually let me skip that for now. Could you just search for a three-bedroom in Atlanta that's pet-friendly? I've got two cats.
- agent heard (1 turn end(s)): I wanted to check the commute from that one listing. Actually, let me skip that for now. Could you just search for a three-bedroom in Atlanta that's pet-friendly? I've got two cats.
- agent said: [speak] I'll search for three-bedroom apartments in Atlanta with a maximum price assumption, and note that you're looking for a pet-friendly listing. I can't do "filter by pet-friendly" here, though. | [final] I found a three bedroom apartment in Atlanta, listing ID APT1, priced at 9900.
- calls emitted (wire): search_apartments(city='Atlanta', bedrooms=3, max_price=10000)
- calls recorded by the benchmark: search_apartments(city='Atlanta', bedrooms=3, max_price=10000)
- latency: {'input_duration_s': 48.42, 'output_duration_s': 48.42, 'first_speech_s': 24.0}
- kernel: 14 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {'G10:search_apartments': 1}
- decision log: decisions/eval-128ba5a5.jsonl
### housing_15  [housing_location, medium, FALSE_START]  cause guess: split_turn: the user's request closed 2 turns
- reason: Unexpected tools: ['update_search_filter']
- expected tools: ['search_apartments']  actual: ['search_apartments', 'update_search_filter']
- reference transcript: Um, so um uh I wanted to I wanted to check the commute from that one listing. Actually, let me skip that for now. Could you just search for a three-bedroom in Atlanta that's pet-friendly? I um I've got two cats too.
- agent heard (2 turn end(s)): So, I wanted to check the commute from that one listing. Actually, let me skip that for now. Could you just search for a three-bedroom in Atlanta? that's pet-friendly. I've got two cats, too.
- agent said: [speak] I'll search for 3-bedroom apartments in Atlanta, assuming a max price of $10,000, and filter for pet-friendly listings. | [final] I found a three bedroom apartment in Atlanta for 9900 dollars with the ID APT1. I also successfully updated your search filter to pet friendly.
- calls emitted (wire): search_apartments(city='Atlanta', bedrooms=3, max_price=10000); update_search_filter(filter_name='pet_friendly', value='true')
- calls recorded by the benchmark: search_apartments(city='Atlanta', bedrooms=3, max_price=10000); update_search_filter(filter_name='pet_friendly', value='true')
- latency: {'input_duration_s': 50.52, 'output_duration_s': 50.52, 'first_speech_s': 32.95}
- kernel: 22 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 2, 'final': 1}; gate holds {'G3:search_apartments': 4, 'G10:search_apartments': 1}
- decision log: decisions/eval-92d38926.jsonl
### housing_18  [housing_location, hard, no disfluency]  cause guess: wrong_args: search_apartments
- reason: Wrong arguments for: ['search_apartments']
- expected tools: ['search_apartments', 'calculate_commute']  actual: ['search_apartments', 'calculate_commute']
- wrong arguments:
    search_apartments: expected {'city': 'Portland', 'bedrooms': 1, 'max_price': 1800} got {'city': 'Portland', 'bedrooms': 1, 'max_price': 800} (The 'max_price' argument is outside the acceptable numeric tolerance range of ±5%.)
- reference transcript: Well so first, search for a one-bedroom in Portland that's under $800 per month, then once you find the cheapest option, check how long it would take to bike from there to the coffee shop on 5th Street where I work.
- agent heard (1 turn end(s)): Well, so first, search for a one-bedroom in Portland that's under $800 per month, then once you find the cheapest option, check how long it would take to bike from there to the coffee shop on 5th Street where I work.
- agent said: [speak] I'll search for one-bedroom apartments in Portland under $800 per month, then calculate the biking commute from the cheapest option to the coffee shop on 5th Street. | [final] I found a one-bedroom apartment in Portland, ID APT1, priced at $700 per month. The biking commute from APT1 to the coffee shop on 5th Street takes 25 minutes.
- calls emitted (wire): search_apartments(city='Portland', bedrooms=1, max_price=800); calculate_commute(origin_address='APT1', destination_address='the coffee shop on 5th Street', mode='biking')
- calls recorded by the benchmark: search_apartments(city='Portland', bedrooms=1, max_price=800); calculate_commute(origin_address='APT1', destination_address='the coffee shop on 5th Street', mode='biking')
- latency: {'input_duration_s': 47.685, 'output_duration_s': 47.685, 'first_speech_s': 23.85}
- kernel: 14 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 2, 'final': 1}; gate holds {}
- decision log: decisions/eval-8a7054fe.jsonl
### housing_20  [housing_location, hard, no disfluency]  cause guess: wrong_args: search_apartments
- reason: Wrong arguments for: ['search_apartments']
- expected tools: ['search_apartments', 'calculate_commute', 'update_search_filter']  actual: ['search_apartments', 'calculate_commute', 'update_search_filter']
- wrong arguments:
    search_apartments: expected {'city': 'Austin', 'max_price': 2000} got {'city': 'Austin', 'max_price': 2000, 'bedrooms': 1} (The actual arguments include an extra 'bedrooms' parameter which is not expected.)
- reference transcript: Uh you know so here's what I'm thinking. Search for places in Austin under 2,000. Then check the commute to my office. If it's under 15 minutes, that's perfect. But if it's longer then raise my budget to 2,500 so uh I can look at places closer to work.
- agent heard (1 turn end(s)): You know, so here's what I'm thinking. Search for places in Austin under $2,000. Then, check the commute to my office. If it's under 15 minutes, that's perfect, but if it's longer, then raise my budget to $2,500 so I can look at places closer to work.
- agent said: [speak] I'll search for 1-bedroom places in Austin under $2,000, check the commute to your office, and update your maximum price to $2,500 if the commute is longer than 15 minutes. | [final] I searched for one-bedroom apartments in Austin and found listing APT1 for $1900, which has a driving commute of 25 minutes to your office. I have also updated your maximum price filter to $2500.
- calls emitted (wire): search_apartments(city='Austin', max_price=2000, bedrooms=1); calculate_commute(origin_address='APT1', destination_address='my office'); update_search_filter(filter_name='max_price', value='2500')
- calls recorded by the benchmark: search_apartments(city='Austin', max_price=2000, bedrooms=1); calculate_commute(origin_address='APT1', destination_address='my office', mode='driving'); update_search_filter(filter_name='max_price', value='2500')
- latency: {'input_duration_s': 47.46, 'output_duration_s': 47.46, 'first_speech_s': 24.0}
- kernel: 19 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 3, 'final': 1}; gate holds {}
- decision log: decisions/eval-80667ed4.jsonl
### housing_21  [housing_location, hard, SELF_CORRECTION]  cause guess: silent: the agent made no calls
- reason: Missing tools: ['search_apartments', 'calculate_commute']
- expected tools: ['search_apartments', 'calculate_commute']  actual: []
- reference transcript: So well, so you know I want to search for a place with two bedrooms. Wait, actually, I mean, I meant three bedrooms. We decided we need a home office. Also, check the transit time to the train station. Actually, I'd rather walk, so make that walk-in time.
- agent heard (1 turn end(s)): Well, so you know, I want to search for a place with two bedrooms. Wait, actually, I mean, I meant three bedrooms. We decided we need a home office. Also check the transit time to the train station. Actually, I'd rather walk, so make that. Walking time.
- agent said: [speak] I'll calculate the walking time to the train station. I can't do "search for 3-bedroom apartment with a home office" here, though. | [clarify] I need a bit more information — what should origin address be?
- calls emitted (wire): none
- calls recorded by the benchmark: none
- latency: {'input_duration_s': 49.725, 'output_duration_s': 49.725, 'first_speech_s': 26.6}
- kernel: 12 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'clarify': 1}; gate holds {}
- decision log: decisions/eval-ab0494c0.jsonl
### housing_22  [housing_location, hard, FILLER]  cause guess: wrong_args: update_search_filter
- reason: Wrong arguments for: ['update_search_filter']
- expected tools: ['update_search_filter', 'search_apartments', 'calculate_commute']  actual: ['update_search_filter', 'search_apartments', 'calculate_commute']
- wrong arguments:
    update_search_filter: expected {'filter_name': 'pets_allowed', 'value': True} got {'filter_name': 'pets', 'value': 'allowed'} (The expected argument 'filter_name' is 'pets_allowed', but the actual argument is 'pets'. Also, the expected 'value' is…)
- reference transcript: You know, um, can you first update my filter so pets are allowed? Um, I keep forgetting to set that. Then, like, search in Seattle for one bedroom. And then once you find something, uh, check the transit time from there to the stadium because, you know, I go to games pretty often.
- agent heard (1 turn end(s)): You know, um, can you first update my filter so pets are allowed? Um, I keep forgetting to set that. Then, like, search in Seattle for one bedroom. And then once you find something, check the transit time. From there to the stadium, because, you know, I go to games pretty often.
- agent said: [speak] I'll update your filter to allow pets, search for one-bedroom apartments in Seattle assuming a maximum price of 5000, and calculate the transit commute time to the stadium. | [final] I updated your filter to allow pets and found a one bedroom apartment in Seattle for forty nine hundred dollars. A transit commute from that apartment to the stadium takes about twenty five minutes.
- calls emitted (wire): update_search_filter(filter_name='pets', value='allowed'); search_apartments(city='Seattle', bedrooms=1, max_price=5000); calculate_commute(origin_address='APT1', destination_address='the stadium', mode='transit')
- calls recorded by the benchmark: update_search_filter(filter_name='pets', value='allowed'); search_apartments(city='Seattle', bedrooms=1, max_price=5000); calculate_commute(origin_address='APT1', destination_address='the stadium', mode='transit')
- latency: {'input_duration_s': 50.1, 'output_duration_s': 50.1, 'first_speech_s': 25.45}
- kernel: 25 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 3, 'final': 1}; gate holds {'G10:search_apartments': 1}
- decision log: decisions/eval-cd0b15ce.jsonl
### housing_24  [housing_location, hard, PAUSE,FILLER]  cause guess: wrong_args: search_apartments
- reason: Wrong arguments for: ['search_apartments']
- expected tools: ['update_search_filter', 'search_apartments', 'calculate_commute']  actual: ['update_search_filter', 'search_apartments', 'calculate_commute']
- wrong arguments:
    search_apartments: expected {'city': 'Dallas'} got {'city': 'Dallas', 'bedrooms': 1, 'max_price': 1500} (The function was called with additional arguments 'bedrooms' and 'max_price' which were not expected.)
- reference transcript: Um, so hmm, like, you know, okay. So, first, um, I want to update my max price to $1,500 because I'm on a tighter budget. Then, uh, search for apartments in Dallas that fit that budget, and then check the walking time from whatever you find to the grocery store because I want to be close to one.
- agent heard (1 turn end(s)): Like, you know. OK, so first, I want to update my max price to $1500 because I'm on a tighter budget, then search for apartments in Dallas that fit that budget, and then... Check the walking time from whatever you find to the grocery store, because I want to be close to one.
- agent said: [speak] I'll update your max price filter to $1500, search for 1-bedroom apartments in Dallas under $1500, and calculate the walking time from the found apartment to the grocery store. | [final] I updated your search filter for maximum price to 1500 and found one apartment in Dallas, APT1, for 1400 dollars per month. A 25-minute walking commute was also calculated from APT1 to the grocery store.
- calls emitted (wire): update_search_filter(filter_name='max_price', value='1500'); search_apartments(city='Dallas', bedrooms=1, max_price=1500); calculate_commute(origin_address='APT1', destination_address='grocery store', mode='walking')
- calls recorded by the benchmark: update_search_filter(filter_name='max_price', value='1500'); search_apartments(city='Dallas', bedrooms=1, max_price=1500); calculate_commute(origin_address='APT1', destination_address='grocery store', mode='walking')
- latency: {'input_duration_s': 56.1, 'output_duration_s': 56.1, 'first_speech_s': 32.75}
- kernel: 23 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 3, 'final': 1}; gate holds {'G10:search_apartments': 1}
- decision log: decisions/eval-a94f7a63.jsonl
### housing_24  [housing_location, hard, PAUSE,FILLER]  cause guess: wrong_args: search_apartments
- reason: Wrong arguments for: ['search_apartments']
- expected tools: ['update_search_filter', 'search_apartments', 'calculate_commute']  actual: ['update_search_filter', 'search_apartments', 'calculate_commute']
- wrong arguments:
    search_apartments: expected {'city': 'Dallas'} got {'city': 'Dallas', 'bedrooms': 1, 'max_price': 1500} (The function was called with additional arguments 'bedrooms' and 'max_price' which were not expected.)
- reference transcript: Um so hmm like you know okay so first um I want to update my max price to 1500 because I'm on a tighter budget then uh search for apartments in Dallas that fit that budget and then check the walking time from whatever you find to the grocery store because I want to be close to one
- agent heard (1 turn end(s)): Like, you know, OK. So first, I want to update my max price to $1500. Because I'm on a tighter budget. Then, search for apartments in Dallas that fit that budget. And then... Check the walking time from whatever you find to the grocery store because I wanna be close to one.
- agent said: [speak] I'll update your max price filter to 1500, search for apartments in Dallas with a max price of 1500, assuming 1 bedroom, and calculate the walking time from the found apartment to the grocery store. | [final] I updated your maximum price filter to $1500 and found apartment APT1 in Dallas for $1400 with one bedroom. The walking commute from APT1 to the grocery store is 25 minutes.
- calls emitted (wire): update_search_filter(filter_name='max_price', value='1500'); search_apartments(city='Dallas', bedrooms=1, max_price=1500); calculate_commute(origin_address='APT1', destination_address='grocery store', mode='walking')
- calls recorded by the benchmark: update_search_filter(filter_name='max_price', value='1500'); search_apartments(city='Dallas', bedrooms=1, max_price=1500); calculate_commute(origin_address='APT1', destination_address='grocery store', mode='walking')
- latency: {'input_duration_s': 59.16, 'output_duration_s': 59.16, 'first_speech_s': 36.05}
- kernel: 26 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 3, 'final': 1}; gate holds {}
- decision log: decisions/eval-3a292ae3.jsonl
### housing_25  [housing_location, hard, SELF_CORRECTION]  cause guess: wrong_tools: missing ['update_search_filter'] unexpected []
- reason: Missing tools: ['update_search_filter']
- expected tools: ['update_search_filter', 'update_search_filter', 'search_apartments']  actual: ['update_search_filter', 'search_apartments']
- reference transcript: You know, you know, alright, first set the filter so pets are allowed and set the max price to 3,000. Then search for places in San Francisco. Wait, actually change the max price to 3500 instead. San Francisco is expensive, so I need more room in the budget.
- agent heard (1 turn end(s)): You know, you know, alright, first set the filter so pets are allowed, and set the max price to $3000. Then search for places in San Francisco. Wait, actually, change the max price to $3500 instead. San Francisco is expensive, so I need more room in the budget.
- agent said: [speak] I'll update the pets allowed filter to true and search for 1-bedroom apartments in San Francisco under $3500. | [final] I updated your search filter to allow pets and found a one bedroom apartment in San Francisco for 3400 dollars per month.
- calls emitted (wire): update_search_filter(filter_name='pets_allowed', value='true'); search_apartments(city='San Francisco', bedrooms=1, max_price=3500)
- calls recorded by the benchmark: update_search_filter(filter_name='pets_allowed', value='true'); search_apartments(city='San Francisco', bedrooms=1, max_price=3500)
- latency: {'input_duration_s': 51.48, 'output_duration_s': 51.48, 'first_speech_s': 26.3}
- kernel: 16 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 2, 'final': 1}; gate holds {'G10:search_apartments': 1}
- decision log: decisions/eval-abe00f1e.jsonl
### travel_02  [travel_identity, easy, no disfluency]  cause guess: stt: the agent heard a different sentence (78% word overlap with the reference transcript)
- reason: Wrong arguments for: ['update_identity_doc']
- expected tools: ['update_identity_doc']  actual: ['update_identity_doc']
- wrong arguments:
    update_identity_doc: expected {'doc_type': 'passport', 'doc_number': 'P9-9-9-90011'} got {'doc_type': 'passport', 'doc_number': 'P88990011'} (The actual doc_number 'P88990011' does not match the expected format 'P9-9-9-90011' and is not within a minor formattin…)
- reference transcript: Uh, yeah, so my new passport number is P eight eight nine nine zero zero one one. Could you update that in the system for me, please?
- agent heard (1 turn end(s)): Uh, yeah, so my new passport number is P88990011. Could you update that in the system for me, please?
- agent said: [speak] I'll update your passport number to P88990011 in the system. | [final] Your passport document has been updated to the number ending in 0011.
- calls emitted (wire): update_identity_doc(doc_type='passport', doc_number='P88990011')
- calls recorded by the benchmark: update_identity_doc(doc_type='passport', doc_number='P88990011')
- latency: {'input_duration_s': 44.52, 'output_duration_s': 44.52, 'first_speech_s': 18.8}
- kernel: 12 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-b9136927.jsonl
### travel_19  [travel_identity, hard, SELF_CORRECTION]  cause guess: wrong_args: search_flights
- reason: Wrong arguments for: ['search_flights']
- expected tools: ['search_flights']  actual: ['search_flights']
- wrong arguments:
    search_flights: expected {'destination': 'Milan', 'date': 'June 3'} got {'destination': 'Mulan', 'date': 'June 3'} (The destination argument is incorrect; 'Milan' was expected, but 'Mulan' was provided.)
- reference transcript: Um, okay, I want to look for flights to Rome. No, wait, I changed my mind. Let's do Milan instead. And I was thinking June 1st. Well, wait, but actually, June 3rd works better for me. Sorry about that.
- agent heard (1 turn end(s)): Okay, I wanna look for flights to Rome. No, wait, I changed my mind. Let's do Mulan instead. And I was thinking June 1st. Well, wait, but actually, June 3rd works better for me. Sorry about that.
- agent said: [speak] I'll search for flights to Mulan for June 3rd. | [final] I found a flight to Mulan on June 3 for 450 dollars under flight ID FL123.
- calls emitted (wire): search_flights(destination='Mulan', date='June 3')
- calls recorded by the benchmark: search_flights(destination='Mulan', date='June 3')
- latency: {'input_duration_s': 49.14, 'output_duration_s': 49.14, 'first_speech_s': 23.55}
- kernel: 19 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-8c526760.jsonl
### travel_20  [travel_identity, hard, no disfluency]  cause guess: wrong_tools: missing ['book_flight'] unexpected []
- reason: Missing tools: ['book_flight']
- expected tools: ['search_flights', 'book_flight', 'update_identity_doc']  actual: ['search_flights', 'update_identity_doc']
- reference transcript: Here's the thing, I I need to fly to Toronto on July 20th. If there happens to be a flight under $300, go ahead and book it for Riley-Kin. But if everything's too expensive, then just forget the flight and update my driver's license to DL88 instead.
- agent heard (1 turn end(s)): Hey, here's the thing: I need to fly to Toronto on July 20th. If there happens to be a flight under $300, go ahead and book it for Riley Kim, but if everything's too expensive, then just forget the flight and update my driver's license to DL-88 instead.
- agent said: [speak] I'll search for flights to Toronto on July 20, book it for Riley Kim if it's under $300, or update your driver's license to DL-88 if not. | [final] I searched for flights to Toronto on July 20th and found flight FL123 for $450, but I did not book it because it was not under $300. I also successfully updated your driver's license number to DL88.
- calls emitted (wire): search_flights(destination='Toronto', date='July 20'); update_identity_doc(doc_type='driver_license', doc_number='DL88')
- calls recorded by the benchmark: search_flights(destination='Toronto', date='July 20'); update_identity_doc(doc_type='driver_license', doc_number='DL88')
- latency: {'input_duration_s': 46.98, 'output_duration_s': 46.98, 'first_speech_s': 22.85}
- kernel: 15 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 2, 'final': 1}; gate holds {}
- decision log: decisions/eval-4df39574.jsonl

## Passing recordings
ecommerce_01, ecommerce_01, ecommerce_02, ecommerce_04, ecommerce_05, ecommerce_06, ecommerce_07, ecommerce_09, ecommerce_10, ecommerce_11, ecommerce_13, ecommerce_13, ecommerce_14, ecommerce_14, ecommerce_15, ecommerce_15, ecommerce_16, ecommerce_17, ecommerce_18, ecommerce_19, ecommerce_21, ecommerce_21, ecommerce_23, ecommerce_25, finance_01, finance_01, finance_02, finance_03, finance_03, finance_04, finance_06, finance_07, finance_07, finance_08, finance_08, finance_10, finance_11, finance_12, finance_12, finance_14, finance_15, finance_16, finance_17, finance_19, finance_21, finance_22, finance_23, housing_01, housing_02, housing_03, housing_04, housing_06, housing_09, housing_10, housing_17, housing_17, housing_19, travel_01, travel_03, travel_03, travel_05, travel_07, travel_07, travel_08, travel_10, travel_11, travel_14, travel_16, travel_18, travel_21, travel_21, travel_23, travel_23, travel_24
