# Run digest: 20261003_180457

- Scenarios scored: 100  passed: 74  failed: 26  strict pass rate: 0.74
- Janus commit: `e296c8561347df6c90319ed8191d8a83ef775e75`  FDB commit: `3e799c45a045256f47d5f1c9cda90157e2d2ec9e`
- Judge: on (FDB --use-llm)
- Tool metrics: {"tool_selection_acc": 0.959, "argument_acc": 0.78, "response_qual": 0.72, "tool_selection_acc_all": 0.959, "argument_acc_all": 0.78, "note": "*_all includes no-response samples (scored 0); default metrics are turn-taken only"}
- Turn-taking: {"total": 100, "turn_taken": 100, "no_response": 0, "turn_take_rate": 1.0}  Latency: {"total_samples": 100, "interruption_count": 0, "interruption_rate": 0.0, "avg_response_latency_s": 8.521, "std_response_latency_s": 4.154, "min_latency_s": 3.52, "max_latency_s": 29.2, "note": "avg/std/min/max exclude interruption samples; computed on turn-taken samples only"}
- by_domain: {"ecommerce_support": 0.793, "finance_billing": 0.96, "housing_location": 0.385, "travel_identity": 0.85}
- by_difficulty: {"easy": 0.806, "medium": 0.735, "hard": 0.667}
- by_num_tools: {"1": 0.773, "2": 0.722, "3": 0.625}
- by_disfluency_feature: {"PAUSE": 0.611, "FILLER": 0.793, "HESITATION": 0.7, "FALSE_START": 0.667, "SELF_CORRECTION": 0.765}
- by_state_rollback: {"with_rollback": 0.765, "without_rollback": 0.735}
- failure_breakdown: {"wrong_tools": 7, "wrong_arguments": 19}
- Recordings re-streamed after a client abort: 0

## Agent log: top errors (de-duplicated)
- 42x ERROR:livekit:livekit::rtc_engine::rtc_session:#:livekit::rtc_engine::rtc_session - publisher data channel '_reliable' closed unexpectedly
- 38x ERROR:livekit:livekit::rtc_engine::rtc_session:#:livekit::rtc_engine::rtc_session - publisher data channel '_lossy' closed unexpectedly
- 38x ERROR:livekit:livekit::rtc_engine::rtc_session:#:livekit::rtc_engine::rtc_session - publisher data channel '_data_track' closed unexpectedly

## Failures by guessed cause (26 total)
- wrong_args: 16
- wrong_tools: 4
- silent: 3
- stt: 2
- split_turn: 1

## Failing recordings

### ecommerce_08  [ecommerce_support, easy, PAUSE]  cause guess: wrong_args: search_products
- reason: Wrong arguments for: ['search_products']
- expected tools: ['search_products']  actual: ['search_products']
- wrong arguments:
    search_products: expected {'query': 'mechanical keyboards', 'max_price': 200} got {'query': 'mechanical keyboard', 'max_price': 200} (The query argument 'mechanical keyboard' does not match the expected 'mechanical keyboards'.)
- reference transcript: Ah, hmm. You know, um, I want a mechanical keyboard and I'm trying, um, to keep my budget under two hundred dollars. Do you have anything like that?
- agent heard (1 turn end(s)): You know, um... I want a mechanical keyboard, and I'm trying to keep my budget under... Two hundred dollars? Do you have anything like that?
- agent said: [speak] I'll search for mechanical keyboards under $200. | [final] I found the mechanical keyboard Premium priced at $190.
- calls emitted (wire): search_products(query='mechanical keyboard', max_price=200)
- calls recorded by the benchmark: search_products(query='mechanical keyboard', max_price=200)
- latency: {'input_duration_s': 45.78, 'output_duration_s': 45.78, 'first_speech_s': 20.05}
- kernel: 14 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-1203252c.jsonl
### ecommerce_08  [ecommerce_support, easy, PAUSE]  cause guess: wrong_args: search_products
- reason: Wrong arguments for: ['search_products']
- expected tools: ['search_products']  actual: ['search_products']
- wrong arguments:
    search_products: expected {'query': 'mechanical keyboards', 'max_price': 200} got {'query': 'mechanical keyboard', 'max_price': 200} (The 'query' argument is 'mechanical keyboard' instead of 'mechanical keyboards', which is not a minor formatting differ…)
- reference transcript: Um, yeah, you know, uh, I want a mechanical keyboard, and I'm trying to keep my budget under $200. Do you have anything like that?
- agent heard (1 turn end(s)): Yeah, you know, uh... I want a mechanical keyboard, and I'm trying to keep my budget under $200. Do you have anything like that?
- agent said: [speak] I'll search for mechanical keyboards under $200. | [final] I searched for mechanical keyboards under 200 dollars and found the mechanical keyboard Premium for 190 dollars.
- calls emitted (wire): search_products(query='mechanical keyboard', max_price=200)
- calls recorded by the benchmark: search_products(query='mechanical keyboard', max_price=200)
- latency: {'input_duration_s': 43.44, 'output_duration_s': 43.44, 'first_speech_s': 19.8}
- kernel: 16 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-6149ecf3.jsonl
### ecommerce_12  [ecommerce_support, medium, HESITATION,PAUSE]  cause guess: stt: the agent heard a different sentence (76% word overlap with the reference transcript)
- reason: Wrong arguments for: ['search_products']
- expected tools: ['search_products']  actual: ['search_products']
- wrong arguments:
    search_products: expected {'query': 'gift', 'category': 'electronics'} got {'query': 'electronics'} (The actual arguments are missing the 'category' argument and the 'query' argument value is incorrect.)
- reference transcript: Like, you know, um, I'm thinking something in the let me think electronics section of the grid. He's really into gadgets and text stuff.
- agent heard (1 turn end(s)): Like, you know, I'm thinking something that, let me think, electronics section would be great. He's really into gadgets and tech stuff.
- agent said: [speak] I'll search for products in the electronics section. | [final] I searched for electronics and found electronics Premium priced at $99.99 with the product ID PROD1.
- calls emitted (wire): search_products(query='electronics')
- calls recorded by the benchmark: search_products(query='electronics')
- latency: {'input_duration_s': 41.264, 'output_duration_s': 41.264, 'first_speech_s': 16.75}
- kernel: 12 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-c0dc28ab.jsonl
### ecommerce_14  [ecommerce_support, medium, FILLER]  cause guess: wrong_args: add_to_cart
- reason: Wrong arguments for: ['add_to_cart']
- expected tools: ['add_to_cart']  actual: ['add_to_cart']
- wrong arguments:
    add_to_cart: expected {'product_id': 'P52', 'quantity': 2} got {'product_id': 'avitum. P52', 'quantity': 2} (The actual 'product_id' argument contains an unexpected prefix 'avitum. ', which does not match the expected 'product_i…)
- reference transcript: Um well yeah, so um yeah, so I already found what I want. Can you add like two of item uh P52 to my card? I want to get one for myself and one as a gift.
- agent heard (1 turn end(s)): Well, yeah, so, um... Yeah, so I already found what I want. Can you add, like... To avitum. P52 to my cart. I wanna get one for myself and one as a gift.
- agent said: [speak] I'll add 2 of product avitum. P52 to your cart. | [final] I have added two of the avitum. P52 to your cart, bringing your total to 199.98.
- calls emitted (wire): add_to_cart(product_id='avitum. P52', quantity=2)
- calls recorded by the benchmark: add_to_cart(product_id='avitum. P52', quantity=2)
- latency: {'input_duration_s': 51.24, 'output_duration_s': 51.24, 'first_speech_s': 28.75}
- kernel: 22 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {'G10:add_to_cart': 1}
- decision log: decisions/eval-bee8997f.jsonl
### ecommerce_20  [ecommerce_support, hard, no disfluency]  cause guess: wrong_tools: missing [] unexpected ['track_order']
- reason: Unexpected tools: ['track_order']
- expected tools: ['search_products', 'add_to_cart']  actual: ['search_products', 'add_to_cart', 'track_order']
- reference transcript: So, you know, so search for a coffee maker first. If you find one that's under $50, go ahead and add two to the cart because they make great gifts. But if everything's over $50, I'd just forget the coffee maker and track order WWW for me instead.
- agent heard (1 turn end(s)): So, um, you know, I... So search for a coffee maker first. If you find one that's under $50, go ahead and add two to the cart because they make great gifts. But if everything's over $50, I'd just forget the coffee maker and track order www for me instead.
- agent said: [speak] I'll search for a coffee maker, add two to the cart if one is under $50, or track order www if they are over $50. | [final] I found the coffee maker Premium priced at $99.99 and added 2 of them to your cart for a total of $199.98. Additionally, your order www is currently out for delivery.
- calls emitted (wire): search_products(query='coffee maker'); add_to_cart(product_id='PROD1', quantity=2); track_order(order_id='www')
- calls recorded by the benchmark: search_products(query='coffee maker'); add_to_cart(product_id='PROD1', quantity=2); track_order(order_id='www')
- latency: {'input_duration_s': 54.629, 'output_duration_s': 54.629, 'first_speech_s': 32.25}
- kernel: 17 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 3, 'final': 1}; gate holds {'G10:search_products': 1}
- decision log: decisions/eval-0e9204e8.jsonl
### ecommerce_25  [ecommerce_support, hard, FALSE_START]  cause guess: split_turn: the user's request closed 2 turns
- reason: Wrong arguments for: ['track_order']
- expected tools: ['track_order', 'search_products', 'add_to_cart']  actual: ['track_order', 'search_products', 'add_to_cart']
- wrong arguments:
    track_order: expected {'order_id': 'CAT'} got {'order_id': 'ZAT'} (The actual argument 'order_id' is 'ZAT', which does not match the expected 'CAT'.)
- reference transcript: You know, um, well, can um I return my never mind, uh, forget the return. Let me focus on what I actually need. Track order CAT for me, then search for cat food because I'm running low and add three of whatever you find to my card.
- agent heard (2 turn end(s)): Can we go? I returned my... Never mind, forget the return. Let me focus on what I actually need. Track order ZAT for me. Then search for cat food because I'm running low. And add three of whatever you find to my cart.
- agent said: [speak] I'll track order ZAT, search for cat food, and add three of the results to your cart. | [final] Your order ZAT is currently out for delivery. I have also added 3 units of cat food Premium to your cart for a total of 299.97.
- calls emitted (wire): track_order(order_id='ZAT'); search_products(query='cat food'); add_to_cart(product_id='PROD1', quantity=3)
- calls recorded by the benchmark: track_order(order_id='ZAT'); search_products(query='cat food'); add_to_cart(product_id='PROD1', quantity=3)
- latency: {'input_duration_s': 53.7, 'output_duration_s': 53.7, 'first_speech_s': 28.0}
- kernel: 31 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 3, 'final': 1}; gate holds {}
- decision log: decisions/eval-4a66c6e2.jsonl
### finance_10  [finance_billing, medium, no disfluency]  cause guess: wrong_args: get_card_benefits
- reason: Wrong arguments for: ['get_card_benefits']
- expected tools: ['get_card_benefits', 'get_exchange_rate']  actual: ['get_card_benefits', 'get_exchange_rate']
- wrong arguments:
    get_card_benefits: expected {'card_type': 'travel'} got {'card_type': 'travel card'} (The expected argument is 'travel', but the actual argument provided is 'travel card', which is not a minor formatting d…)
- reference transcript: Firstly, could you tell me what the benefits are for the travel card? I'm considering applying and then separately, I also need to know how much 200 British pounds would be in Japanese yen.
- agent heard (1 turn end(s)): Firstly, could you tell me what the benefits are for the travel card? I'm considering applying, and then separately, I also need to know how much 200 British pounds would be in Japanese yen.
- agent said: [speak] I'll check the travel card benefits and convert 200 GBP to JPY for you. | [final] The travel card offers 2% cashback and no foreign transaction fees, and converting 200 GBP to JPY results in 180 JPY at an exchange rate of 0.9.
- calls emitted (wire): get_card_benefits(card_type='travel card'); get_exchange_rate(amount=200, from_currency='GBP', to_currency='JPY')
- calls recorded by the benchmark: get_card_benefits(card_type='travel card'); get_exchange_rate(amount=200, from_currency='GBP', to_currency='JPY')
- latency: {'input_duration_s': 46.331, 'output_duration_s': 46.331, 'first_speech_s': 22.35}
- kernel: 15 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 2, 'final': 1}; gate holds {}
- decision log: decisions/eval-3ba5b5c5.jsonl
### housing_05  [housing_location, easy, HESITATION,PAUSE]  cause guess: wrong_args: search_apartments
- reason: Wrong arguments for: ['search_apartments']
- expected tools: ['search_apartments']  actual: ['search_apartments']
- wrong arguments:
    search_apartments: expected {'city': 'Miami', 'max_price': 1500, 'pets_allowed': True} got {'city': 'Miami', 'bedrooms': 1, 'max_price': 1500} (The actual arguments are missing 'pets_allowed' and include an unexpected 'bedrooms' argument.)
- reference transcript: You know, you know, you know, well, I need um a pet-friendly apartment in Miami, and my budget is about let me check fifteen hundred a month. Is there anything in that range?
- agent heard (1 turn end(s)): You know? You know, you know well I need a pet-friendly apartment in Miami, and my budget is about, let me check. Fifteen hundred a month. Is there anything in that range?
- agent said: [speak] I'll search for pet-friendly apartments in Miami with a maximum price of 1500 a month, assuming 1 bedroom. | [final] I found a one bedroom apartment in Miami priced at 1400 dollars per month with the ID APT1.
- calls emitted (wire): search_apartments(city='Miami', bedrooms=1, max_price=1500)
- calls recorded by the benchmark: search_apartments(city='Miami', bedrooms=1, max_price=1500)
- latency: {'input_duration_s': 48.9, 'output_duration_s': 48.9, 'first_speech_s': 28.4}
- kernel: 17 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-00a8cd7f.jsonl
### housing_05  [housing_location, easy, HESITATION,PAUSE]  cause guess: wrong_args: search_apartments
- reason: Wrong arguments for: ['search_apartments']
- expected tools: ['search_apartments']  actual: ['search_apartments']
- wrong arguments:
    search_apartments: expected {'city': 'Miami', 'max_price': 1500, 'pets_allowed': True} got {'city': 'Miami', 'max_price': 1500, 'bedrooms': 1} (The actual arguments are missing 'pets_allowed' and include an unexpected 'bedrooms' argument.)
- reference transcript: You know, um, you know, well, I need um a pet-friendly apartment in Miami, and my budget is about uh let me check. It's uh it's about fifteen hundred a month. Is there anything in that range?
- agent heard (1 turn end(s)): You know, um... You know... Well, I need a pet-friendly apartment in Miami, and my budget is about... Let me check, it's... It's about fifteen hundred. Month Is there anything in that range?
- agent said: [speak] I'll search for pet-friendly apartments in Miami with a budget of 1500, assuming 1 bedroom. | [final] I found a one bedroom apartment in Miami, listing ID APT1, priced at 1400 dollars per month.
- calls emitted (wire): search_apartments(city='Miami', max_price=1500, bedrooms=1)
- calls recorded by the benchmark: search_apartments(city='Miami', max_price=1500, bedrooms=1)
- latency: {'input_duration_s': 50.1, 'output_duration_s': 50.1, 'first_speech_s': 31.35}
- kernel: 29 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {'G10:search_apartments': 1}
- decision log: decisions/eval-4ab823c6.jsonl
### housing_08  [housing_location, easy, FALSE_START]  cause guess: wrong_args: update_search_filter
- reason: Wrong arguments for: ['update_search_filter']
- expected tools: ['update_search_filter']  actual: ['update_search_filter']
- wrong arguments:
    update_search_filter: expected {'filter_name': 'pets_allowed', 'value': True} got {'filter_name': 'pets_allowed', 'value': 'true'} (The expected argument for 'value' is a boolean (true), but the actual argument is a string ('true').)
- reference transcript: Okay, so um I want to check the listings in. Actually, before before I do that, could you just update my search filter so that it only shows me places that allow pets? I have a cat.
- agent heard (1 turn end(s)): I wanna check the listings and actually, before I do that, could you just update my search filters so that it only shows me places that allow pets? I have a cat.
- agent said: [speak] I'll update your search filter to allow pets and then search for apartments. | [clarify] I need a bit more information — what should city be?
- calls emitted (wire): update_search_filter(filter_name='pets_allowed', value='true')
- calls recorded by the benchmark: update_search_filter(filter_name='pets_allowed', value='true')
- latency: {'input_duration_s': 45.72, 'output_duration_s': 45.72, 'first_speech_s': 23.35}
- kernel: 12 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'clarify': 1}; gate holds {}
- decision log: decisions/eval-3a330b04.jsonl
### housing_11  [housing_location, medium, SELF_CORRECTION]  cause guess: silent: the agent made no calls
- reason: Missing tools: ['search_apartments']
- expected tools: ['search_apartments']  actual: []
- reference transcript: Uh well, I was thinking a one bedroom under twelve well actually no wait, my partner is moving in with me, so we need a two bedroom and we can go up uh uh up to sixteen hundred a month.
- agent heard (1 turn end(s)): I was thinking a one-bedroom under 12. Well, actually, no, wait, my partner is moving in with me, so we need a two-bedroom, and we need to go up to $1,600 a month.
- agent said: [speak] I'll search for two-bedroom apartments with a maximum rent of $1,600. | [clarify] I need a bit more information — what should city be?
- calls emitted (wire): none
- calls recorded by the benchmark: none
- latency: {'input_duration_s': 41.46, 'output_duration_s': 41.46, 'first_speech_s': 22.85}
- kernel: 10 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'clarify': 1}; gate holds {}
- decision log: decisions/eval-cf0ad310.jsonl
### housing_13  [housing_location, medium, no disfluency]  cause guess: silent: the agent made no calls
- reason: Missing tools: ['update_search_filter', 'update_search_filter']
- expected tools: ['update_search_filter', 'update_search_filter']  actual: []
- reference transcript: You know, like, you know, let's raise the max price to three thousand per month and also bump up the minimum bedrooms to three. Yeah, I think I need more space than I originally thought.
- agent heard (1 turn end(s)): You know, like, you know, let's raise the max price to $3,000 per month. And also bump up the minimum bedrooms to three. Yeah, I think I needed more space than I originally thought.
- agent said: [speak] I'll search for 3-bedroom apartments with a maximum price of $3,000 per month. | [clarify] I need a bit more information — what should city be?
- calls emitted (wire): none
- calls recorded by the benchmark: none
- latency: {'input_duration_s': 48.507, 'output_duration_s': 48.507, 'first_speech_s': 24.45}
- kernel: 12 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'clarify': 1}; gate holds {}
- decision log: decisions/eval-b77dcd31.jsonl
### housing_14  [housing_location, medium, FILLER]  cause guess: wrong_args: search_apartments
- reason: Wrong arguments for: ['search_apartments']
- expected tools: ['search_apartments']  actual: ['search_apartments']
- wrong arguments:
    search_apartments: expected {'city': 'Portland', 'bedrooms': 1, 'max_price': 1800, 'pets_allowed': True} got {'city': 'Portland', 'bedrooms': 1, 'max_price': 1800} (The 'pets_allowed' argument is missing in the actual arguments.)
- reference transcript: Like, you know, um, so um, I'm looking for like a one-bedroom apartment in Portland, and I'd want to keep the rent under 1,800. Oh, and it needs to be uh pet-friendly because um I have a dog.
- agent heard (1 turn end(s)): Like, you know, um, so, um... I'm looking for, like, a one-bedroom apartment in Portland, and I'd want to keep the rent under $1,800. Oh, and it needs to be pet-friendly, because I have a dog.
- agent said: [speak] I'll search for one-bedroom apartments in Portland with rent under $1,800. I can't do "filter for pet-friendly apartments" here, though. | [final] I found a one-bedroom apartment in Portland listed at $1,700 per month, with the ID APT1.
- calls emitted (wire): search_apartments(city='Portland', bedrooms=1, max_price=1800)
- calls recorded by the benchmark: search_apartments(city='Portland', bedrooms=1, max_price=1800)
- latency: {'input_duration_s': 48.36, 'output_duration_s': 48.36, 'first_speech_s': 26.55}
- kernel: 15 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-5386457a.jsonl
### housing_14  [housing_location, medium, FILLER]  cause guess: wrong_args: search_apartments
- reason: Wrong arguments for: ['search_apartments']
- expected tools: ['search_apartments']  actual: ['search_apartments']
- wrong arguments:
    search_apartments: expected {'city': 'Portland', 'bedrooms': 1, 'max_price': 1800, 'pets_allowed': True} got {'city': 'Portland', 'bedrooms': 1, 'max_price': 1800} (The 'pets_allowed' argument is missing in the actual arguments.)
- reference transcript: Like, you know, so um, I'm looking for like a one-bedroom apartment in Portland and I'd want to keep the rent under $1,800. Oh, well, and oh, and it needs to be uh pet-friendly because uh I have a dog.
- agent heard (1 turn end(s)): Like, you know... So, um, I'm looking for like a one-bedroom apartment in Portland. And I wanna keep the rent under $1,800, so, well, and it needs to be a pet-friendly, because... I have a dog.
- agent said: [speak] I'll search for one-bedroom apartments in Portland with rent under $1,800. I can't do "filter for pet-friendly apartments" here, though. | [final] I found a one bedroom apartment in Portland, listing ID APT1, priced at 1700 dollars.
- calls emitted (wire): search_apartments(city='Portland', bedrooms=1, max_price=1800)
- calls recorded by the benchmark: search_apartments(city='Portland', bedrooms=1, max_price=1800)
- latency: {'input_duration_s': 51.3, 'output_duration_s': 51.3, 'first_speech_s': 31.8}
- kernel: 20 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {'G10:search_apartments': 1}
- decision log: decisions/eval-88e3d99b.jsonl
### housing_15  [housing_location, medium, FALSE_START]  cause guess: wrong_args: search_apartments
- reason: Wrong arguments for: ['search_apartments']
- expected tools: ['search_apartments']  actual: ['search_apartments']
- wrong arguments:
    search_apartments: expected {'city': 'Atlanta', 'bedrooms': 3, 'pets_allowed': True} got {'city': 'Atlanta', 'bedrooms': 3, 'max_price': 10000} (The actual arguments are missing 'pets_allowed' and include an unexpected 'max_price' argument.)
- reference transcript: Um so hmm uh I wanted um to check the commute from that one listing. Actually let me skip that for now. Could you just search for a three-bedroom in Atlanta that's pet-friendly? I've got two cats.
- agent heard (1 turn end(s)): I want... I wanted to check the commute from that one listing. Actually, let me skip that for now. Could you just search for a three-bedroom in Atlanta that's pet-friendly? I've got two cats.
- agent said: [speak] I'll search for 3-bedroom apartments in Atlanta, assuming a high budget limit. | [final] I searched for three bedroom apartments in Atlanta under 10000 dollars and found apartment APT1 priced at 9900 dollars.
- calls emitted (wire): search_apartments(city='Atlanta', bedrooms=3, max_price=10000)
- calls recorded by the benchmark: search_apartments(city='Atlanta', bedrooms=3, max_price=10000)
- latency: {'input_duration_s': 48.42, 'output_duration_s': 48.42, 'first_speech_s': 29.85}
- kernel: 13 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-dd1136a8.jsonl
### housing_15  [housing_location, medium, FALSE_START]  cause guess: wrong_args: search_apartments
- reason: Wrong arguments for: ['search_apartments']
- expected tools: ['search_apartments']  actual: ['search_apartments']
- wrong arguments:
    search_apartments: expected {'city': 'Atlanta', 'bedrooms': 3, 'pets_allowed': True} got {'city': 'Atlanta', 'bedrooms': 3, 'max_price': 10000} (The actual arguments are missing 'pets_allowed' and include an unexpected 'max_price' argument.)
- reference transcript: Um, so um uh I wanted to I wanted to check the commute from that one listing. Actually, let me skip that for now. Could you just search for a three-bedroom in Atlanta that's pet-friendly? I um I've got two cats too.
- agent heard (1 turn end(s)): I wanted to check the commute from that one listing. Actually, let me skip that for now. Could you just search for a three-bedroom in Atlanta? that's pet-friendly. I've got two cats, too.
- agent said: [speak] I'll search for a three-bedroom apartment in Atlanta, assuming a max price budget. I can't do "pet-friendly filter" here, though. | [final] I found a three bedroom apartment in Atlanta for 9900 dollars with the ID APT1.
- calls emitted (wire): search_apartments(city='Atlanta', bedrooms=3, max_price=10000)
- calls recorded by the benchmark: search_apartments(city='Atlanta', bedrooms=3, max_price=10000)
- latency: {'input_duration_s': 50.52, 'output_duration_s': 50.52, 'first_speech_s': 35.3}
- kernel: 18 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {'G3:search_apartments': 2, 'G10:search_apartments': 1}
- decision log: decisions/eval-869f2ffb.jsonl
### housing_18  [housing_location, hard, no disfluency]  cause guess: wrong_args: search_apartments
- reason: Wrong arguments for: ['search_apartments']
- expected tools: ['search_apartments', 'calculate_commute']  actual: ['search_apartments', 'calculate_commute']
- wrong arguments:
    search_apartments: expected {'city': 'Portland', 'bedrooms': 1, 'max_price': 1800} got {'city': 'Portland', 'bedrooms': 1, 'max_price': 800} (The 'max_price' argument is outside the acceptable numeric tolerance range of ±5%.)
- reference transcript: Well so first, search for a one-bedroom in Portland that's under $800 per month, then once you find the cheapest option, check how long it would take to bike from there to the coffee shop on 5th Street where I work.
- agent heard (1 turn end(s)): Well, so search for a One bed. I'm in Portland that's under $800 a month, then once I find the cheapest option, check how long it would take to bike from there to the coffee shop on 5th Street where I work.
- agent said: [speak] I'll search for 1-bedroom apartments in Portland under $800 a month, and then calculate the biking commute time from the cheapest option to the coffee shop on 5th Street. | [final] I found a one bedroom apartment in Portland listed for 700 dollars per month, and the biking commute to the coffee shop on 5th Street takes 25 minutes.
- calls emitted (wire): search_apartments(city='Portland', bedrooms=1, max_price=800); calculate_commute(origin_address='APT1', destination_address='the coffee shop on 5th Street', mode='biking')
- calls recorded by the benchmark: search_apartments(city='Portland', bedrooms=1, max_price=800); calculate_commute(origin_address='APT1', destination_address='the coffee shop on 5th Street', mode='biking')
- latency: {'input_duration_s': 47.685, 'output_duration_s': 47.685, 'first_speech_s': 33.85}
- kernel: 18 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 2, 'final': 1}; gate holds {}
- decision log: decisions/eval-bb68b1cc.jsonl
### housing_20  [housing_location, hard, no disfluency]  cause guess: wrong_args: search_apartments
- reason: Wrong arguments for: ['search_apartments']
- expected tools: ['search_apartments', 'calculate_commute', 'update_search_filter']  actual: ['search_apartments', 'calculate_commute', 'update_search_filter']
- wrong arguments:
    search_apartments: expected {'city': 'Austin', 'max_price': 2000} got {'city': 'Austin', 'max_price': 2000, 'bedrooms': 1} (The actual arguments include an extra 'bedrooms' parameter which is not expected.)
- reference transcript: Uh you know so here's what I'm thinking. Search for places in Austin under 2,000. Then check the commute to my office. If it's under 15 minutes, that's perfect. But if it's longer then raise my budget to 2,500 so uh I can look at places closer to work.
- agent heard (1 turn end(s)): You know... So here's what I'm thinking. Search for places in Austin under $2,000, then check the commute to my office. If it's under 15 minutes, that's perfect. But if it's longer, then raise my budget to $2,500 so I can look at places closer to work.
- agent said: [speak] I'll search for 1-bedroom apartments in Austin under $2,000, assuming 1 bedroom, check the commute to your office, and raise the budget filter to $2,500 if needed. | [final] I searched for one-bedroom apartments in Austin and found property APT1 priced at $1,900 per month, which has a 25-minute driving commute to your office. I also updated your search filter to set the maximum price to $2,500.
- calls emitted (wire): search_apartments(city='Austin', max_price=2000, bedrooms=1); calculate_commute(origin_address='APT1', destination_address='my office'); update_search_filter(filter_name='max_price', value='2500')
- calls recorded by the benchmark: search_apartments(city='Austin', max_price=2000, bedrooms=1); calculate_commute(origin_address='APT1', destination_address='my office', mode='driving'); update_search_filter(filter_name='max_price', value='2500')
- latency: {'input_duration_s': 47.46, 'output_duration_s': 47.46, 'first_speech_s': 29.1}
- kernel: 18 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 3, 'final': 1}; gate holds {}
- decision log: decisions/eval-c741d1dc.jsonl
### housing_21  [housing_location, hard, SELF_CORRECTION]  cause guess: silent: the agent made no calls
- reason: Missing tools: ['search_apartments', 'calculate_commute']
- expected tools: ['search_apartments', 'calculate_commute']  actual: []
- reference transcript: So well, so you know I want to search for a place with two bedrooms. Wait, actually, I mean, I meant three bedrooms. We decided we need a home office. Also, check the transit time to the train station. Actually, I'd rather walk, so make that walk-in time.
- agent heard (1 turn end(s)): So, well, so you know, I want to search for a place with two bedrooms. Wait, actually, I mean, I meant three bedrooms. We decided we need a home office. Also, check the transit time to the... The train station is actually I'd rather walk, so make that walking time.
- agent said: [speak] I'll search for 3-bedroom apartments and calculate the walking commute time to the train station. | [clarify] I need a bit more information — what should city be?
- calls emitted (wire): none
- calls recorded by the benchmark: none
- latency: {'input_duration_s': 49.725, 'output_duration_s': 49.725, 'first_speech_s': 30.5}
- kernel: 12 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'clarify': 1}; gate holds {}
- decision log: decisions/eval-f5e3d5b9.jsonl
### housing_22  [housing_location, hard, FILLER]  cause guess: wrong_args: update_search_filter
- reason: Wrong arguments for: ['update_search_filter', 'search_apartments']
- expected tools: ['update_search_filter', 'search_apartments', 'calculate_commute']  actual: ['update_search_filter', 'search_apartments', 'calculate_commute']
- wrong arguments:
    update_search_filter: expected {'filter_name': 'pets_allowed', 'value': True} got {'filter_name': 'pets_allowed', 'value': 'true'} (The expected argument for 'value' is a boolean true, but the actual argument is a string 'true'.)
    search_apartments: expected {'city': 'Seattle', 'bedrooms': 1} got {'city': 'Seattle', 'bedrooms': 1, 'max_price': 10000} (The actual arguments include an extra argument 'max_price' which is not expected.)
- reference transcript: You know, um, can you first update my filter so pets are allowed? Um, I keep forgetting to set that. Then, like, search in Seattle for one bedroom. And then once you find something, uh, check the transit time from there to the stadium because, you know, I go to games pretty often.
- agent heard (1 turn end(s)): Um, can you first update my filters so pets are allowed? Um, I keep forgetting to set that. Then like search in Seattle for one bedroom. And then once you find something, check the transit time from there to the stadium, because, you know, I go to games pretty often.
- agent said: [speak] I'll update your filter to allow pets, search for a one-bedroom apartment in Seattle, and calculate the transit time from there to the stadium. | [final] I updated your search filter to allow pets and found a one bedroom apartment in Seattle with ID APT1 for 9,900 dollars. The transit commute from APT1 to the stadium is estimated at 25 minutes.
- calls emitted (wire): update_search_filter(filter_name='pets_allowed', value='true'); search_apartments(city='Seattle', bedrooms=1, max_price=10000); calculate_commute(origin_address='APT1', destination_address='stadium', mode='transit')
- calls recorded by the benchmark: update_search_filter(filter_name='pets_allowed', value='true'); search_apartments(city='Seattle', bedrooms=1, max_price=10000); calculate_commute(origin_address='APT1', destination_address='stadium', mode='transit')
- latency: {'input_duration_s': 50.1, 'output_duration_s': 50.1, 'first_speech_s': 28.6}
- kernel: 21 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 3, 'final': 1}; gate holds {}
- decision log: decisions/eval-368b5d28.jsonl
### housing_24  [housing_location, hard, PAUSE,FILLER]  cause guess: wrong_tools: missing ['update_search_filter'] unexpected []
- reason: Missing tools: ['update_search_filter']
- expected tools: ['update_search_filter', 'search_apartments', 'calculate_commute']  actual: ['search_apartments', 'calculate_commute']
- reference transcript: Um, so hmm, like, you know, okay. So, first, um, I want to update my max price to $1,500 because I'm on a tighter budget. Then, uh, search for apartments in Dallas that fit that budget, and then check the walking time from whatever you find to the grocery store because I want to be close to one.
- agent heard (1 turn end(s)): Like, you know. OK, so first, um... I want to update my max price to $1500 because I'm on a tighter budget, then search for apartments in Dallas that fit that budget, and then... Check the walking time from whatever you find to the grocery store because I want it to be close to one.
- agent said: [speak] I'll search for 1-bedroom apartments in Dallas with a maximum price of $1500, assuming 1 bedroom, and calculate the walking commute to the nearest grocery store. | [final] I found a one-bedroom apartment in Dallas, APT1, listed at 1400 dollars. The walking commute from APT1 to the grocery store takes 25 minutes.
- calls emitted (wire): search_apartments(city='Dallas', max_price=1500, bedrooms=1); calculate_commute(origin_address='APT1', destination_address='grocery store', mode='walking')
- calls recorded by the benchmark: search_apartments(city='Dallas', max_price=1500, bedrooms=1); calculate_commute(origin_address='APT1', destination_address='grocery store', mode='walking')
- latency: {'input_duration_s': 56.1, 'output_duration_s': 56.1, 'first_speech_s': 36.5}
- kernel: 20 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 2, 'final': 1}; gate holds {}
- decision log: decisions/eval-cc422e1d.jsonl
### housing_24  [housing_location, hard, PAUSE,FILLER]  cause guess: wrong_tools: missing ['update_search_filter'] unexpected []
- reason: Missing tools: ['update_search_filter']
- expected tools: ['update_search_filter', 'search_apartments', 'calculate_commute']  actual: ['search_apartments', 'calculate_commute']
- reference transcript: Um so hmm like you know okay so first um I want to update my max price to 1500 because I'm on a tighter budget then uh search for apartments in Dallas that fit that budget and then check the walking time from whatever you find to the grocery store because I want to be close to one
- agent heard (1 turn end(s)): Like, you know, okay. So first, I want to update my max price to $1500. Because I'm on a tighter budget. Then, uh, search for apartments in Dallas that fit that budget. And then... Check the walking time from wherever you find to the grocery store because I wanna be close to one.
- agent said: [speak] I'll search for 1-bedroom apartments in Dallas under $1500, assuming 1 bedroom, and calculate the walking commute to the nearest grocery store. | [final] I found a one bedroom apartment in Dallas, ID APT1, priced at 1400 dollars. The walking commute from APT1 to the grocery store takes 25 minutes.
- calls emitted (wire): search_apartments(max_price=1500, city='Dallas', bedrooms=1); calculate_commute(origin_address='APT1', destination_address='grocery store', mode='walking')
- calls recorded by the benchmark: search_apartments(max_price=1500, city='Dallas', bedrooms=1); calculate_commute(origin_address='APT1', destination_address='grocery store', mode='walking')
- latency: {'input_duration_s': 59.16, 'output_duration_s': 59.16, 'first_speech_s': 37.4}
- kernel: 24 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 2, 'final': 1}; gate holds {}
- decision log: decisions/eval-1eac2a02.jsonl
### housing_25  [housing_location, hard, SELF_CORRECTION]  cause guess: wrong_tools: missing ['update_search_filter', 'update_search_filter'] unexpected []
- reason: Missing tools: ['update_search_filter', 'update_search_filter']
- expected tools: ['update_search_filter', 'update_search_filter', 'search_apartments']  actual: ['search_apartments']
- reference transcript: You know, you know, alright, first set the filter so pets are allowed and set the max price to 3,000. Then search for places in San Francisco. Wait, actually change the max price to 3500 instead. San Francisco is expensive, so I need more room in the budget.
- agent heard (1 turn end(s)): You know, you know, all right. First set the filters so pets are allowed, and set the max price to $3000. Then search for places in San Francisco. Cisco, wait, actually, change the max price to $3500 instead. San Francisco is expensive, so I need more room in the budget.
- agent said: [speak] I'll search for places in San Francisco with a max price of $3500, assuming 1 bedroom. | [final] I found a one bedroom apartment in San Francisco, APT1, listed for 3,400 dollars per month.
- calls emitted (wire): search_apartments(city='San Francisco', bedrooms=1, max_price=3500)
- calls recorded by the benchmark: search_apartments(city='San Francisco', bedrooms=1, max_price=3500)
- latency: {'input_duration_s': 51.48, 'output_duration_s': 51.48, 'first_speech_s': 34.7}
- kernel: 17 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-48f10201.jsonl
### travel_02  [travel_identity, easy, no disfluency]  cause guess: stt: the agent heard a different sentence (74% word overlap with the reference transcript)
- reason: Wrong arguments for: ['update_identity_doc']
- expected tools: ['update_identity_doc']  actual: ['update_identity_doc']
- wrong arguments:
    update_identity_doc: expected {'doc_type': 'passport', 'doc_number': 'P9-9-9-90011'} got {'doc_type': 'passport', 'doc_number': 'P88990011'} (The doc_number 'P88990011' does not match the expected format 'P9-9-9-90011' and is not within a 5% numeric tolerance.)
- reference transcript: Uh, yeah, so my new passport number is P eight eight nine nine zero zero one one. Could you update that in the system for me, please?
- agent heard (1 turn end(s)): Yeah, so my new passport number is P88990011. Could you update that in the system for me, please?
- agent said: [speak] I'll update your passport number to P88990011 in the system. | [final] Your passport number has been updated to ending in 0011.
- calls emitted (wire): update_identity_doc(doc_type='passport', doc_number='P88990011')
- calls recorded by the benchmark: update_identity_doc(doc_type='passport', doc_number='P88990011')
- latency: {'input_duration_s': 44.52, 'output_duration_s': 44.52, 'first_speech_s': 21.8}
- kernel: 13 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-b08ea106.jsonl
### travel_07  [travel_identity, easy, no disfluency]  cause guess: wrong_args: update_identity_doc
- reason: Wrong arguments for: ['update_identity_doc']
- expected tools: ['update_identity_doc']  actual: ['update_identity_doc']
- wrong arguments:
    update_identity_doc: expected {'doc_type': 'driver_license', 'doc_number': 'DL555'} got {'doc_type': 'drivers_license', 'doc_number': 'DL555'} (The actual argument 'drivers_license' does not match the expected 'driver_license' due to an extra 's'.)
- reference transcript: Um, the new driver's license number is DL555. Could you swap out the old one and put this new one in there?
- agent heard (1 turn end(s)): The new driver's license number is DL. five five five Could you swap out the old one and put this new one in there?
- agent said: [speak] I'll update your driver's license number to DL. five five five. | [final] Your driver's license number has been updated to L555.
- calls emitted (wire): update_identity_doc(doc_type='drivers_license', doc_number='DL555')
- calls recorded by the benchmark: update_identity_doc(doc_type='drivers_license', doc_number='DL555')
- latency: {'input_duration_s': 41.82, 'output_duration_s': 41.82, 'first_speech_s': 17.5}
- kernel: 16 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-728204a8.jsonl
### travel_19  [travel_identity, hard, SELF_CORRECTION]  cause guess: wrong_args: search_flights
- reason: Wrong arguments for: ['search_flights']
- expected tools: ['search_flights']  actual: ['search_flights']
- wrong arguments:
    search_flights: expected {'destination': 'Milan', 'date': 'June 3'} got {'destination': 'Mulan', 'date': 'June 3'} (The destination argument is incorrect; 'Mulan' does not match the expected 'Milan'.)
- reference transcript: Um, okay, I want to look for flights to Rome. No, wait, I changed my mind. Let's do Milan instead. And I was thinking June 1st. Well, wait, but actually, June 3rd works better for me. Sorry about that.
- agent heard (1 turn end(s)): Um, okay, I wanna look for flights to Rome. No way, I changed my mind. Let's do Mulan instead. And I was thinking June 1st. Well, wait, but actually, June 3rd... Works better for me. Sorry about that.
- agent said: [speak] I'll search for flights to Mulan for June 3. | [final] I found a flight to Mulan for June 3rd priced at 450 dollars with flight ID FL123.
- calls emitted (wire): search_flights(destination='Mulan', date='June 3')
- calls recorded by the benchmark: search_flights(destination='Mulan', date='June 3')
- latency: {'input_duration_s': 49.14, 'output_duration_s': 49.14, 'first_speech_s': 24.9}
- kernel: 22 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-5e7ab551.jsonl

## Passing recordings
ecommerce_01, ecommerce_01, ecommerce_02, ecommerce_04, ecommerce_05, ecommerce_06, ecommerce_07, ecommerce_09, ecommerce_10, ecommerce_11, ecommerce_13, ecommerce_13, ecommerce_14, ecommerce_15, ecommerce_15, ecommerce_16, ecommerce_17, ecommerce_18, ecommerce_19, ecommerce_21, ecommerce_21, ecommerce_23, ecommerce_25, finance_01, finance_01, finance_02, finance_03, finance_03, finance_04, finance_06, finance_07, finance_07, finance_08, finance_08, finance_11, finance_12, finance_12, finance_14, finance_15, finance_16, finance_17, finance_18, finance_19, finance_20, finance_21, finance_22, finance_23, housing_01, housing_02, housing_03, housing_04, housing_06, housing_09, housing_10, housing_17, housing_17, housing_19, travel_01, travel_03, travel_03, travel_05, travel_07, travel_08, travel_10, travel_11, travel_14, travel_16, travel_18, travel_20, travel_21, travel_21, travel_23, travel_23, travel_24
