# Janus x FDB-v3 run

- Janus commit: `86e5fc95cabf2cdd4de5695acb51a0edc560ac78`  FDB commit: `3e799c45a045256f47d5f1c9cda90157e2d2ec9e`
- Janus source SHA-256: `0c35d204c33ee27f`
- Judge: off (exact-match scoring only)
- Scenarios: 26  passed: 16  failed: 10
- Strict pass rate: 0.615

Provider declaration: custom LiveKit agent (Janus). Decisions by the Janus kernel with gemini-3.6-flash (hosted Gemini API, thinking budget 0, temperature 0); speech: faster-whisper large-v3-turbo (local, GPU) (STT), Kokoro-82M (TTS, local), Silero VAD (local).
