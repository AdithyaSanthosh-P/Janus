# Janus x FDB-v3 run

- Janus commit: `f911a194d5899633830f84cfc3751eaaa5487b82`  FDB commit: `3e799c45a045256f47d5f1c9cda90157e2d2ec9e`
- Janus source SHA-256: `15833452f2f017d6`
- Judge: on (FDB --use-llm)
- Scenarios: 100  passed: 82  failed: 18
- Strict pass rate: 0.82
- Recordings re-streamed after FDB's client aborted: none

Provider declaration: custom LiveKit agent (Janus). Decisions by the Janus kernel with gemini-3.6-flash (hosted Gemini API, thinking budget 0, temperature 0); speech: gpt-4o-mini-transcribe-2025-12-15 (hosted OpenAI API) (STT), Kokoro-82M (TTS, local), Silero VAD (local).
