# Janus x FDB-v3 run

- Janus commit: `unknown`  FDB commit: `3e799c45a045256f47d5f1c9cda90157e2d2ec9e`
- Judge: on (FDB --use-llm)
- Scenarios: 41  passed: 17  failed: 24
- Strict pass rate: 0.415

Provider declaration: custom LiveKit agent (Janus). Decisions by the Janus kernel with gemini-3.6-flash (hosted Gemini API, thinking budget 0, temperature 0); speech: gpt-4o-mini-transcribe-2025-12-15 (hosted OpenAI API) (STT), Kokoro-82M (TTS, local), Silero VAD (local).
