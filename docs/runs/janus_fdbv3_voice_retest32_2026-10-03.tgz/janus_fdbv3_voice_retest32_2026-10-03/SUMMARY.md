# Janus x FDB-v3 run

- Janus commit: `a8d1fcdb70c16b708d68300171c710fc60df772d`  FDB commit: `3e799c45a045256f47d5f1c9cda90157e2d2ec9e`
- Janus source SHA-256: `305385603b261780`
- Judge: on (FDB --use-llm)
- Scenarios: 32  passed: 24  failed: 8
- Strict pass rate: 0.75
- Recordings re-streamed after FDB's client aborted: none

Provider declaration: custom LiveKit agent (Janus). Decisions by the Janus kernel with gemini-3.6-flash (hosted Gemini API, thinking budget 0, temperature 0); speech: gpt-4o-mini-transcribe-2025-12-15 (hosted OpenAI API) (STT), Kokoro-82M (TTS, local), Silero VAD (local).
