# Run digest: 20261003_143517

- Scenarios scored: 32  passed: 24  failed: 8  strict pass rate: 0.75
- Janus commit: `a8d1fcdb70c16b708d68300171c710fc60df772d`  FDB commit: `3e799c45a045256f47d5f1c9cda90157e2d2ec9e`
- Judge: on (FDB --use-llm)
- Tool metrics: {"tool_selection_acc": 0.963, "argument_acc": 0.807, "response_qual": 0.625, "tool_selection_acc_all": 0.963, "argument_acc_all": 0.807, "note": "*_all includes no-response samples (scored 0); default metrics are turn-taken only"}
- Turn-taking: {"total": 32, "turn_taken": 32, "no_response": 0, "turn_take_rate": 1.0}  Latency: {"total_samples": 32, "interruption_count": 0, "interruption_rate": 0.0, "avg_response_latency_s": 7.11, "std_response_latency_s": 3.192, "min_latency_s": 4.24, "max_latency_s": 21.92, "note": "avg/std/min/max exclude interruption samples; computed on turn-taken samples only"}
- by_domain: {"ecommerce_support": 1.0, "finance_billing": 1.0, "housing_location": 0.167, "travel_identity": 0.727}
- by_difficulty: {"easy": 1.0, "medium": 0.75, "hard": 0.615}
- by_num_tools: {"1": 0.85, "2": 0.5, "3": 0.625}
- by_disfluency_feature: {"SELF_CORRECTION": 0.75, "FILLER": 0.75, "FALSE_START": 1.0, "HESITATION": 1.0, "PAUSE": 1.0}
- by_state_rollback: {"with_rollback": 0.75, "without_rollback": 0.75}
- failure_breakdown: {"wrong_tools": 2, "wrong_arguments": 6}
- Recordings re-streamed after a client abort: 0

## Agent log: top errors (de-duplicated)
- 8x ERROR:livekit:livekit::rtc_engine::rtc_session:#:livekit::rtc_engine::rtc_session - publisher data channel '_reliable' closed unexpectedly
- 6x ERROR:livekit:livekit::rtc_engine::rtc_session:#:livekit::rtc_engine::rtc_session - publisher data channel '_lossy' closed unexpectedly
- 6x ERROR:livekit:livekit::rtc_engine::rtc_session:#:livekit::rtc_engine::rtc_session - publisher data channel '_data_track' closed unexpectedly

## Failures by guessed cause (8 total)
- wrong_args: 5
- silent: 1
- wrong_tools: 1
- stt: 1

## Failing recordings

### housing_13  [housing_location, medium, no disfluency]  cause guess: silent: the agent made no calls
- reason: Missing tools: ['update_search_filter', 'update_search_filter']
- expected tools: ['update_search_filter', 'update_search_filter']  actual: []
- reference transcript: You know, like, you know, let's raise the max price to three thousand per month and also bump up the minimum bedrooms to three. Yeah, I think I need more space than I originally thought.
- agent heard (1 turn end(s)): You know, like, you know, let's raise the max price to $3,000 per month. And also bump up the minimum bedrooms to three. Mm, yeah, I think I need more space than I originally thought.
- agent said: [speak] I'll search for 3-bedroom apartments with a maximum rent of $3,000 per month. | [clarify] I need a bit more information — what should city be?
- calls emitted (wire): none
- calls recorded by the benchmark: none
- latency: {'input_duration_s': 48.507, 'output_duration_s': 48.507, 'first_speech_s': 23.15}
- kernel: 14 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'clarify': 1}; gate holds {}
- decision log: decisions/eval-9f951d67.jsonl
### housing_14  [housing_location, medium, FILLER]  cause guess: wrong_args: search_apartments
- reason: Wrong arguments for: ['search_apartments']
- expected tools: ['search_apartments']  actual: ['search_apartments']
- wrong arguments:
    search_apartments: expected {'city': 'Portland', 'bedrooms': 1, 'max_price': 1800, 'pets_allowed': True} got {'city': 'Portland', 'bedrooms': 1, 'max_price': 1800} (The 'pets_allowed' argument is missing in the actual arguments.)
- reference transcript: Like, you know, um, so um, I'm looking for like a one-bedroom apartment in Portland, and I'd want to keep the rent under 1,800. Oh, and it needs to be uh pet-friendly because um I have a dog.
- agent heard (1 turn end(s)): So, um, I'm looking for, like, a one-bedroom apartment in Portland, and I'd want to keep the rent under $1,800. Oh, and it needs to be pet-friendly because, um, I have a dog.
- agent said: [speak] I will search for 1-bedroom apartments in Portland with a rent under $1,800. I can't do "pet-friendly filter" here, though. | [final] I found a one-bedroom apartment in Portland listed at $1,700 per month under ID APT1.
- calls emitted (wire): search_apartments(city='Portland', bedrooms=1, max_price=1800)
- calls recorded by the benchmark: search_apartments(city='Portland', bedrooms=1, max_price=1800)
- latency: {'input_duration_s': 48.36, 'output_duration_s': 48.36, 'first_speech_s': 23.75}
- kernel: 11 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-f8c7a85e.jsonl
### housing_14  [housing_location, medium, FILLER]  cause guess: wrong_args: search_apartments
- reason: Wrong arguments for: ['search_apartments']
- expected tools: ['search_apartments']  actual: ['search_apartments']
- wrong arguments:
    search_apartments: expected {'city': 'Portland', 'bedrooms': 1, 'max_price': 1800, 'pets_allowed': True} got {'city': 'Portland', 'bedrooms': 1, 'max_price': 1800} (The 'pets_allowed' argument is missing in the actual arguments.)
- reference transcript: Like, you know, so um, I'm looking for like a one-bedroom apartment in Portland and I'd want to keep the rent under $1,800. Oh, well, and oh, and it needs to be uh pet-friendly because uh I have a dog.
- agent heard (1 turn end(s)): Like, you know, so, um, I'm looking for like a one-bedroom apartment in Portland. And I wanna keep the rent under $1,800, so, well, and it needs to be pet-friendly, because... I have a dog.
- agent said: [speak] I'll search for one-bedroom apartments in Portland with a rent under $1,800. I can't do "filter for pet-friendly apartments" here, though. | [final] I found a one bedroom apartment in Portland listed at 1700 dollars with the ID APT1.
- calls emitted (wire): search_apartments(city='Portland', bedrooms=1, max_price=1800)
- calls recorded by the benchmark: search_apartments(city='Portland', bedrooms=1, max_price=1800)
- latency: {'input_duration_s': 51.3, 'output_duration_s': 51.3, 'first_speech_s': 32.55}
- kernel: 18 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {'G10:search_apartments': 1}
- decision log: decisions/eval-389ee3d4.jsonl
### housing_20  [housing_location, hard, no disfluency]  cause guess: wrong_args: search_apartments
- reason: Wrong arguments for: ['search_apartments']
- expected tools: ['search_apartments', 'calculate_commute', 'update_search_filter']  actual: ['search_apartments', 'calculate_commute', 'update_search_filter']
- wrong arguments:
    search_apartments: expected {'city': 'Austin', 'max_price': 2000} got {'city': 'Austin', 'max_price': 2000, 'bedrooms': 1} (The actual arguments include an extra 'bedrooms' parameter which is not expected.)
- reference transcript: Uh you know so here's what I'm thinking. Search for places in Austin under 2,000. Then check the commute to my office. If it's under 15 minutes, that's perfect. But if it's longer then raise my budget to 2,500 so uh I can look at places closer to work.
- agent heard (1 turn end(s)): You know, so here's what I'm thinking. Search for places in Austin under $2000. Then, check the commute to my office. If it's under 15 minutes, that is perfect, but if it's longer then raise my budget to $2500 so I can look at places closer to work.
- agent said: [speak] I'll search for 1-bedroom apartments in Austin under $2000, assuming 1 bedroom, check the commute to your office, and update the max price filter to $2500 if needed. | [final] I searched for one bedroom apartments in Austin under 2000 dollars and found apartment APT1 priced at 1900 dollars. The driving commute from APT1 to your office takes 25 minutes, and I updated your maximum price filter to 2500 dollars.
- calls emitted (wire): search_apartments(city='Austin', max_price=2000, bedrooms=1); calculate_commute(origin_address='APT1', destination_address='my office'); update_search_filter(filter_name='max_price', value='2500')
- calls recorded by the benchmark: search_apartments(city='Austin', max_price=2000, bedrooms=1); calculate_commute(origin_address='APT1', destination_address='my office', mode='driving'); update_search_filter(filter_name='max_price', value='2500')
- latency: {'input_duration_s': 47.46, 'output_duration_s': 47.46, 'first_speech_s': 23.95}
- kernel: 18 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 3, 'final': 1}; gate holds {}
- decision log: decisions/eval-9615a016.jsonl
### housing_25  [housing_location, hard, SELF_CORRECTION]  cause guess: wrong_tools: missing ['update_search_filter'] unexpected []
- reason: Missing tools: ['update_search_filter']
- expected tools: ['update_search_filter', 'update_search_filter', 'search_apartments']  actual: ['update_search_filter', 'search_apartments']
- reference transcript: You know, you know, alright, first set the filter so pets are allowed and set the max price to 3,000. Then search for places in San Francisco. Wait, actually change the max price to 3500 instead. San Francisco is expensive, so I need more room in the budget.
- agent heard (1 turn end(s)): You know, you know, all right, first set the filter so pets are allowed and set the max price to 3000. Then search for places in San Francisco. Wait, actually, change the max price to $3,500 instead. San Francisco is expensive, so I need more room in the budget.
- agent said: [speak] I'll update the search filter to allow pets and search for 1-bedroom apartments in San Francisco with a max price of $3,500. | [final] I updated your filter to allow pets and searched for one bedroom apartments in San Francisco under $3,500. I found one listing, ID APT1, priced at $3,400 per month.
- calls emitted (wire): update_search_filter(filter_name='pets_allowed', value='true'); search_apartments(city='San Francisco', bedrooms=1, max_price=3500)
- calls recorded by the benchmark: update_search_filter(filter_name='pets_allowed', value='true'); search_apartments(city='San Francisco', bedrooms=1, max_price=3500)
- latency: {'input_duration_s': 51.48, 'output_duration_s': 51.48, 'first_speech_s': 26.6}
- kernel: 16 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 2, 'final': 1}; gate holds {'G10:search_apartments': 1}
- decision log: decisions/eval-575c08fb.jsonl
### travel_19  [travel_identity, hard, SELF_CORRECTION]  cause guess: wrong_args: search_flights
- reason: Wrong arguments for: ['search_flights']
- expected tools: ['search_flights']  actual: ['search_flights']
- wrong arguments:
    search_flights: expected {'destination': 'Milan', 'date': 'June 3'} got {'destination': 'Mulan', 'date': 'June 3'} (The destination argument is incorrect; 'Milan' was expected, but 'Mulan' was provided.)
- reference transcript: Um, okay, I want to look for flights to Rome. No, wait, I changed my mind. Let's do Milan instead. And I was thinking June 1st. Well, wait, but actually, June 3rd works better for me. Sorry about that.
- agent heard (1 turn end(s)): Okay, I wanna look for flights to Rome. No way, I changed my mind, let's do Mulan instead. And I was thinking June 1st. Well, wait, but actually, June 3rd works better for me. Sorry about that.
- agent said: [speak] I'll search for flights to Mulan for June 3rd. | [final] I found a flight to Mulan on June 3rd, flight FL123, priced at $450.
- calls emitted (wire): search_flights(destination='Mulan', date='June 3')
- calls recorded by the benchmark: search_flights(destination='Mulan', date='June 3')
- latency: {'input_duration_s': 49.14, 'output_duration_s': 49.14, 'first_speech_s': 23.1}
- kernel: 19 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-d23fab44.jsonl
### travel_20  [travel_identity, hard, no disfluency]  cause guess: wrong_args: book_flight
- reason: Wrong arguments for: ['book_flight', 'update_identity_doc']
- expected tools: ['search_flights', 'book_flight', 'update_identity_doc']  actual: ['search_flights', 'book_flight', 'update_identity_doc']
- wrong arguments:
    book_flight: expected {'passenger_name': 'Riley Kim'} got {'passenger_name': 'Riley King'} (The actual argument 'Riley King' does not match the expected argument 'Riley Kim' for 'passenger_name'.)
    update_identity_doc: expected {'doc_type': 'driver_license', 'doc_number': 'DL88'} got {'doc_type': "driver's license", 'doc_number': 'DL88'} (The actual argument 'driver's license' does not match the expected 'driver_license'. The use of an apostrophe is not a …)
- reference transcript: Here's the thing, I I need to fly to Toronto on July 20th. If there happens to be a flight under $300, go ahead and book it for Riley-Kin. But if everything's too expensive, then just forget the flight and update my driver's license to DL88 instead.
- agent heard (1 turn end(s)): Here's the thing, I need to fly to Toronto on July 20th. If there happens to be a flight under $300, go ahead and book it for Riley King. But if everything's too expensive, then just forget the flight and update my driver's license to DL88 instead.
- agent said: [speak] I'll search for flights to Toronto for July 20, book it for Riley King if it's under $300, or update your driver's license to DL88 if flights are too expensive. | [final] I found a flight to Toronto for July 20 at 450 dollars under ID FL123. I also confirmed your flight booking for Riley King with reference B789, and successfully updated your driver's license to DL88.
- calls emitted (wire): search_flights(destination='Toronto', date='July 20'); book_flight(passenger_name='Riley King'); update_identity_doc(doc_type="driver's license", doc_number='DL88')
- calls recorded by the benchmark: search_flights(destination='Toronto', date='July 20'); book_flight(passenger_name='Riley King'); update_identity_doc(doc_type="driver's license", doc_number='DL88')
- latency: {'input_duration_s': 46.98, 'output_duration_s': 46.98, 'first_speech_s': 24.05}
- kernel: 15 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 3, 'final': 1}; gate holds {'G10:search_flights': 1}
- decision log: decisions/eval-c7ec6629.jsonl
### travel_23  [travel_identity, hard, FILLER]  cause guess: stt: the agent heard a different sentence (65% word overlap with the reference transcript)
- reason: Wrong arguments for: ['update_identity_doc']
- expected tools: ['update_identity_doc', 'update_identity_doc']  actual: ['update_identity_doc', 'update_identity_doc']
- wrong arguments:
    update_identity_doc: expected {'doc_type': 'driver_license', 'doc_number': 'DL9090'} got {'doc_type': "driver's license", 'doc_number': 'DL9090'} (The actual argument 'driver's license' does not match the expected 'driver_license'. The use of an apostrophe and the w…)
- reference transcript: Hmm. Um so I need to like update my passport number to P1122 because they just renewed it. And then uh I also got a new driver's license. So could you change that one to D L nine zero nine zero as well? Great idea. Rocky cheek. You want to go to check out a check right here.
- agent heard (1 turn end(s)): So I need to, like, update my passport number to P1122 because I just renewed it. And then, uh I also got a new driver's license, so could you change that one to DL-9090 as well?
- agent said: [speak] I'll update your passport number to P1122 and your driver's license number to DL-9090. | [final] I have successfully updated your passport to number 1122 and your driver's license to number 9090.
- calls emitted (wire): update_identity_doc(doc_type='passport', doc_number='P1122'); update_identity_doc(doc_type="driver's license", doc_number='DL9090')
- calls recorded by the benchmark: update_identity_doc(doc_type='passport', doc_number='P1122'); update_identity_doc(doc_type="driver's license", doc_number='DL9090')
- latency: {'input_duration_s': 52.5, 'output_duration_s': 52.5, 'first_speech_s': 30.05}
- kernel: 14 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 2, 'final': 1}; gate holds {}
- decision log: decisions/eval-99571867.jsonl

## Passing recordings
ecommerce_06, ecommerce_09, ecommerce_10, ecommerce_14, ecommerce_14, ecommerce_25, ecommerce_25, finance_03, finance_03, finance_07, finance_07, finance_12, finance_12, finance_19, finance_23, housing_09, travel_07, travel_07, travel_14, travel_16, travel_18, travel_21, travel_21, travel_23
