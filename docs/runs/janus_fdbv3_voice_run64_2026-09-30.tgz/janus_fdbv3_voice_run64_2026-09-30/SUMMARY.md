# Janus x FDB-v3 run

- Janus commit: `unknown`  FDB commit: `3e799c45a045256f47d5f1c9cda90157e2d2ec9e`
- Judge: off (exact-match scoring only)
- Scenarios: 64  passed: 12  failed: 52
- Strict pass rate: 0.188

Provider declaration: custom LiveKit agent (Janus). Decisions by the Janus kernel with gemini-3.6-flash (hosted Gemini API, thinking budget 0, temperature 0); speech: gpt-4o-mini-transcribe-2025-12-15 (hosted OpenAI API) (STT), Kokoro-82M (TTS, local), Silero VAD (local).
