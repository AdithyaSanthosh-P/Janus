# Run digest: 20261004_105851

- Scenarios scored: 100  passed: 73  failed: 27  strict pass rate: 0.73
- Janus commit: `d1732c5585de8cf421a733d852aeab96f18273c2`  FDB commit: `3e799c45a045256f47d5f1c9cda90157e2d2ec9e`
- Judge: on (FDB --use-llm)
- Tool metrics: {"tool_selection_acc": 0.953, "argument_acc": 0.767, "response_qual": 0.29, "tool_selection_acc_all": 0.953, "argument_acc_all": 0.767, "note": "*_all includes no-response samples (scored 0); default metrics are turn-taken only"}
- Turn-taking: {"total": 100, "turn_taken": 100, "no_response": 0, "turn_take_rate": 1.0}  Latency: {"total_samples": 100, "interruption_count": 0, "interruption_rate": 0.0, "avg_response_latency_s": 7.459, "std_response_latency_s": 4.023, "min_latency_s": 5.12, "max_latency_s": 28.8, "note": "avg/std/min/max exclude interruption samples; computed on turn-taken samples only"}
- by_domain: {"travel_identity": 0.8, "ecommerce_support": 0.793, "finance_billing": 0.96, "housing_location": 0.385}
- by_difficulty: {"easy": 0.806, "medium": 0.824, "hard": 0.533}
- by_num_tools: {"1": 0.773, "2": 0.778, "3": 0.5}
- by_disfluency_feature: {"FILLER": 0.828, "HESITATION": 0.7, "SELF_CORRECTION": 0.706, "FALSE_START": 0.583, "PAUSE": 0.611}
- by_state_rollback: {"with_rollback": 0.706, "without_rollback": 0.735}
- failure_breakdown: {"wrong_tools": 9, "wrong_arguments": 18}
- Recordings re-streamed after a client abort: 0

## Agent log: top errors (de-duplicated)
- 6x ERROR:livekit:livekit::rtc_engine::rtc_session:#:livekit::rtc_engine::rtc_session - publisher data channel '_reliable' closed unexpectedly
- 6x ERROR:livekit:livekit::rtc_engine::rtc_session:#:livekit::rtc_engine::rtc_session - publisher data channel '_lossy' closed unexpectedly
- 6x ERROR:livekit:livekit::rtc_engine::rtc_session:#:livekit::rtc_engine::rtc_session - publisher data channel '_data_track' closed unexpectedly

## Failures by guessed cause (27 total)
- wrong_args: 17
- wrong_tools: 6
- silent: 3
- stt: 1

## Failing recordings

### ecommerce_07  [ecommerce_support, easy, FALSE_START]  cause guess: wrong_args: track_order
- reason: Wrong arguments for: ['track_order']
- expected tools: ['track_order']  actual: ['track_order']
- wrong arguments:
    track_order: expected {'order_id': 'FAST99'} got {'order_id': 'FAST999'} (The actual argument 'FAST999' does not match the expected argument 'FAST99'.)
- reference transcript: So, could you? Um, I wanted to search for a new product. Actually, no, never mind, never mind, forget that for now. Could you just track my order instead? Um, the ID is FAST99.
- agent heard (1 turn end(s)): So, could you, um, I wanted to search for a new product. Actually, no, never mind, never mind. Forget that for now. Could you just track my order instead? The ID is FAST999.
- agent said: [speak] I'll track order FAST999 for you. | [final] Your order FAST999 is currently out for delivery.
- calls emitted (wire): track_order(order_id='FAST999')
- calls recorded by the benchmark: track_order(order_id='FAST999')
- latency: {'input_duration_s': 50.04, 'output_duration_s': 50.04, 'first_speech_s': 25.7}
- kernel: 11 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-8f7bc3f5.jsonl
### ecommerce_08  [ecommerce_support, easy, PAUSE]  cause guess: wrong_args: search_products
- reason: Wrong arguments for: ['search_products']
- expected tools: ['search_products']  actual: ['search_products']
- wrong arguments:
    search_products: expected {'query': 'mechanical keyboards', 'max_price': 200} got {'query': 'mechanical keyboard', 'max_price': 200} (The 'query' argument is 'mechanical keyboard' instead of 'mechanical keyboards', which is not a minor formatting differ…)
- reference transcript: Ah, hmm. You know, um, I want a mechanical keyboard and I'm trying, um, to keep my budget under two hundred dollars. Do you have anything like that?
- agent heard (1 turn end(s)): You know, um... I want a mechanical keyboard, and I'm trying to keep my budget under... Two hundred dollars? Do you have anything like that?
- agent said: [speak] I'll search for mechanical keyboards under $200. | [final] I found the mechanical keyboard Premium priced at $190 under product ID PROD1.
- calls emitted (wire): search_products(query='mechanical keyboard', max_price=200)
- calls recorded by the benchmark: search_products(query='mechanical keyboard', max_price=200)
- latency: {'input_duration_s': 45.78, 'output_duration_s': 45.78, 'first_speech_s': 20.3}
- kernel: 16 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {'G10:search_products': 1}
- decision log: decisions/eval-306c1fad.jsonl
### ecommerce_08  [ecommerce_support, easy, PAUSE]  cause guess: wrong_args: search_products
- reason: Wrong arguments for: ['search_products']
- expected tools: ['search_products']  actual: ['search_products']
- wrong arguments:
    search_products: expected {'query': 'mechanical keyboards', 'max_price': 200} got {'query': 'mechanical keyboard', 'max_price': 200} (The query argument 'mechanical keyboard' does not match the expected 'mechanical keyboards'.)
- reference transcript: Um, yeah, you know, uh, I want a mechanical keyboard, and I'm trying to keep my budget under $200. Do you have anything like that?
- agent heard (1 turn end(s)): Yeah, you know, uh... I want a mechanical keyboard, and I'm trying to keep my budget under $200. Do you have anything like that?
- agent said: [speak] I'll search for mechanical keyboards under $200. | [final] I found the mechanical keyboard Premium priced at $190 under product ID PROD1.
- calls emitted (wire): search_products(query='mechanical keyboard', max_price=200)
- calls recorded by the benchmark: search_products(query='mechanical keyboard', max_price=200)
- latency: {'input_duration_s': 43.44, 'output_duration_s': 43.44, 'first_speech_s': 19.8}
- kernel: 16 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {'G10:search_products': 1}
- decision log: decisions/eval-5bae920a.jsonl
### ecommerce_12  [ecommerce_support, medium, HESITATION,PAUSE]  cause guess: wrong_args: search_products
- reason: Wrong arguments for: ['search_products']
- expected tools: ['search_products']  actual: ['search_products']
- wrong arguments:
    search_products: expected {'query': 'gift', 'category': 'electronics'} got {'query': 'electronics'} (The actual arguments are missing the 'category' argument and the 'query' argument value is incorrect.)
- reference transcript: Like, you know, um, I'm thinking something in the let me think electronics section of the grid. He's really into gadgets and text stuff.
- agent heard (1 turn end(s)): Like, you know, I'm thinking something in the, let me think, electronics section would be great. He's really into gadgets and tech stuff.
- agent said: [speak] I'll search for products in the electronics section. | [final] I found the product electronics Premium with ID PROD1, priced at 99.99.
- calls emitted (wire): search_products(query='electronics')
- calls recorded by the benchmark: search_products(query='electronics')
- latency: {'input_duration_s': 41.264, 'output_duration_s': 41.264, 'first_speech_s': 18.55}
- kernel: 12 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {'G10:search_products': 1}
- decision log: decisions/eval-9c06055d.jsonl
### ecommerce_20  [ecommerce_support, hard, no disfluency]  cause guess: wrong_tools: missing ['add_to_cart'] unexpected ['track_order']
- reason: Missing tools: ['add_to_cart']; Unexpected tools: ['track_order']
- expected tools: ['search_products', 'add_to_cart']  actual: ['search_products', 'track_order']
- reference transcript: So, you know, so search for a coffee maker first. If you find one that's under $50, go ahead and add two to the cart because they make great gifts. But if everything's over $50, I'd just forget the coffee maker and track order WWW for me instead.
- agent heard (1 turn end(s)): So, um, you know, I... So search for a coffee maker first. If you find one that's under $50, go ahead and add to the cart because they make great gifts. But if everything's over $50, just forget the coffee maker and track order www for me instead.
- agent said: [speak] I'll search for a coffee maker, add it to your cart if it's under $50, or track order www for you if everything is over $50. | [final] I searched for coffee makers and found the coffee maker Premium priced at $99.99, but I did not add it to your cart because its price is over $50. I also tracked your order www, which is currently out for delivery.
- calls emitted (wire): search_products(query='coffee maker'); track_order(order_id='www')
- calls recorded by the benchmark: search_products(query='coffee maker'); track_order(order_id='www')
- latency: {'input_duration_s': 54.629, 'output_duration_s': 54.629, 'first_speech_s': 31.95}
- kernel: 19 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 2, 'final': 1}; gate holds {}
- decision log: decisions/eval-8b502943.jsonl
### ecommerce_25  [ecommerce_support, hard, FALSE_START]  cause guess: wrong_args: track_order
- reason: Wrong arguments for: ['track_order']
- expected tools: ['track_order', 'search_products', 'add_to_cart']  actual: ['track_order', 'search_products', 'add_to_cart']
- wrong arguments:
    track_order: expected {'order_id': 'CAT'} got {'order_id': 'ZAT'} (The actual argument 'order_id' is 'ZAT', which does not match the expected 'CAT'.)
- reference transcript: You know, um, well, can um I return my never mind, uh, forget the return. Let me focus on what I actually need. Track order CAT for me, then search for cat food because I'm running low and add three of whatever you find to my card.
- agent heard (1 turn end(s)): You know, um, well... Can, um... I returned my... Never mind, forget the return. Let me focus on what I actually need. Track order ZAT for me. and search for cat food because I'm running low. And add three of whatever you find to my cart.
- agent said: [speak] I'll track order ZAT, search for cat food, and add three of the results to your cart. | [final] Your order ZAT is currently out for delivery. I have also added 3 packages of cat food Premium to your cart, bringing your cart total to $300.00.
- calls emitted (wire): track_order(order_id='ZAT'); search_products(query='cat food'); add_to_cart(product_id='PROD1', quantity=3)
- calls recorded by the benchmark: track_order(order_id='ZAT'); search_products(query='cat food'); add_to_cart(product_id='PROD1', quantity=3)
- latency: {'input_duration_s': 53.7, 'output_duration_s': 53.7, 'first_speech_s': 29.35}
- kernel: 28 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 3, 'final': 1}; gate holds {}
- decision log: decisions/eval-363911ce.jsonl
### finance_20  [finance_billing, hard, no disfluency]  cause guess: wrong_tools: missing ['modify_autopay'] unexpected []
- reason: Missing tools: ['modify_autopay']
- expected tools: ['get_exchange_rate', 'modify_autopay']  actual: ['get_exchange_rate']
- reference transcript: Well, here's my situation. I want to check what 1,000 US dollars is in Euros right now. If the exchange rate looks good to me, then go ahead and change my mortgage auto pay to pull from checking. But if the rate isn't great, just leave everything as is and keep it on the savings.
- agent heard (1 turn end(s)): Well, here's my situation. I wanna check what $1,000 US dollars is in euros right now. If the exchange rate looks good to me, then go ahead and change my mortgage auto-pay to pull from checking. But if the rate isn't great, just leave everything as is and keep it on the savings.
- agent said: [speak] I'll check the current exchange rate for $1,000 USD to EUR, and if the rate is good, I'll update your mortgage auto-pay to pull from your checking account. | [final] I checked the exchange rate and 1000 USD converts to 900 EUR at a rate of 0.9. I did not update your autopay since you specified to only do so if the exchange rate looks good, but let me know if you would like me to modify it now.
- calls emitted (wire): get_exchange_rate(amount=1000, from_currency='USD', to_currency='EUR')
- calls recorded by the benchmark: get_exchange_rate(amount=1000, from_currency='USD', to_currency='EUR')
- latency: {'input_duration_s': 52.576, 'output_duration_s': 52.576, 'first_speech_s': 28.6}
- kernel: 12 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-9490e0dd.jsonl
### housing_05  [housing_location, easy, HESITATION,PAUSE]  cause guess: wrong_args: search_apartments
- reason: Wrong arguments for: ['search_apartments']
- expected tools: ['search_apartments']  actual: ['search_apartments']
- wrong arguments:
    search_apartments: expected {'city': 'Miami', 'max_price': 1500, 'pets_allowed': True} got {'city': 'Miami', 'max_price': 1500, 'bedrooms': 1} (The actual arguments are missing 'pets_allowed' and include an unexpected 'bedrooms' argument.)
- reference transcript: You know, you know, you know, well, I need um a pet-friendly apartment in Miami, and my budget is about let me check fifteen hundred a month. Is there anything in that range?
- agent heard (1 turn end(s)): You know? You know, you know well I need, um... a pet-friendly apartment in Miami, and my budget is about, uh, let me check. Fifteen hundred a month. Is there anything in that range?
- agent said: [speak] I'll search for pet-friendly apartments in Miami with a maximum price of 1500 a month, assuming 1 bedroom. | [final] I found a one bedroom apartment in Miami with ID APT1 listed for $1400.
- calls emitted (wire): search_apartments(city='Miami', max_price=1500, bedrooms=1)
- calls recorded by the benchmark: search_apartments(city='Miami', max_price=1500, bedrooms=1)
- latency: {'input_duration_s': 48.9, 'output_duration_s': 48.9, 'first_speech_s': 25.05}
- kernel: 20 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {'G10:search_apartments': 1}
- decision log: decisions/eval-034d912b.jsonl
### housing_05  [housing_location, easy, HESITATION,PAUSE]  cause guess: wrong_args: search_apartments
- reason: Wrong arguments for: ['search_apartments']
- expected tools: ['search_apartments']  actual: ['search_apartments']
- wrong arguments:
    search_apartments: expected {'city': 'Miami', 'max_price': 1500, 'pets_allowed': True} got {'city': 'Miami', 'max_price': 1500, 'bedrooms': 1} (The actual arguments are missing 'pets_allowed' and include an unexpected 'bedrooms' argument.)
- reference transcript: You know, um, you know, well, I need um a pet-friendly apartment in Miami, and my budget is about uh let me check. It's uh it's about fifteen hundred a month. Is there anything in that range?
- agent heard (1 turn end(s)): You know, um... You know, well, I need a pet-friendly apartment in Miami, and my budget is about, let me check, it's... It's about $1,500 a month. Is there anything in that range?
- agent said: [speak] I'll search for 1-bedroom apartments in Miami with a maximum budget of $1,500, assuming 1 bedroom. I can't do "pet-friendly filter" here, though. | [final] I found a one bedroom apartment in Miami with ID APT1 listed at 1400 dollars per month.
- calls emitted (wire): search_apartments(city='Miami', max_price=1500, bedrooms=1)
- calls recorded by the benchmark: search_apartments(city='Miami', max_price=1500, bedrooms=1)
- latency: {'input_duration_s': 50.1, 'output_duration_s': 50.1, 'first_speech_s': 26.5}
- kernel: 19 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {'G10:search_apartments': 1}
- decision log: decisions/eval-fedebc9a.jsonl
### housing_08  [housing_location, easy, FALSE_START]  cause guess: wrong_args: update_search_filter
- reason: Wrong arguments for: ['update_search_filter']
- expected tools: ['update_search_filter']  actual: ['update_search_filter']
- wrong arguments:
    update_search_filter: expected {'filter_name': 'pets_allowed', 'value': True} got {'filter_name': 'pets', 'value': 'allowed'} (The expected argument 'filter_name' is 'pets_allowed', but the actual argument is 'pets'. Also, the expected 'value' is…)
- reference transcript: Okay, so um I want to check the listings in. Actually, before before I do that, could you just update my search filter so that it only shows me places that allow pets? I have a cat.
- agent heard (1 turn end(s)): Okay, so I wanna check the listings and actually, before I do that... Uh, could you just update my search filter so that it only shows me places that allow pets? I have a cat.
- agent said: [speak] I'll update your search filter to allow pets. | [final] I have updated your search filter to allow pets.
- calls emitted (wire): update_search_filter(filter_name='pets', value='allowed')
- calls recorded by the benchmark: update_search_filter(filter_name='pets', value='allowed')
- latency: {'input_duration_s': 45.72, 'output_duration_s': 45.72, 'first_speech_s': 18.8}
- kernel: 12 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-0072d733.jsonl
### housing_11  [housing_location, medium, SELF_CORRECTION]  cause guess: silent: the agent made no calls
- reason: Missing tools: ['search_apartments']
- expected tools: ['search_apartments']  actual: []
- reference transcript: Uh well, I was thinking a one bedroom under twelve well actually no wait, my partner is moving in with me, so we need a two bedroom and we can go up uh uh up to sixteen hundred a month.
- agent heard (1 turn end(s)): Well, I was thinking of one bedroom under 12. Well, actually, no, wait, my partner is moving in with me, so we need a two-bedroom, and we need to go up to $1,600 a month.
- agent said: [speak] I'll search for two-bedroom apartments with a maximum rent of $1,600, assuming a city. | [clarify] I need a bit more information — what should city be?
- calls emitted (wire): none
- calls recorded by the benchmark: none
- latency: {'input_duration_s': 41.46, 'output_duration_s': 41.46, 'first_speech_s': 17.25}
- kernel: 9 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'clarify': 1}; gate holds {}
- decision log: decisions/eval-764c3afb.jsonl
### housing_14  [housing_location, medium, FILLER]  cause guess: wrong_args: search_apartments
- reason: Wrong arguments for: ['search_apartments']
- expected tools: ['search_apartments']  actual: ['search_apartments']
- wrong arguments:
    search_apartments: expected {'city': 'Portland', 'bedrooms': 1, 'max_price': 1800, 'pets_allowed': True} got {'city': 'Portland', 'bedrooms': 1, 'max_price': 1800} (The 'pets_allowed' argument is missing in the actual arguments.)
- reference transcript: Like, you know, um, so um, I'm looking for like a one-bedroom apartment in Portland, and I'd want to keep the rent under 1,800. Oh, and it needs to be uh pet-friendly because um I have a dog.
- agent heard (1 turn end(s)): Like, you know, um, so, um, I'm looking for, like, a one-bedroom apartment in Portland, and I'd want to keep the rent under $1,800. Oh, and it needs to be, uh, pet-friendly, because, um, I have a dog.
- agent said: [speak] I'll search for one-bedroom apartments in Portland under $1,800. I can't do "filter for pet-friendly apartments" here, though. | [final] I found a one bedroom apartment in Portland listed at 1700 dollars with the ID APT1.
- calls emitted (wire): search_apartments(city='Portland', bedrooms=1, max_price=1800)
- calls recorded by the benchmark: search_apartments(city='Portland', bedrooms=1, max_price=1800)
- latency: {'input_duration_s': 48.36, 'output_duration_s': 48.36, 'first_speech_s': 25.8}
- kernel: 11 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-28eb84f3.jsonl
### housing_14  [housing_location, medium, FILLER]  cause guess: wrong_args: search_apartments
- reason: Wrong arguments for: ['search_apartments']
- expected tools: ['search_apartments']  actual: ['search_apartments']
- wrong arguments:
    search_apartments: expected {'city': 'Portland', 'bedrooms': 1, 'max_price': 1800, 'pets_allowed': True} got {'city': 'Portland', 'bedrooms': 1, 'max_price': 1800} (The 'pets_allowed' argument is missing in the actual arguments.)
- reference transcript: Like, you know, so um, I'm looking for like a one-bedroom apartment in Portland and I'd want to keep the rent under $1,800. Oh, well, and oh, and it needs to be uh pet-friendly because uh I have a dog.
- agent heard (1 turn end(s)): Like, you know, so, um, I'm looking for like a one-bedroom apartment in Portland. And I wanna keep the rent under $1,800, so, well, and it needs to be pet-friendly because... I have a dog.
- agent said: [speak] I will search for 1-bedroom apartments in Portland under $1,800. I can't do "pet-friendly filter" here, though. | [final] I found a one bedroom apartment in Portland for $1,700 per month with the ID APT1.
- calls emitted (wire): search_apartments(city='Portland', bedrooms=1, max_price=1800)
- calls recorded by the benchmark: search_apartments(city='Portland', bedrooms=1, max_price=1800)
- latency: {'input_duration_s': 51.3, 'output_duration_s': 51.3, 'first_speech_s': 32.1}
- kernel: 16 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {'G10:search_apartments': 1}
- decision log: decisions/eval-b4335808.jsonl
### housing_15  [housing_location, medium, FALSE_START]  cause guess: wrong_tools: missing [] unexpected ['update_search_filter']
- reason: Unexpected tools: ['update_search_filter']
- expected tools: ['search_apartments']  actual: ['search_apartments', 'update_search_filter']
- reference transcript: Um so hmm uh I wanted um to check the commute from that one listing. Actually let me skip that for now. Could you just search for a three-bedroom in Atlanta that's pet-friendly? I've got two cats.
- agent heard (1 turn end(s)): I wanted to check the commute from that one listing. Actually, let me skip that for now. Could you just search for a three-bedroom in Atlanta that's pet-friendly? I've got two cats.
- agent said: [speak] I'll search for three-bedroom apartments in Atlanta and set the filter for pet-friendly properties, assuming a generous max price limit. | [final] I found a three bedroom apartment in Atlanta for 9900 dollars per month under the ID APT1. I have also updated your search filter to pet friendly.
- calls emitted (wire): search_apartments(city='Atlanta', bedrooms=3, max_price=10000); update_search_filter(filter_name='pet_friendly', value='true')
- calls recorded by the benchmark: search_apartments(city='Atlanta', bedrooms=3, max_price=10000); update_search_filter(filter_name='pet_friendly', value='true')
- latency: {'input_duration_s': 48.42, 'output_duration_s': 48.42, 'first_speech_s': 25.45}
- kernel: 16 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 2, 'final': 1}; gate holds {'G10:search_apartments': 1}
- decision log: decisions/eval-a566f4b9.jsonl
### housing_15  [housing_location, medium, FALSE_START]  cause guess: silent: the agent made no calls
- reason: Missing tools: ['search_apartments']
- expected tools: ['search_apartments']  actual: []
- reference transcript: Um, so um uh I wanted to I wanted to check the commute from that one listing. Actually, let me skip that for now. Could you just search for a three-bedroom in Atlanta that's pet-friendly? I um I've got two cats too.
- agent heard (1 turn end(s)): So, I wanted to check the commute from that one listing. Actually, let me skip that for now. Could you just search for a three-bedroom in Atlanta? That's pet-friendly. I've got two cats, too.
- agent said: [speak] I'll search for a three-bedroom apartment in Atlanta with a standard maximum budget, and apply a pet-friendly search filter.
- calls emitted (wire): none
- calls recorded by the benchmark: none
- latency: {'input_duration_s': 50.52, 'output_duration_s': 50.52, 'first_speech_s': 33.2}
- kernel: 18 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1}; gate holds {'G3:search_apartments': 5, 'G10:search_apartments': 1}
- decision log: decisions/eval-30fec05f.jsonl
### housing_18  [housing_location, hard, no disfluency]  cause guess: wrong_args: search_apartments
- reason: Wrong arguments for: ['search_apartments', 'calculate_commute']
- expected tools: ['search_apartments', 'calculate_commute']  actual: ['search_apartments', 'calculate_commute']
- wrong arguments:
    search_apartments: expected {'city': 'Portland', 'bedrooms': 1, 'max_price': 1800} got {'city': 'Portland', 'bedrooms': 1, 'max_price': 800} (The 'max_price' argument is outside the acceptable numeric tolerance of ±5%.)
    calculate_commute: expected {'origin_address': '$RESULT_0.cheapest_apartment_address', 'destination_address': 'coffee shop on 5th', 'mode': 'biking'} got {'origin_address': 'APT1', 'destination_address': 'coffee shop on 5th Street', 'mode': 'biking'} (The destination address 'coffee shop on 5th Street' does not match 'coffee shop on 5th' as expected. The addition of 'S…)
- reference transcript: Well so first, search for a one-bedroom in Portland that's under $800 per month, then once you find the cheapest option, check how long it would take to bike from there to the coffee shop on 5th Street where I work.
- agent heard (1 turn end(s)): Well, so first, search for a one-bedroom in Portland that's under $800 per month. Then, once you find the cheapest option, check how long it would take to bike from there to the coffee shop on 5th Street where I work.
- agent said: [speak] I'll search for one-bedroom apartments in Portland under $800 per month, and then calculate the biking commute time from the cheapest option to the coffee shop on 5th Street. | [final] I found a one bedroom apartment in Portland, ID APT1, priced at 700 dollars per month. The biking commute from APT1 to the coffee shop on 5th Street takes 25 minutes.
- calls emitted (wire): search_apartments(city='Portland', bedrooms=1, max_price=800); calculate_commute(origin_address='APT1', destination_address='coffee shop on 5th Street', mode='biking')
- calls recorded by the benchmark: search_apartments(city='Portland', bedrooms=1, max_price=800); calculate_commute(origin_address='APT1', destination_address='coffee shop on 5th Street', mode='biking')
- latency: {'input_duration_s': 47.685, 'output_duration_s': 47.685, 'first_speech_s': 24.2}
- kernel: 14 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 2, 'final': 1}; gate holds {}
- decision log: decisions/eval-b221dbbf.jsonl
### housing_19  [housing_location, hard, SELF_CORRECTION]  cause guess: wrong_args: calculate_commute
- reason: Wrong arguments for: ['calculate_commute']
- expected tools: ['calculate_commute']  actual: ['calculate_commute']
- wrong arguments:
    calculate_commute: expected {'origin_address': 'my house', 'destination_address': 'the gym', 'mode': 'driving'} got {'origin_address': 'my house', 'destination_address': 'the gym', 'mode': 'drive'} (The 'mode' argument is 'drive' instead of the expected 'driving'.)
- reference transcript: Well, uh, calculate the transit time to the office. Wait, no, um I wouldn't be going to the office, I'd be going to the gym. And actually, now that I think about it, I'd drive there and not take transit. So make a drive into the gym from my house.
- agent heard (1 turn end(s)): Well, calculate the transit time to the office. Wait, no, I wouldn't be going to the office. I'd be going to the gym. And actually, now that I think about it, I drive there, not take transit, so make it a drive into the gym from my house.
- agent said: [speak] I'll calculate the drive time from your house to the gym. | [final] Driving from your house to the gym takes 25 minutes.
- calls emitted (wire): calculate_commute(origin_address='my house', destination_address='the gym', mode='drive')
- calls recorded by the benchmark: calculate_commute(origin_address='my house', destination_address='the gym', mode='drive')
- latency: {'input_duration_s': 43.44, 'output_duration_s': 43.44, 'first_speech_s': 21.9}
- kernel: 13 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-286b95d9.jsonl
### housing_20  [housing_location, hard, no disfluency]  cause guess: wrong_tools: missing [] unexpected ['search_apartments']
- reason: Unexpected tools: ['search_apartments']
- expected tools: ['search_apartments', 'calculate_commute', 'update_search_filter']  actual: ['search_apartments', 'calculate_commute', 'update_search_filter', 'search_apartments']
- reference transcript: Uh you know so here's what I'm thinking. Search for places in Austin under 2,000. Then check the commute to my office. If it's under 15 minutes, that's perfect. But if it's longer then raise my budget to 2,500 so uh I can look at places closer to work.
- agent heard (1 turn end(s)): You know, so here's what I'm thinking. Search for places in Austin under $2,000. Then, check the commute to my office. If it's under 15 minutes, that's perfect, but if it's longer, then raise my budget to $2500 so I can look at places closer to work.
- agent said: [speak] I'll search for 1-bedroom apartments in Austin under $2,000, check the commute to your office, and if it's over 15 minutes, update your max price filter to $2,500 and search again. | [final] I searched for one bedroom apartments in Austin under 2000 dollars and found APT1 for 1900 dollars, which has a 25 minute driving commute to your office. After updating your maximum price filter to 2500 dollars, a new search returned APT1 listed at 2400 dollars.
- calls emitted (wire): search_apartments(city='Austin', bedrooms=1, max_price=2000); calculate_commute(origin_address='APT1', destination_address='my office'); update_search_filter(filter_name='max_price', value='2500'); search_apartments(city='Austin', bedrooms=1, max_price=2500)
- calls recorded by the benchmark: search_apartments(city='Austin', bedrooms=1, max_price=2000); calculate_commute(origin_address='APT1', destination_address='my office', mode='driving'); update_search_filter(filter_name='max_price', value='2500'); search_apartments(city='Austin', bedrooms=1, max_price=2500)
- latency: {'input_duration_s': 47.46, 'output_duration_s': 47.46, 'first_speech_s': 24.2}
- kernel: 22 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 4, 'final': 1}; gate holds {}
- decision log: decisions/eval-3e8b22f9.jsonl
### housing_21  [housing_location, hard, SELF_CORRECTION]  cause guess: silent: the agent made no calls
- reason: Missing tools: ['search_apartments', 'calculate_commute']
- expected tools: ['search_apartments', 'calculate_commute']  actual: []
- reference transcript: So well, so you know I want to search for a place with two bedrooms. Wait, actually, I mean, I meant three bedrooms. We decided we need a home office. Also, check the transit time to the train station. Actually, I'd rather walk, so make that walk-in time.
- agent heard (1 turn end(s)): So, well, so you know, I want to search for a place with two bedrooms. Wait, actually, I mean, I meant three bedrooms. We decided we need a home office. Also, check the transit time to the train station. Actually, I'd rather walk, so make that. Walking time.
- agent said: [speak] I'll search for 3-bedroom apartments assuming a high budget, and calculate the walking commute to the train station. | [clarify] I need a bit more information — what should city be?
- calls emitted (wire): none
- calls recorded by the benchmark: none
- latency: {'input_duration_s': 49.725, 'output_duration_s': 49.725, 'first_speech_s': 26.95}
- kernel: 12 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'clarify': 1}; gate holds {}
- decision log: decisions/eval-d3973887.jsonl
### housing_22  [housing_location, hard, FILLER]  cause guess: wrong_args: update_search_filter
- reason: Wrong arguments for: ['update_search_filter', 'search_apartments', 'calculate_commute']
- expected tools: ['update_search_filter', 'search_apartments', 'calculate_commute']  actual: ['update_search_filter', 'search_apartments', 'calculate_commute']
- wrong arguments:
    update_search_filter: expected {'filter_name': 'pets_allowed', 'value': True} got {'filter_name': 'pets', 'value': 'allowed'} (The expected argument 'filter_name' is 'pets_allowed', but the actual argument is 'pets'. The values also do not match;…)
    search_apartments: expected {'city': 'Seattle', 'bedrooms': 1} got {'city': 'Seattle', 'bedrooms': 1, 'max_price': 10000} (The actual arguments include an unexpected 'max_price' parameter.)
    calculate_commute: expected {'origin_address': '$RESULT_1.apartments[0].address', 'destination_address': 'the stadium', 'mode': 'transit'} got {'origin_address': 'APT1', 'destination_address': 'the stadium', 'mode': 'driving'} (The mode of transport is incorrect; expected 'transit' but got 'driving'.)
- reference transcript: You know, um, can you first update my filter so pets are allowed? Um, I keep forgetting to set that. Then, like, search in Seattle for one bedroom. And then once you find something, uh, check the transit time from there to the stadium because, you know, I go to games pretty often.
- agent heard (1 turn end(s)): You know, um, can you first update my filter so pets are allowed? Um, I keep forgetting to set that. Then, like, search in Seattle for a one-bedroom. And then once you find something, check the transit time. From there to the stadium, because, you know, I go to games pretty often.
- agent said: [speak] I'll update your filter to allow pets, search for a one-bedroom apartment in Seattle assuming a max price of $10,000, and calculate the commute from there to the stadium. | [final] I updated your search to allow pets and found a one-bedroom apartment in Seattle for $9,900 per month with ID APT1. The driving commute from APT1 to the stadium takes 25 minutes.
- calls emitted (wire): update_search_filter(filter_name='pets', value='allowed'); search_apartments(city='Seattle', bedrooms=1, max_price=10000); calculate_commute(origin_address='APT1', destination_address='the stadium')
- calls recorded by the benchmark: update_search_filter(filter_name='pets', value='allowed'); search_apartments(city='Seattle', bedrooms=1, max_price=10000); calculate_commute(origin_address='APT1', destination_address='the stadium', mode='driving')
- latency: {'input_duration_s': 50.1, 'output_duration_s': 50.1, 'first_speech_s': 26.2}
- kernel: 25 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 3, 'final': 1}; gate holds {'G10:search_apartments': 1}
- decision log: decisions/eval-9c3dea48.jsonl
### housing_24  [housing_location, hard, PAUSE,FILLER]  cause guess: wrong_args: search_apartments
- reason: Wrong arguments for: ['search_apartments', 'calculate_commute']
- expected tools: ['update_search_filter', 'search_apartments', 'calculate_commute']  actual: ['update_search_filter', 'search_apartments', 'calculate_commute']
- wrong arguments:
    search_apartments: expected {'city': 'Dallas'} got {'city': 'Dallas', 'bedrooms': 1, 'max_price': 1500} (The function was called with additional arguments 'bedrooms' and 'max_price' which were not expected.)
    calculate_commute: expected {'origin_address': '$RESULT_1.apartments[0].address', 'destination_address': 'the grocery store', 'mode': 'walking'} got {'origin_address': 'APT1', 'destination_address': 'grocery store', 'mode': 'walking'} (The expected 'destination_address' is 'the grocery store', but the actual argument is 'grocery store', which is not a c…)
- reference transcript: Um, so hmm, like, you know, okay. So, first, um, I want to update my max price to $1,500 because I'm on a tighter budget. Then, uh, search for apartments in Dallas that fit that budget, and then check the walking time from whatever you find to the grocery store because I want to be close to one.
- agent heard (1 turn end(s)): Like, you know. Okay, so first, I want to update my max price to $1500 because I'm on a tighter budget, then search for apartments in Dallas that fit that budget, and then... Check the walking time from whatever you find to the grocery store because I want to be close to one.
- agent said: [speak] I'll update your max price filter to 1500, search for apartments in Dallas fitting that budget, and calculate the walking commute to the grocery store for the search results. | [final] I updated your search filter to a maximum price of 1500 and found apartment APT1 in Dallas for 1400 dollars with one bedroom. The walking commute from APT1 to the grocery store is 25 minutes.
- calls emitted (wire): update_search_filter(filter_name='max_price', value='1500'); search_apartments(city='Dallas', bedrooms=1, max_price=1500); calculate_commute(origin_address='APT1', destination_address='grocery store', mode='walking')
- calls recorded by the benchmark: update_search_filter(filter_name='max_price', value='1500'); search_apartments(city='Dallas', bedrooms=1, max_price=1500); calculate_commute(origin_address='APT1', destination_address='grocery store', mode='walking')
- latency: {'input_duration_s': 56.1, 'output_duration_s': 56.1, 'first_speech_s': 33.65}
- kernel: 23 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 3, 'final': 1}; gate holds {'G10:search_apartments': 1}
- decision log: decisions/eval-897a9700.jsonl
### housing_24  [housing_location, hard, PAUSE,FILLER]  cause guess: wrong_args: search_apartments
- reason: Wrong arguments for: ['search_apartments', 'calculate_commute']
- expected tools: ['update_search_filter', 'search_apartments', 'calculate_commute']  actual: ['update_search_filter', 'search_apartments', 'calculate_commute']
- wrong arguments:
    search_apartments: expected {'city': 'Dallas'} got {'city': 'Dallas', 'bedrooms': 1, 'max_price': 1500} (The function was called with additional arguments 'bedrooms' and 'max_price' which were not expected.)
    calculate_commute: expected {'origin_address': '$RESULT_1.apartments[0].address', 'destination_address': 'the grocery store', 'mode': 'walking'} got {'origin_address': 'APT1', 'destination_address': 'grocery store', 'mode': 'walking'} (The destination_address 'grocery store' does not match the expected 'the grocery store'.)
- reference transcript: Um so hmm like you know okay so first um I want to update my max price to 1500 because I'm on a tighter budget then uh search for apartments in Dallas that fit that budget and then check the walking time from whatever you find to the grocery store because I want to be close to one
- agent heard (1 turn end(s)): Like, you know, okay. So first, I want to update my max price to $1500. Because I'm on a tighter budget. Then, uh, search for apartments in Dallas that fit that budget. And then... Check the walking time from whatever you find to the grocery store because I wanna be close to one.
- agent said: [speak] I'll update your max price filter to $1500, search for 1-bedroom apartments in Dallas within that budget, and calculate the walking commute time to the grocery store for the results. | [final] I updated your maximum price filter to 1500 and found one 1-bedroom apartment in Dallas, APT1, listed at 1400 dollars. The walking commute from APT1 to the grocery store is 25 minutes.
- calls emitted (wire): update_search_filter(filter_name='max_price', value='1500'); search_apartments(city='Dallas', bedrooms=1, max_price=1500); calculate_commute(origin_address='APT1', destination_address='grocery store', mode='walking')
- calls recorded by the benchmark: update_search_filter(filter_name='max_price', value='1500'); search_apartments(city='Dallas', bedrooms=1, max_price=1500); calculate_commute(origin_address='APT1', destination_address='grocery store', mode='walking')
- latency: {'input_duration_s': 59.16, 'output_duration_s': 59.16, 'first_speech_s': 35.8}
- kernel: 27 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 3, 'final': 1}; gate holds {'G10:search_apartments': 1}
- decision log: decisions/eval-5a6f9632.jsonl
### housing_25  [housing_location, hard, SELF_CORRECTION]  cause guess: wrong_tools: missing ['update_search_filter'] unexpected []
- reason: Missing tools: ['update_search_filter']
- expected tools: ['update_search_filter', 'update_search_filter', 'search_apartments']  actual: ['update_search_filter', 'search_apartments']
- reference transcript: You know, you know, alright, first set the filter so pets are allowed and set the max price to 3,000. Then search for places in San Francisco. Wait, actually change the max price to 3500 instead. San Francisco is expensive, so I need more room in the budget.
- agent heard (1 turn end(s)): You know, you know, all right, first set the filter so pets are allowed, and set the max price to $3000. Then search for places in San Francisco. Wait, actually, change the max price to $3500 instead. San Francisco is expensive, so I need more room in the budget.
- agent said: [speak] I'll update your filter to allow pets and search for apartments in San Francisco with a maximum price of $3500. | [final] I updated your search filter to allow pets and found a one bedroom apartment in San Francisco, ID APT1, listed for 3400 dollars per month.
- calls emitted (wire): update_search_filter(filter_name='pets_allowed', value='true'); search_apartments(city='San Francisco', max_price=3500, bedrooms=1)
- calls recorded by the benchmark: update_search_filter(filter_name='pets_allowed', value='true'); search_apartments(city='San Francisco', max_price=3500, bedrooms=1)
- latency: {'input_duration_s': 51.48, 'output_duration_s': 51.48, 'first_speech_s': 26.95}
- kernel: 16 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 2, 'final': 1}; gate holds {'G10:search_apartments': 1}
- decision log: decisions/eval-736aa964.jsonl
### travel_02  [travel_identity, easy, no disfluency]  cause guess: stt: the agent heard a different sentence (78% word overlap with the reference transcript)
- reason: Wrong arguments for: ['update_identity_doc']
- expected tools: ['update_identity_doc']  actual: ['update_identity_doc']
- wrong arguments:
    update_identity_doc: expected {'doc_type': 'passport', 'doc_number': 'P9-9-9-90011'} got {'doc_type': 'passport', 'doc_number': 'P88990011'} (The actual doc_number 'P88990011' does not match the expected format 'P9-9-9-90011' and is not within a minor formattin…)
- reference transcript: Uh, yeah, so my new passport number is P eight eight nine nine zero zero one one. Could you update that in the system for me, please?
- agent heard (1 turn end(s)): Uh, yeah, so my new passport number is P88990011. Could you update that in the system for me, please?
- agent said: [speak] I'll update your passport number to P88990011 in the system. | [final] Your passport document number has been successfully updated to end in 0011.
- calls emitted (wire): update_identity_doc(doc_type='passport', doc_number='P88990011')
- calls recorded by the benchmark: update_identity_doc(doc_type='passport', doc_number='P88990011')
- latency: {'input_duration_s': 44.52, 'output_duration_s': 44.52, 'first_speech_s': 19.1}
- kernel: 12 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-2c28e91f.jsonl
### travel_19  [travel_identity, hard, SELF_CORRECTION]  cause guess: wrong_args: search_flights
- reason: Wrong arguments for: ['search_flights']
- expected tools: ['search_flights']  actual: ['search_flights']
- wrong arguments:
    search_flights: expected {'destination': 'Milan', 'date': 'June 3'} got {'destination': 'Mulan', 'date': 'June 3'} (The destination argument is incorrect; 'Milan' was expected, but 'Mulan' was provided.)
- reference transcript: Um, okay, I want to look for flights to Rome. No, wait, I changed my mind. Let's do Milan instead. And I was thinking June 1st. Well, wait, but actually, June 3rd works better for me. Sorry about that.
- agent heard (1 turn end(s)): Um, OK, I wanna look for flights to Rome. No way, I changed my mind, let's do Mulan instead. And I was thinking June 1st. Well, wait, but actually, June 3rd works better for me. Sorry about that.
- agent said: [speak] I'll search for flights to Mulan for June 3. | [final] I found a flight to Mulan for June 3rd priced at $450 with flight ID FL123.
- calls emitted (wire): search_flights(destination='Mulan', date='June 3')
- calls recorded by the benchmark: search_flights(destination='Mulan', date='June 3')
- latency: {'input_duration_s': 49.14, 'output_duration_s': 49.14, 'first_speech_s': 24.4}
- kernel: 20 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-2a190d33.jsonl
### travel_20  [travel_identity, hard, no disfluency]  cause guess: wrong_tools: missing ['book_flight'] unexpected []
- reason: Missing tools: ['book_flight']
- expected tools: ['search_flights', 'book_flight', 'update_identity_doc']  actual: ['search_flights', 'update_identity_doc']
- reference transcript: Here's the thing, I I need to fly to Toronto on July 20th. If there happens to be a flight under $300, go ahead and book it for Riley-Kin. But if everything's too expensive, then just forget the flight and update my driver's license to DL88 instead.
- agent heard (1 turn end(s)): Here's the thing: I need to fly to Toronto on July 20th. If there happens to be a flight under $300, go ahead and book it for Riley Kim. But if everything's too expensive, then just forget the flight and update my driver's license to DL-88 instead.
- agent said: [speak] I'll search for flights to Toronto on July 20, book it for Riley Kim if there's one under $300, or update your driver's license to DL-88 if not. | [final] I searched for flights to Toronto on July 20th and found flight FL123 for $450, but I did not book it since it was not under $300. I also updated your driver's license number to DL88.
- calls emitted (wire): search_flights(destination='Toronto', date='July 20'); update_identity_doc(doc_type='driver_license', doc_number='DL88')
- calls recorded by the benchmark: search_flights(destination='Toronto', date='July 20'); update_identity_doc(doc_type='driver_license', doc_number='DL88')
- latency: {'input_duration_s': 46.98, 'output_duration_s': 46.98, 'first_speech_s': 22.85}
- kernel: 15 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 2, 'final': 1}; gate holds {}
- decision log: decisions/eval-1654aef3.jsonl
### travel_24  [travel_identity, hard, no disfluency]  cause guess: wrong_args: book_flight
- reason: Wrong arguments for: ['book_flight']
- expected tools: ['search_flights', 'book_flight', 'update_identity_doc']  actual: ['search_flights', 'book_flight', 'update_identity_doc']
- wrong arguments:
    book_flight: expected {'passenger_name': 'Skyler'} got {'passenger_name': 'Skylar'} (The passenger name 'Skylar' does not match the expected 'Skyler'.)
- reference transcript: Well, great. So first, um, I need to find a flight to Vancouver on November 5th and book it under the name Schuyler. Then I was also hoping you could find a hotel near the airport for a couple of nights. And then finally, I need to update my Visa number to V as in Victor-4-4.
- agent heard (1 turn end(s)): Well, great. So first, um, I need to find a flight to Vancouver. On November 5th and book it under the name Skylar. Then I was also hoping you could find a hotel near the airport for a couple of nights. And then finally, I need to update my visa number to V as in Victor dash four dash four.
- agent said: [speak] I'll search for flights to Vancouver on November 5, book the flight for Skylar, and update your visa number to V-4-4. I can't do "search for a hotel near the airport for a couple of nights" here, though. | [final] I found a flight to Vancouver on November 5 for 450 dollars under flight ID FL123. I also booked the flight for Skylar with reference B789, and updated the visa document to V44.
- calls emitted (wire): search_flights(destination='Vancouver', date='November 5'); book_flight(passenger_name='Skylar'); update_identity_doc(doc_type='visa', doc_number='V44')
- calls recorded by the benchmark: search_flights(destination='Vancouver', date='November 5'); book_flight(passenger_name='Skylar'); update_identity_doc(doc_type='visa', doc_number='V44')
- latency: {'input_duration_s': 56.76, 'output_duration_s': 56.76, 'first_speech_s': 32.6}
- kernel: 25 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 3, 'final': 1}; gate holds {}
- decision log: decisions/eval-c054e89f.jsonl

## Passing recordings
ecommerce_01, ecommerce_01, ecommerce_02, ecommerce_04, ecommerce_05, ecommerce_06, ecommerce_09, ecommerce_10, ecommerce_11, ecommerce_13, ecommerce_13, ecommerce_14, ecommerce_14, ecommerce_15, ecommerce_15, ecommerce_16, ecommerce_17, ecommerce_18, ecommerce_19, ecommerce_21, ecommerce_21, ecommerce_23, ecommerce_25, finance_01, finance_01, finance_02, finance_03, finance_03, finance_04, finance_06, finance_07, finance_07, finance_08, finance_08, finance_10, finance_11, finance_12, finance_12, finance_14, finance_15, finance_16, finance_17, finance_18, finance_19, finance_21, finance_22, finance_23, housing_01, housing_02, housing_03, housing_04, housing_06, housing_09, housing_10, housing_13, housing_17, housing_17, travel_01, travel_03, travel_03, travel_05, travel_07, travel_07, travel_08, travel_10, travel_11, travel_14, travel_16, travel_18, travel_21, travel_21, travel_23, travel_23
