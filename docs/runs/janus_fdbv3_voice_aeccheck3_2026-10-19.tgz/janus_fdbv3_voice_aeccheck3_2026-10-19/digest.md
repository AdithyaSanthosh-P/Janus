# Run digest: 20261019_175544

- Scenarios scored: 3  passed: 3  failed: 0  strict pass rate: 1.0
- Janus commit: `f911a194d5899633830f84cfc3751eaaa5487b82`  FDB commit: `3e799c45a045256f47d5f1c9cda90157e2d2ec9e`
- Judge: on (FDB --use-llm)
- Tool metrics: {"tool_selection_acc": 1.0, "argument_acc": 1.0, "response_qual": 0.333, "tool_selection_acc_all": 1.0, "argument_acc_all": 1.0, "note": "*_all includes no-response samples (scored 0); default metrics are turn-taken only"}
- Turn-taking: {"total": 3, "turn_taken": 3, "no_response": 0, "turn_take_rate": 1.0}  Latency: {"total_samples": 3, "interruption_count": 0, "interruption_rate": 0.0, "avg_response_latency_s": 7.573, "std_response_latency_s": 4.163, "min_latency_s": 4.24, "max_latency_s": 12.24, "note": "avg/std/min/max exclude interruption samples; computed on turn-taken samples only"}
- by_domain: {"finance_billing": 1.0, "travel_identity": 1.0}
- by_difficulty: {"medium": 1.0, "easy": 1.0}
- by_num_tools: {"1": 1.0}
- by_disfluency_feature: {"HESITATION": 1.0, "PAUSE": 1.0, "FILLER": 1.0, "SELF_CORRECTION": 1.0}
- by_state_rollback: {"with_rollback": 1.0, "without_rollback": 1.0}
- failure_breakdown: {"wrong_tools": 0, "wrong_arguments": 0}
- Recordings re-streamed after a client abort: 0

## Agent log: top errors (de-duplicated)
- none

## Failures by guessed cause (0 total)

## Failing recordings


## Passing recordings
finance_04, finance_16, travel_10
