# Janus x FDB-v3 run

- Janus commit: `unknown`  FDB commit: `3e799c45a045256f47d5f1c9cda90157e2d2ec9e`
- Judge: off (exact-match scoring only)
- Scenarios: 32  passed: 11  failed: 21
- Strict pass rate: 0.344

Provider declaration: custom LiveKit agent (Janus). Decisions by the Janus kernel with gemini-3.6-flash (hosted Gemini API, thinking budget 0, temperature 0); speech: faster-whisper large-v3-turbo (STT), Kokoro-82M (TTS), Silero VAD, all local.
