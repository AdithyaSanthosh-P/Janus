# Run digest: 20261019_142138

- Scenarios scored: 100  passed: 77  failed: 23  strict pass rate: 0.77
- Janus commit: `f911a194d5899633830f84cfc3751eaaa5487b82`  FDB commit: `3e799c45a045256f47d5f1c9cda90157e2d2ec9e`
- Judge: on (FDB --use-llm)
- Tool metrics: {"tool_selection_acc": 0.951, "argument_acc": 0.838, "response_qual": 0.72, "tool_selection_acc_all": 0.951, "argument_acc_all": 0.838, "note": "*_all includes no-response samples (scored 0); default metrics are turn-taken only"}
- Turn-taking: {"total": 100, "turn_taken": 100, "no_response": 0, "turn_take_rate": 1.0}  Latency: {"total_samples": 100, "interruption_count": 1, "interruption_rate": 0.01, "avg_response_latency_s": 6.66, "std_response_latency_s": 4.042, "min_latency_s": 4.0, "max_latency_s": 26.96, "note": "avg/std/min/max exclude interruption samples; computed on turn-taken samples only"}
- by_domain: {"ecommerce_support": 0.793, "travel_identity": 0.85, "finance_billing": 0.8, "housing_location": 0.654}
- by_difficulty: {"easy": 0.861, "medium": 0.824, "hard": 0.6}
- by_num_tools: {"1": 0.848, "2": 0.667, "3": 0.562}
- by_disfluency_feature: {"FALSE_START": 0.75, "FILLER": 0.897, "HESITATION": 0.8, "SELF_CORRECTION": 0.765, "PAUSE": 0.611}
- by_state_rollback: {"with_rollback": 0.765, "without_rollback": 0.771}
- failure_breakdown: {"wrong_tools": 7, "wrong_arguments": 16}
- Recordings re-streamed after a client abort: 0

## Agent log: top errors (de-duplicated)
- 16x ERROR:livekit:livekit::rtc_engine::rtc_session:#:livekit::rtc_engine::rtc_session - publisher data channel '_reliable' closed unexpectedly
- 12x ERROR:livekit:livekit::rtc_engine::rtc_session:#:livekit::rtc_engine::rtc_session - publisher data channel '_lossy' closed unexpectedly
- 12x ERROR:livekit:livekit::rtc_engine::rtc_session:#:livekit::rtc_engine::rtc_session - publisher data channel '_data_track' closed unexpectedly

## Failures by guessed cause (23 total)
- wrong_args: 14
- silent: 4
- wrong_tools: 3
- stt: 2

## Failing recordings

### ecommerce_07  [ecommerce_support, easy, FALSE_START]  cause guess: wrong_args: track_order
- reason: Wrong arguments for: ['track_order']
- expected tools: ['track_order']  actual: ['track_order']
- wrong arguments:
    track_order: expected {'order_id': 'FAST99'} got {'order_id': 'FAST999'} (The actual argument 'FAST999' does not match the expected argument 'FAST99'.)
- reference transcript: So, could you? Um, I wanted to search for a new product. Actually, no, never mind, never mind, forget that for now. Could you just track my order instead? Um, the ID is FAST99.
- agent heard (1 turn end(s)): So, could you, um, I wanted to search for a new product. Actually, no, never mind, never mind. Forget that for now. Could you just track my order instead? Um, the ID is FAST999.
- agent said: [speak] I will track your order with ID FAST999. | [final] Your order FAST999 is currently out for delivery.
- calls emitted (wire): track_order(order_id='FAST999')
- calls recorded by the benchmark: track_order(order_id='FAST999')
- latency: {'input_duration_s': 50.04, 'output_duration_s': 50.04, 'first_speech_s': 23.05}
- kernel: 11 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-b50e4a4e.jsonl
### ecommerce_08  [ecommerce_support, easy, PAUSE]  cause guess: wrong_args: search_products
- reason: Wrong arguments for: ['search_products']
- expected tools: ['search_products']  actual: ['search_products']
- wrong arguments:
    search_products: expected {'query': 'mechanical keyboards', 'max_price': 200} got {'query': 'mechanical keyboard', 'max_price': 200} (The query argument 'mechanical keyboard' does not match the expected 'mechanical keyboards'.)
- reference transcript: Ah, hmm. You know, um, I want a mechanical keyboard and I'm trying, um, to keep my budget under two hundred dollars. Do you have anything like that?
- agent heard (1 turn end(s)): A You know, um... I want a mechanical keyboard, and I'm trying to keep my budget under... Two hundred dollars? Do you have anything like that?
- agent said: [speak] I'll search for mechanical keyboards under 200 dollars. | [final] I found the mechanical keyboard Premium priced at $190 with product ID PROD1.
- calls emitted (wire): search_products(query='mechanical keyboard', max_price=200)
- calls recorded by the benchmark: search_products(query='mechanical keyboard', max_price=200)
- latency: {'input_duration_s': 45.78, 'output_duration_s': 45.78, 'first_speech_s': 19.55}
- kernel: 17 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-52021425.jsonl
### ecommerce_08  [ecommerce_support, easy, PAUSE]  cause guess: wrong_args: search_products
- reason: Wrong arguments for: ['search_products']
- expected tools: ['search_products']  actual: ['search_products']
- wrong arguments:
    search_products: expected {'query': 'mechanical keyboards', 'max_price': 200} got {'query': 'mechanical keyboard', 'max_price': 200} (The 'query' argument is incorrect. 'mechanical keyboard' is singular, while the expected argument is 'mechanical keyboa…)
- reference transcript: Um, yeah, you know, uh, I want a mechanical keyboard, and I'm trying to keep my budget under $200. Do you have anything like that?
- agent heard (1 turn end(s)): Yeah, you know, I want a mechanical keyboard, and I'm trying to keep my budget under $200. Do you have anything like that?
- agent said: [speak] I'll search for mechanical keyboards under $200. | [final] I found the mechanical keyboard Premium priced at 190 dollars, matching product ID PROD1.
- calls emitted (wire): search_products(query='mechanical keyboard', max_price=200)
- calls recorded by the benchmark: search_products(query='mechanical keyboard', max_price=200)
- latency: {'input_duration_s': 43.44, 'output_duration_s': 43.44, 'first_speech_s': 20.7}
- kernel: 16 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {'G10:search_products': 1}
- decision log: decisions/eval-a4068a78.jsonl
### ecommerce_12  [ecommerce_support, medium, HESITATION,PAUSE]  cause guess: wrong_args: search_products
- reason: Wrong arguments for: ['search_products']
- expected tools: ['search_products']  actual: ['search_products']
- wrong arguments:
    search_products: expected {'query': 'gift', 'category': 'electronics'} got {'query': 'electronics'} (The actual arguments are missing the 'category' argument and the 'query' argument does not match the expected value.)
- reference transcript: Like, you know, um, I'm thinking something in the let me think electronics section of the grid. He's really into gadgets and text stuff.
- agent heard (1 turn end(s)): Like, you know, I'm thinking something in the, let me think, electronics section would be great. He's really into gadgets and tech stuff.
- agent said: [speak] I'll search for products in the electronics section. | [final] I found the electronics Premium product priced at $99.99 with the product ID PROD1.
- calls emitted (wire): search_products(query='electronics')
- calls recorded by the benchmark: search_products(query='electronics')
- latency: {'input_duration_s': 41.264, 'output_duration_s': 41.264, 'first_speech_s': 19.3}
- kernel: 12 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {'G10:search_products': 1}
- decision log: decisions/eval-835db7dd.jsonl
### ecommerce_20  [ecommerce_support, hard, no disfluency]  cause guess: wrong_args: search_products
- reason: Wrong arguments for: ['search_products']
- expected tools: ['search_products', 'add_to_cart']  actual: ['search_products', 'add_to_cart']
- wrong arguments:
    search_products: expected {'query': 'coffee maker'} got {'query': 'coffee maker', 'max_price': 50} (The actual arguments include an extra 'max_price' parameter which is not expected.)
- reference transcript: So, you know, so search for a coffee maker first. If you find one that's under $50, go ahead and add two to the cart because they make great gifts. But if everything's over $50, I'd just forget the coffee maker and track order WWW for me instead.
- agent heard (1 turn end(s)): So, you know, I... So search for a coffee maker first. If you find one that's under $50, go ahead and add two to the cart because they make great gifts. But if everything's over $50, just forget the coffee maker and track order www for me instead.
- agent said: [speak] I'll search for coffee makers under $50 to add two to your cart, or track order www for you if none are under $50. | [final] I searched for coffee makers under 50 dollars and found the coffee maker Premium for 40 dollars, then added a quantity of 2 to your cart for a total of 199.98 dollars. Since we found a model under 50 dollars, I did not track the order, but let me know if you would like me to do that.
- calls emitted (wire): search_products(query='coffee maker', max_price=50); add_to_cart(product_id='PROD1', quantity=2)
- calls recorded by the benchmark: search_products(query='coffee maker', max_price=50); add_to_cart(product_id='PROD1', quantity=2)
- latency: {'input_duration_s': 54.629, 'output_duration_s': 54.629, 'first_speech_s': 29.95}
- kernel: 17 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 2, 'final': 1}; gate holds {}
- decision log: decisions/eval-ba40534d.jsonl
### ecommerce_25  [ecommerce_support, hard, FALSE_START]  cause guess: wrong_args: track_order
- reason: Wrong arguments for: ['track_order']
- expected tools: ['track_order', 'search_products', 'add_to_cart']  actual: ['track_order', 'search_products', 'add_to_cart']
- wrong arguments:
    track_order: expected {'order_id': 'CAT'} got {'order_id': 'ZAT'} (The actual argument 'order_id': 'ZAT' does not match the expected argument 'order_id': 'CAT'.)
- reference transcript: You know, um, well, can um I return my never mind, uh, forget the return. Let me focus on what I actually need. Track order CAT for me, then search for cat food because I'm running low and add three of whatever you find to my card.
- agent heard (1 turn end(s)): You know, um, well... Can I return my... Never mind, forget the return. Let me focus on what I actually need. Check order ZAT for me. and search for cat food because I'm running low. And add three of whatever you find to my cart.
- agent said: [speak] I'll track order ZAT, search for cat food, and add three of the product found to your cart. | [final] Your order ZAT is currently out for delivery. I have also added three units of cat food Premium to your cart for a total of 299.97.
- calls emitted (wire): track_order(order_id='ZAT'); search_products(query='cat food'); add_to_cart(product_id='PROD1', quantity=3)
- calls recorded by the benchmark: track_order(order_id='ZAT'); search_products(query='cat food'); add_to_cart(product_id='PROD1', quantity=3)
- latency: {'input_duration_s': 53.7, 'output_duration_s': 53.7, 'first_speech_s': 28.4}
- kernel: 26 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 3, 'final': 1}; gate holds {}
- decision log: decisions/eval-edce8e7a.jsonl
### finance_04  [finance_billing, easy, PAUSE]  cause guess: silent: the agent made no calls
- reason: Missing tools: ['get_exchange_rate']
- expected tools: ['get_exchange_rate']  actual: []
- reference transcript: I need uh to figure out how much one thousand US dollars would be in uh British pounds. Uh do you know the current rate?
- agent heard (2 turn end(s)): I need to figure out how much $1,000 would be in... Right. You know the current rate?
- agent said: [speak] Got it, working on it. | [clarify] I need a bit more information — what should from currency be?
- calls emitted (wire): none
- calls recorded by the benchmark: none
- latency: {'input_duration_s': 39.54, 'output_duration_s': 39.54, 'first_speech_s': 9.0}
- kernel: 19 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'clarify': 1}; gate holds {}
- decision log: decisions/eval-b53e004a.jsonl
### finance_10  [finance_billing, medium, no disfluency]  cause guess: wrong_tools: missing ['get_card_benefits'] unexpected []
- reason: Missing tools: ['get_card_benefits']
- expected tools: ['get_card_benefits', 'get_exchange_rate']  actual: ['get_exchange_rate']
- reference transcript: Firstly, could you tell me what the benefits are for the travel card? I'm considering applying and then separately, I also need to know how much 200 British pounds would be in Japanese yen.
- agent heard (1 turn end(s)): Firstly, could you tell me what the benefits are for the travel card? I'm considering applying and then separately, I also need to know how much 200 British pounds would be in Japanese yen.
- agent said: [speak] I'll check the card benefits for the travel card and convert 200 British pounds to Japanese yen for you. | [clarify] I need a bit more information — what should card type be?
- calls emitted (wire): get_exchange_rate(amount=200, from_currency='GBP', to_currency='JPY')
- calls recorded by the benchmark: get_exchange_rate(amount=200, from_currency='GBP', to_currency='JPY')
- latency: {'input_duration_s': 46.331, 'output_duration_s': 46.331, 'first_speech_s': 20.65}
- kernel: 14 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'clarify': 1}; gate holds {}
- decision log: decisions/eval-b46c1f28.jsonl
### finance_16  [finance_billing, medium, HESITATION,PAUSE]  cause guess: silent: the agent made no calls
- reason: Missing tools: ['get_exchange_rate']
- expected tools: ['get_exchange_rate']  actual: []
- reference transcript: Like, okay, so um, I need to know how much. Let me see five hundred yen would be in dollars. I'm trying to figure out if this online purchase is worth it.
- agent heard (2 turn end(s)): Like, okay, so... I need to know how much. Let me see. I'm trying to figure out if this online purchase is worth it.
- agent said: [speak] Sorry, I didn't quite catch what you'd like me to do — could you say that again?
- calls emitted (wire): none
- calls recorded by the benchmark: none
- latency: {'input_duration_s': 43.92, 'output_duration_s': 43.92, 'first_speech_s': 10.8}
- kernel: 14 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1}; gate holds {}
- decision log: decisions/eval-7cf26ded.jsonl
### finance_18  [finance_billing, hard, no disfluency]  cause guess: wrong_args: get_exchange_rate
- reason: Wrong arguments for: ['get_exchange_rate']
- expected tools: ['get_exchange_rate', 'modify_autopay', 'get_card_benefits']  actual: ['get_exchange_rate', 'modify_autopay', 'get_card_benefits']
- wrong arguments:
    get_exchange_rate: expected {'amount': 1000, 'from_currency': 'USD', 'to_currency': 'EUR'} got {'amount': 1000, 'from_currency': 'USD', 'to_currency': 'UAH'} (The 'to_currency' argument is 'UAH' instead of the expected 'EUR'.)
- reference transcript: Um so alright, so first um I need to know how much thousand US dollars would be in Euros. Then I want to change my credit card or to pay so it pulls from the savings instead. And finally, can you tell me what kind of benefits the premium card has?
- agent heard (1 turn end(s)): Um, so all right, so first, um, I need to know how much thousand US dollars would be in UAH. Then I want to change my credit card autopay so it pulls from the savings instead. And finally, can you tell me what kind of benefits the premium card has?
- agent said: [speak] I'll get the exchange rate for 1000 USD to UAH, update your credit card autopay to draw from savings, and look up the benefits for the premium card. | [final] I converted 1000 USD to 900 UAH at a rate of 0.9, confirmed your autopay for the credit card bill using your savings account, and retrieved your premium card benefits which include 2% Cashback and No Foreign Transaction Fee.
- calls emitted (wire): get_exchange_rate(amount=1000, from_currency='USD', to_currency='UAH'); modify_autopay(bill_type='credit_card', source_account='savings'); get_card_benefits(card_type='premium')
- calls recorded by the benchmark: get_exchange_rate(amount=1000, from_currency='USD', to_currency='UAH'); modify_autopay(bill_type='credit_card', source_account='savings'); get_card_benefits(card_type='premium')
- latency: {'input_duration_s': 49.797, 'output_duration_s': 49.797, 'first_speech_s': 24.7}
- kernel: 14 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 3, 'final': 1}; gate holds {}
- decision log: decisions/eval-2c208ed5.jsonl
### finance_20  [finance_billing, hard, no disfluency]  cause guess: wrong_tools: missing ['modify_autopay'] unexpected []
- reason: Missing tools: ['modify_autopay']
- expected tools: ['get_exchange_rate', 'modify_autopay']  actual: ['get_exchange_rate']
- reference transcript: Well, here's my situation. I want to check what 1,000 US dollars is in Euros right now. If the exchange rate looks good to me, then go ahead and change my mortgage auto pay to pull from checking. But if the rate isn't great, just leave everything as is and keep it on the savings.
- agent heard (1 turn end(s)): Well, here's my situation. I want to check what $1,000 US dollars is in euros right now. If the exchange rate looks good to me, then go ahead and change my mortgage auto-pay to pull from checking. But if the rate isn't great, just leave everything as is and keep it on the savings.
- agent said: [speak] I'll check the exchange rate for $1,000 USD to EUR, and if it looks good, update your mortgage auto-pay source account to checking. | [final] I converted 1000 USD to EUR at a rate of 0.9, giving you 900 EUR. I did not update your autopay settings since that depended on if you liked the rate, but let me know if you would like me to change it.
- calls emitted (wire): get_exchange_rate(amount=1000, from_currency='USD', to_currency='EUR')
- calls recorded by the benchmark: get_exchange_rate(amount=1000, from_currency='USD', to_currency='EUR')
- latency: {'input_duration_s': 52.576, 'output_duration_s': 52.576, 'first_speech_s': 29.75}
- kernel: 12 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-6653b00b.jsonl
### housing_11  [housing_location, medium, SELF_CORRECTION]  cause guess: silent: the agent made no calls
- reason: Missing tools: ['search_apartments']
- expected tools: ['search_apartments']  actual: []
- reference transcript: Uh well, I was thinking a one bedroom under twelve well actually no wait, my partner is moving in with me, so we need a two bedroom and we can go up uh uh up to sixteen hundred a month.
- agent heard (1 turn end(s)): Well, I was thinking a one bedroom under 12, but actually, no, wait, my partner is moving in with me, so we need a two bedroom, and we need to go up to 1600 a month.
- agent said: [speak] I'll search for two bedroom apartments up to 1600 a month, assuming a city. | [clarify] I need a bit more information — what should city be?
- calls emitted (wire): none
- calls recorded by the benchmark: none
- latency: {'input_duration_s': 41.46, 'output_duration_s': 41.46, 'first_speech_s': 18.0}
- kernel: 9 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'clarify': 1}; gate holds {}
- decision log: decisions/eval-cccf58fb.jsonl
### housing_13  [housing_location, medium, no disfluency]  cause guess: wrong_args: update_search_filter
- reason: Wrong arguments for: ['update_search_filter']
- expected tools: ['update_search_filter', 'update_search_filter']  actual: ['update_search_filter', 'update_search_filter']
- wrong arguments:
    update_search_filter: expected {'filter_name': 'min_bedrooms', 'value': 3} got {'filter_name': 'bedrooms', 'value': 3} (The expected argument 'filter_name' is 'min_bedrooms', but the actual argument provided is 'bedrooms', which does not m…)
- reference transcript: You know, like, you know, let's raise the max price to three thousand per month and also bump up the minimum bedrooms to three. Yeah, I think I need more space than I originally thought.
- agent heard (1 turn end(s)): You know, like, you know, let's raise the max price to $3,000 per month. And also bump up the minimum bedrooms to three. Um, yeah, I think I need more space than I originally thought.
- agent said: [speak] I'll update your search filters to a max price of 3000 and a minimum of 3 bedrooms. | [final] I have updated your search filters to a maximum price of 3000 and set the bedroom count to 3.
- calls emitted (wire): update_search_filter(filter_name='max_price', value=3000); update_search_filter(filter_name='bedrooms', value=3)
- calls recorded by the benchmark: update_search_filter(filter_name='max_price', value=3000); update_search_filter(filter_name='bedrooms', value=3)
- latency: {'input_duration_s': 48.507, 'output_duration_s': 48.507, 'first_speech_s': 24.1}
- kernel: 17 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 2, 'final': 1}; gate holds {}
- decision log: decisions/eval-d9bacad7.jsonl
### housing_15  [housing_location, medium, FALSE_START]  cause guess: stt: the agent heard a different sentence (75% word overlap with the reference transcript)
- reason: Wrong arguments for: ['search_apartments']
- expected tools: ['search_apartments']  actual: ['search_apartments']
- wrong arguments:
    search_apartments: expected {'city': 'Atlanta', 'bedrooms': 3, 'pets_allowed': True} got {'city': 'Atlanta', 'bedrooms': 1, 'pets_allowed': True} (The 'bedrooms' argument is incorrect. Expected 3, but got 1.)
- reference transcript: Um so hmm uh I wanted um to check the commute from that one listing. Actually let me skip that for now. Could you just search for a three-bedroom in Atlanta that's pet-friendly? I've got two cats.
- agent heard (1 turn end(s)): I wanted to check the commute from that one listing. Actually, let me skip that. Could you just... The bedroom in Atlanta that's pet friendly. I've got two cats.
- agent said: [speak] I'll search for pet-friendly 1-bedroom apartments in Atlanta. | [final] I found a one-bedroom apartment listing in Atlanta with the ID APT1.
- calls emitted (wire): search_apartments(city='Atlanta', bedrooms=1, pets_allowed=True)
- calls recorded by the benchmark: search_apartments(city='Atlanta', bedrooms=1, pets_allowed=True)
- latency: {'input_duration_s': 48.42, 'output_duration_s': 48.42, 'first_speech_s': 25.3}
- kernel: 17 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-a7e16aa8.jsonl
### housing_18  [housing_location, hard, no disfluency]  cause guess: wrong_args: search_apartments
- reason: Wrong arguments for: ['search_apartments']
- expected tools: ['search_apartments', 'calculate_commute']  actual: ['search_apartments', 'calculate_commute']
- wrong arguments:
    search_apartments: expected {'city': 'Portland', 'bedrooms': 1, 'max_price': 1800} got {'city': 'Portland', 'bedrooms': 1, 'max_price': 800} (The 'max_price' argument is outside the acceptable numeric tolerance. Expected 1800, but got 800, which is not within ±…)
- reference transcript: Well so first, search for a one-bedroom in Portland that's under $800 per month, then once you find the cheapest option, check how long it would take to bike from there to the coffee shop on 5th Street where I work.
- agent heard (1 turn end(s)): Well, so first, search for a one-bedroom in Portland that's under $800 per month. Then, once you find the cheapest option, check how long it would take to bike from there to the coffee shop on 5th Street where I work.
- agent said: [speak] I'll search for a 1-bedroom apartment in Portland under $800 per month, then calculate the biking commute from the cheapest option to the coffee shop on 5th Street. | [final] I found a one bedroom apartment in Portland, APT1, listed for 700 dollars. The biking commute from APT1 to the coffee shop on 5th Street takes about 25 minutes.
- calls emitted (wire): search_apartments(city='Portland', bedrooms=1, max_price=800); calculate_commute(origin_address='APT1', destination_address='the coffee shop on 5th Street', mode='biking')
- calls recorded by the benchmark: search_apartments(city='Portland', bedrooms=1, max_price=800); calculate_commute(origin_address='APT1', destination_address='the coffee shop on 5th Street', mode='biking')
- latency: {'input_duration_s': 47.685, 'output_duration_s': 47.685, 'first_speech_s': 21.9}
- kernel: 14 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 2, 'final': 1}; gate holds {}
- decision log: decisions/eval-3a751fb5.jsonl
### housing_21  [housing_location, hard, SELF_CORRECTION]  cause guess: silent: the agent made no calls
- reason: Missing tools: ['search_apartments', 'calculate_commute']
- expected tools: ['search_apartments', 'calculate_commute']  actual: []
- reference transcript: So well, so you know I want to search for a place with two bedrooms. Wait, actually, I mean, I meant three bedrooms. We decided we need a home office. Also, check the transit time to the train station. Actually, I'd rather walk, so make that walk-in time.
- agent heard (1 turn end(s)): So, well, so you know, I want to search for a place with two bedrooms. Wait, actually, I mean, I meant three bedrooms. We decided we need a home office. Also check the transit time to the train station. Actually, I'd rather walk, so make that. Walking time.
- agent said: [speak] I'll search for 3-bedroom places and calculate the walking commute time to the train station. | [clarify] I need a bit more information — what should city be?
- calls emitted (wire): none
- calls recorded by the benchmark: none
- latency: {'input_duration_s': 49.725, 'output_duration_s': 49.725, 'first_speech_s': 24.0}
- kernel: 12 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'clarify': 1}; gate holds {}
- decision log: decisions/eval-5e72430f.jsonl
### housing_22  [housing_location, hard, FILLER]  cause guess: wrong_args: search_apartments
- reason: Wrong arguments for: ['search_apartments']
- expected tools: ['update_search_filter', 'search_apartments', 'calculate_commute']  actual: ['update_search_filter', 'search_apartments', 'calculate_commute']
- wrong arguments:
    search_apartments: expected {'city': 'Seattle', 'bedrooms': 1} got {'city': 'Seattle', 'bedrooms': 1, 'pets_allowed': True} (The actual arguments include an unexpected 'pets_allowed' key which is not part of the expected arguments.)
- reference transcript: You know, um, can you first update my filter so pets are allowed? Um, I keep forgetting to set that. Then, like, search in Seattle for one bedroom. And then once you find something, uh, check the transit time from there to the stadium because, you know, I go to games pretty often.
- agent heard (1 turn end(s)): You know, um, can you first update my filter so pets are allowed? Um, I keep forgetting to set that. Then, like, search in Seattle for one bedroom. And then once you find something, check the transit time. From there to the stadium, because, you know, I go to games pretty often.
- agent said: [speak] I'll update your filter to allow pets, search for a one-bedroom apartment in Seattle, and calculate the transit time from there to the stadium. | [final] I updated your search to allow pets and found a one-bedroom apartment with ID APT1 in Seattle. The transit commute from APT1 to the stadium is estimated at 25 minutes.
- calls emitted (wire): update_search_filter(filter_name='pets_allowed', value=True); search_apartments(city='Seattle', bedrooms=1, pets_allowed=True); calculate_commute(origin_address='APT1', destination_address='the stadium', mode='transit')
- calls recorded by the benchmark: update_search_filter(filter_name='pets_allowed', value=True); search_apartments(city='Seattle', bedrooms=1, pets_allowed=True); calculate_commute(origin_address='APT1', destination_address='the stadium', mode='transit')
- latency: {'input_duration_s': 50.1, 'output_duration_s': 50.1, 'first_speech_s': 24.15}
- kernel: 24 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 3, 'final': 1}; gate holds {}
- decision log: decisions/eval-a50eda87.jsonl
### housing_24  [housing_location, hard, PAUSE,FILLER]  cause guess: wrong_args: search_apartments
- reason: Wrong arguments for: ['search_apartments', 'calculate_commute']
- expected tools: ['update_search_filter', 'search_apartments', 'calculate_commute']  actual: ['update_search_filter', 'search_apartments', 'calculate_commute']
- wrong arguments:
    search_apartments: expected {'city': 'Dallas'} got {'city': 'Dallas', 'max_price': 1500} (The actual arguments include an extra argument 'max_price' which is not expected.)
    calculate_commute: expected {'origin_address': '$RESULT_1.apartments[0].address', 'destination_address': 'the grocery store', 'mode': 'walking'} got {'origin_address': 'APT1', 'destination_address': 'grocery store', 'mode': 'walking'} (The destination_address 'grocery store' does not match the expected 'the grocery store' due to the missing 'the'.)
- reference transcript: Um, so hmm, like, you know, okay. So, first, um, I want to update my max price to $1,500 because I'm on a tighter budget. Then, uh, search for apartments in Dallas that fit that budget, and then check the walking time from whatever you find to the grocery store because I want to be close to one.
- agent heard (1 turn end(s)): Like, you know. OK, so first, I want to update my max price to $1500 because I'm on a tighter budget. Then, search for apartments in Dallas that fit that budget, and then... Check the walking time from whatever you find to the grocery store because I want to be close to one.
- agent said: [speak] I'll update your max price filter to 1500, search for apartments in Dallas within that budget, and calculate the walking commute time from the search result to the grocery store. | [final] I updated your maximum price filter to 1500, found apartment APT1 in Dallas for 1400 dollars, and confirmed a 25 minute walking commute to the grocery store.
- calls emitted (wire): update_search_filter(filter_name='max_price', value=1500); search_apartments(city='Dallas', max_price=1500); calculate_commute(origin_address='APT1', destination_address='grocery store', mode='walking')
- calls recorded by the benchmark: update_search_filter(filter_name='max_price', value=1500); search_apartments(city='Dallas', max_price=1500); calculate_commute(origin_address='APT1', destination_address='grocery store', mode='walking')
- latency: {'input_duration_s': 56.1, 'output_duration_s': 56.1, 'first_speech_s': 34.35}
- kernel: 23 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 3, 'final': 1}; gate holds {'G10:update_search_filter': 1}
- decision log: decisions/eval-9e0c28c1.jsonl
### housing_24  [housing_location, hard, PAUSE,FILLER]  cause guess: wrong_args: search_apartments
- reason: Wrong arguments for: ['search_apartments']
- expected tools: ['update_search_filter', 'search_apartments', 'calculate_commute']  actual: ['update_search_filter', 'search_apartments', 'calculate_commute']
- wrong arguments:
    search_apartments: expected {'city': 'Dallas'} got {'city': 'Dallas', 'max_price': 1500} (The actual arguments include an extra 'max_price' argument which is not expected.)
- reference transcript: Um so hmm like you know okay so first um I want to update my max price to 1500 because I'm on a tighter budget then uh search for apartments in Dallas that fit that budget and then check the walking time from whatever you find to the grocery store because I want to be close to one
- agent heard (1 turn end(s)): Like, you know, OK. So first, I want to update my max price to $1500. Because I'm on a tighter budget. Then, search for apartments in Dallas that fit that budget. And then... Check the walking time from wherever you find to the grocery store because I wanna be close to one.
- agent said: [speak] I'll update your maximum price filter to $1500, search for apartments in Dallas within that budget, and check the walking time from the found apartment to the nearest grocery store. | [final] I updated your maximum price filter to 1500 and found apartment APT1 in Dallas for 1400 dollars per month. The walking commute from APT1 to the grocery store takes 25 minutes.
- calls emitted (wire): update_search_filter(filter_name='max_price', value=1500); search_apartments(city='Dallas', max_price=1500); calculate_commute(origin_address='APT1', destination_address='grocery store', mode='walking')
- calls recorded by the benchmark: update_search_filter(filter_name='max_price', value=1500); search_apartments(city='Dallas', max_price=1500); calculate_commute(origin_address='APT1', destination_address='grocery store', mode='walking')
- latency: {'input_duration_s': 59.16, 'output_duration_s': 59.16, 'first_speech_s': 33.85}
- kernel: 26 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 3, 'final': 1}; gate holds {}
- decision log: decisions/eval-f4ccdf1e.jsonl
### housing_25  [housing_location, hard, SELF_CORRECTION]  cause guess: wrong_args: search_apartments
- reason: Wrong arguments for: ['search_apartments']
- expected tools: ['update_search_filter', 'update_search_filter', 'search_apartments']  actual: ['update_search_filter', 'update_search_filter', 'search_apartments']
- wrong arguments:
    search_apartments: expected {'city': 'San Francisco'} got {'city': 'San Francisco', 'pets_allowed': True, 'max_price': 3500} (The actual arguments include 'pets_allowed' and 'max_price', which are not expected.)
- reference transcript: You know, you know, alright, first set the filter so pets are allowed and set the max price to 3,000. Then search for places in San Francisco. Wait, actually change the max price to 3500 instead. San Francisco is expensive, so I need more room in the budget.
- agent heard (1 turn end(s)): You know, you know, all right, first set the filter so pets are allowed, and set the max price to $3,000. Then search for places in San Francisco. Wait, actually, change the max price to $3,500 instead. San Francisco is expensive, so I need more room in the budget.
- agent said: [speak] I'll update the filter to allow pets, set the max price to $3,500, and search for apartments in San Francisco. | [final] I updated your search filters to allow pets and set a maximum price of 3500 dollars. In San Francisco, I found one apartment matching your criteria, listing ID APT1 for 3400 dollars.
- calls emitted (wire): update_search_filter(filter_name='pets_allowed', value=True); update_search_filter(filter_name='max_price', value=3500); search_apartments(city='San Francisco', pets_allowed=True, max_price=3500)
- calls recorded by the benchmark: update_search_filter(filter_name='pets_allowed', value=True); update_search_filter(filter_name='max_price', value=3500); search_apartments(city='San Francisco', pets_allowed=True, max_price=3500)
- latency: {'input_duration_s': 51.48, 'output_duration_s': 51.48, 'first_speech_s': 25.1}
- kernel: 17 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 3, 'final': 1}; gate holds {}
- decision log: decisions/eval-7bdc62a0.jsonl
### travel_02  [travel_identity, easy, no disfluency]  cause guess: stt: the agent heard a different sentence (78% word overlap with the reference transcript)
- reason: Wrong arguments for: ['update_identity_doc']
- expected tools: ['update_identity_doc']  actual: ['update_identity_doc']
- wrong arguments:
    update_identity_doc: expected {'doc_type': 'passport', 'doc_number': 'P9-9-9-90011'} got {'doc_type': 'passport', 'doc_number': 'P88990011'} (The doc_number 'P88990011' does not match the expected format 'P9-9-9-90011' and is not within a 5% numeric tolerance.)
- reference transcript: Uh, yeah, so my new passport number is P eight eight nine nine zero zero one one. Could you update that in the system for me, please?
- agent heard (1 turn end(s)): Uh, yeah, so my new passport number is P88990011. Could you update that in the system for me, please?
- agent said: [speak] I'll update your passport number to P88990011 in the system. | [final] I have updated your passport details to end in 0011, and the change is confirmed.
- calls emitted (wire): update_identity_doc(doc_type='passport', doc_number='P88990011')
- calls recorded by the benchmark: update_identity_doc(doc_type='passport', doc_number='P88990011')
- latency: {'input_duration_s': 44.52, 'output_duration_s': 44.52, 'first_speech_s': 17.9}
- kernel: 12 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-00008368.jsonl
### travel_19  [travel_identity, hard, SELF_CORRECTION]  cause guess: wrong_args: search_flights
- reason: Wrong arguments for: ['search_flights']
- expected tools: ['search_flights']  actual: ['search_flights']
- wrong arguments:
    search_flights: expected {'destination': 'Milan', 'date': 'June 3'} got {'destination': 'Mulan', 'date': 'June 3'} (The destination argument is incorrect; 'Milan' was expected, but 'Mulan' was provided.)
- reference transcript: Um, okay, I want to look for flights to Rome. No, wait, I changed my mind. Let's do Milan instead. And I was thinking June 1st. Well, wait, but actually, June 3rd works better for me. Sorry about that.
- agent heard (1 turn end(s)): Um, okay, I wanna look for flights to Rome. No way, I changed my mind, let's do Mulan instead. And I was thinking June 1st. Well, wait, but actually, June 3rd works better for me. Sorry about that.
- agent said: [speak] I'll search for flights to Mulan for June 3rd. | [final] I found a flight to Mulan on June 3rd, flight FL123, priced at $450.
- calls emitted (wire): search_flights(destination='Mulan', date='June 3')
- calls recorded by the benchmark: search_flights(destination='Mulan', date='June 3')
- latency: {'input_duration_s': 49.14, 'output_duration_s': 49.14, 'first_speech_s': 22.4}
- kernel: 20 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-8ff99cf7.jsonl
### travel_20  [travel_identity, hard, no disfluency]  cause guess: wrong_tools: missing ['book_flight'] unexpected []
- reason: Missing tools: ['book_flight']
- expected tools: ['search_flights', 'book_flight', 'update_identity_doc']  actual: ['search_flights', 'update_identity_doc']
- reference transcript: Here's the thing, I I need to fly to Toronto on July 20th. If there happens to be a flight under $300, go ahead and book it for Riley-Kin. But if everything's too expensive, then just forget the flight and update my driver's license to DL88 instead.
- agent heard (1 turn end(s)): Here's the thing, I need to fly to Toronto on July 20th. If there happens to be a flight under $300... Go ahead and book it for Riley King, but if everything's too expensive, then just forget the flight and update my driver's license to DL88 instead.
- agent said: [speak] I'll search for flights to Toronto for July 20, book it for Riley King if it's under $300, or update your driver's license to DL88 if everything is too expensive. | [final] I searched for flights to Toronto on July 20 and found flight FL123 for $450, but I did not book it because there were no flights available under $300. I also updated your driver's license number to DL88.
- calls emitted (wire): search_flights(destination='Toronto', date='July 20'); update_identity_doc(doc_type='driver_license', doc_number='DL88')
- calls recorded by the benchmark: search_flights(destination='Toronto', date='July 20'); update_identity_doc(doc_type='driver_license', doc_number='DL88')
- latency: {'input_duration_s': 46.98, 'output_duration_s': 46.98, 'first_speech_s': 20.85}
- kernel: 17 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 2, 'final': 1}; gate holds {}
- decision log: decisions/eval-ac3c55ba.jsonl

## Passing recordings
ecommerce_01, ecommerce_01, ecommerce_02, ecommerce_04, ecommerce_05, ecommerce_06, ecommerce_09, ecommerce_10, ecommerce_11, ecommerce_13, ecommerce_13, ecommerce_14, ecommerce_14, ecommerce_15, ecommerce_15, ecommerce_16, ecommerce_17, ecommerce_18, ecommerce_19, ecommerce_21, ecommerce_21, ecommerce_23, ecommerce_25, finance_01, finance_01, finance_02, finance_03, finance_03, finance_06, finance_07, finance_07, finance_08, finance_08, finance_11, finance_12, finance_12, finance_14, finance_15, finance_17, finance_19, finance_21, finance_22, finance_23, housing_01, housing_02, housing_03, housing_04, housing_05, housing_05, housing_06, housing_08, housing_09, housing_10, housing_14, housing_14, housing_15, housing_17, housing_17, housing_19, housing_20, travel_01, travel_03, travel_03, travel_05, travel_07, travel_07, travel_08, travel_10, travel_11, travel_14, travel_16, travel_18, travel_21, travel_21, travel_23, travel_23, travel_24
