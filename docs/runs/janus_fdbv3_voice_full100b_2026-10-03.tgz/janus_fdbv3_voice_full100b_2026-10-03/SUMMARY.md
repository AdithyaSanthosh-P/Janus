# Janus x FDB-v3 run

- Janus commit: `054c305a6f5de57e50303a4551027fac7ad52e7d`  FDB commit: `3e799c45a045256f47d5f1c9cda90157e2d2ec9e`
- Janus source SHA-256: `5cfb4ddefc6db899`
- Judge: on (FDB --use-llm)
- Scenarios: 100  passed: 65  failed: 35
- Strict pass rate: 0.65
- Recordings re-streamed after FDB's client aborted: none

Provider declaration: custom LiveKit agent (Janus). Decisions by the Janus kernel with gemini-3.6-flash (hosted Gemini API, thinking budget 0, temperature 0); speech: gpt-4o-mini-transcribe-2025-12-15 (hosted OpenAI API) (STT), Kokoro-82M (TTS, local), Silero VAD (local).
