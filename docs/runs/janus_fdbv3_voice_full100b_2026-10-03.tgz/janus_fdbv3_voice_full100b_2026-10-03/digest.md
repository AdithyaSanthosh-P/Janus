# Run digest: 20261003_121822

- Scenarios scored: 100  passed: 65  failed: 35  strict pass rate: 0.65
- Janus commit: `054c305a6f5de57e50303a4551027fac7ad52e7d`  FDB commit: `3e799c45a045256f47d5f1c9cda90157e2d2ec9e`
- Judge: on (FDB --use-llm)
- Tool metrics: {"tool_selection_acc": 0.917, "argument_acc": 0.704, "response_qual": 0.616, "tool_selection_acc_all": 0.908, "argument_acc_all": 0.697, "note": "*_all includes no-response samples (scored 0); default metrics are turn-taken only"}
- Turn-taking: {"total": 100, "turn_taken": 99, "no_response": 1, "turn_take_rate": 0.99}  Latency: {"total_samples": 99, "interruption_count": 0, "interruption_rate": 0.0, "avg_response_latency_s": 9.009, "std_response_latency_s": 4.706, "min_latency_s": 1.84, "max_latency_s": 30.56, "note": "avg/std/min/max exclude interruption samples; computed on turn-taken samples only"}
- by_domain: {"ecommerce_support": 0.724, "finance_billing": 0.88, "housing_location": 0.385, "travel_identity": 0.6}
- by_difficulty: {"easy": 0.722, "medium": 0.706, "hard": 0.5}
- by_num_tools: {"1": 0.697, "2": 0.722, "3": 0.375}
- by_disfluency_feature: {"PAUSE": 0.5, "FILLER": 0.724, "HESITATION": 0.6, "FALSE_START": 0.417, "SELF_CORRECTION": 0.706}
- by_state_rollback: {"with_rollback": 0.706, "without_rollback": 0.639}
- failure_breakdown: {"wrong_tools": 15, "wrong_arguments": 20}
- Recordings re-streamed after a client abort: 0

## Agent log: top errors (de-duplicated)
- 62x ERROR:livekit:livekit::rtc_engine::rtc_session:#:livekit::rtc_engine::rtc_session - publisher data channel '_reliable' closed unexpectedly
- 62x ERROR:livekit:livekit::rtc_engine::rtc_session:#:livekit::rtc_engine::rtc_session - publisher data channel '_lossy' closed unexpectedly
- 60x ERROR:livekit:livekit::rtc_engine::rtc_session:#:livekit::rtc_engine::rtc_session - publisher data channel '_data_track' closed unexpectedly
- 9x httpcore.ReadTimeout
- 9x httpx.ReadTimeout
- 9x openai.APITimeoutError: Request timed out.
- 6x ERROR:janus.voice.speech:janus.voice.speech: transcription attempt # failed

## Failures by guessed cause (35 total)
- wrong_args: 16
- split_turn: 9
- silent: 7
- wrong_tools: 2
- stt: 1

## Failing recordings

### ecommerce_07  [ecommerce_support, easy, FALSE_START]  cause guess: wrong_args: track_order
- reason: Wrong arguments for: ['track_order']
- expected tools: ['track_order']  actual: ['track_order']
- wrong arguments:
    track_order: expected {'order_id': 'FAST99'} got {'order_id': 'FAST999'} (The actual argument 'FAST999' does not match the expected argument 'FAST99'.)
- reference transcript: So, could you? Um, I wanted to search for a new product. Actually, no, never mind, never mind, forget that for now. Could you just track my order instead? Um, the ID is FAST99.
- agent heard (1 turn end(s)): So, could you, I wanted to search for a new product. Actually, no, never mind, never mind. Forget that for now. Could you just track my order instead? The ID is FAST999.
- agent said: [speak] I'll track your order with ID FAST999. | [final] Your order FAST999 is currently out for delivery.
- calls emitted (wire): track_order(order_id='FAST999')
- calls recorded by the benchmark: track_order(order_id='FAST999')
- latency: {'input_duration_s': 50.04, 'output_duration_s': 50.04, 'first_speech_s': 28.8}
- kernel: 11 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-3a5063f8.jsonl
### ecommerce_08  [ecommerce_support, easy, PAUSE]  cause guess: wrong_args: search_products
- reason: Wrong arguments for: ['search_products']
- expected tools: ['search_products']  actual: ['search_products']
- wrong arguments:
    search_products: expected {'query': 'mechanical keyboards', 'max_price': 200} got {'query': 'mechanical keyboard', 'max_price': 200} (The query argument 'mechanical keyboard' does not match the expected 'mechanical keyboards'.)
- reference transcript: Ah, hmm. You know, um, I want a mechanical keyboard and I'm trying, um, to keep my budget under two hundred dollars. Do you have anything like that?
- agent heard (1 turn end(s)): You know, um... I want a mechanical keyboard, and I'm trying to keep my budget under... Two hundred dollars? Do you have anything like that?
- agent said: [speak] I'll search for mechanical keyboards under $200. | [final] I found the mechanical keyboard Premium priced at $190 under product ID PROD1.
- calls emitted (wire): search_products(query='mechanical keyboard', max_price=200)
- calls recorded by the benchmark: search_products(query='mechanical keyboard', max_price=200)
- latency: {'input_duration_s': 45.78, 'output_duration_s': 45.78, 'first_speech_s': 21.75}
- kernel: 15 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-ad5d0220.jsonl
### ecommerce_08  [ecommerce_support, easy, PAUSE]  cause guess: wrong_args: search_products
- reason: Wrong arguments for: ['search_products']
- expected tools: ['search_products']  actual: ['search_products']
- wrong arguments:
    search_products: expected {'query': 'mechanical keyboards', 'max_price': 200} got {'query': 'mechanical keyboard', 'max_price': 200} (The 'query' argument is incorrect. 'mechanical keyboard' is not the same as 'mechanical keyboards'.)
- reference transcript: Um, yeah, you know, uh, I want a mechanical keyboard, and I'm trying to keep my budget under $200. Do you have anything like that?
- agent heard (1 turn end(s)): Um, yeah, you know, uh... I want a mechanical keyboard, and I'm trying to keep my budget under $200. Do you have anything like that?
- agent said: [speak] I'll search for mechanical keyboards under $200. | [final] I searched for mechanical keyboards under 200 dollars and found the mechanical keyboard Premium priced at 190 dollars with product ID PROD1.
- calls emitted (wire): search_products(query='mechanical keyboard', max_price=200)
- calls recorded by the benchmark: search_products(query='mechanical keyboard', max_price=200)
- latency: {'input_duration_s': 43.44, 'output_duration_s': 43.44, 'first_speech_s': 18.8}
- kernel: 18 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {'G10:search_products': 1}
- decision log: decisions/eval-7dbc0875.jsonl
### ecommerce_12  [ecommerce_support, medium, HESITATION,PAUSE]  cause guess: wrong_args: search_products
- reason: Wrong arguments for: ['search_products']
- expected tools: ['search_products']  actual: ['search_products']
- wrong arguments:
    search_products: expected {'query': 'gift', 'category': 'electronics'} got {'query': 'electronics'} (The actual arguments are missing the 'category' argument and the 'query' argument does not match the expected value 'gi…)
- reference transcript: Like, you know, um, I'm thinking something in the let me think electronics section of the grid. He's really into gadgets and text stuff.
- agent heard (1 turn end(s)): Like, you know, I'm thinking of something in the, let me think, electronics section would be great. He's really into gadgets and tech stuff.
- agent said: [speak] I'll search for products in the electronics section.
- calls emitted (wire): search_products(query='electronics')
- calls recorded by the benchmark: search_products(query='electronics')
- latency: {'input_duration_s': 41.264, 'output_duration_s': 41.264, 'first_speech_s': 18.85}
- kernel: 17 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1}; gate holds {'G10:search_products': 1}
- decision log: decisions/eval-439a0b37.jsonl
### ecommerce_14  [ecommerce_support, medium, FILLER]  cause guess: wrong_args: add_to_cart
- reason: Wrong arguments for: ['add_to_cart']
- expected tools: ['add_to_cart']  actual: ['add_to_cart']
- wrong arguments:
    add_to_cart: expected {'product_id': 'P52', 'quantity': 2} got {'product_id': 'vitam. P52', 'quantity': 2} (The actual 'product_id' argument 'vitam. P52' does not match the expected 'product_id' 'P52' and is not a minor formatt…)
- reference transcript: Um well yeah, so um yeah, so I already found what I want. Can you add like two of item uh P52 to my card? I want to get one for myself and one as a gift.
- agent heard (1 turn end(s)): Well... Yeah, so, um... Yeah, so I already found what I want. Can you add, like... to a vitam. P52 to my cart. I wanna get one for myself and one as a gift.
- agent said: [speak] I'll add 2 of the vitam. P52 to your cart. | [final] I have added two units of vitamin P52 to your cart, bringing your total to 199.98.
- calls emitted (wire): add_to_cart(product_id='vitam. P52', quantity=2)
- calls recorded by the benchmark: add_to_cart(product_id='vitam. P52', quantity=2)
- latency: {'input_duration_s': 51.24, 'output_duration_s': 51.24, 'first_speech_s': 27.4}
- kernel: 25 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-b69dc517.jsonl
### ecommerce_20  [ecommerce_support, hard, no disfluency]  cause guess: wrong_tools: missing [] unexpected ['track_order']
- reason: Unexpected tools: ['track_order']
- expected tools: ['search_products', 'add_to_cart']  actual: ['search_products', 'add_to_cart', 'track_order']
- reference transcript: So, you know, so search for a coffee maker first. If you find one that's under $50, go ahead and add two to the cart because they make great gifts. But if everything's over $50, I'd just forget the coffee maker and track order WWW for me instead.
- agent heard (1 turn end(s)): So, you know, I... So search for a coffeemaker first. If you find one that's under $50, go ahead and add two to the cart because they make great gifts. But if everything's over $50, just forget the coffeemaker and track order www for me instead.
- agent said: [speak] I'll search for a coffeemaker, add two to the cart if one is found under $50, or track order www if everything is over $50. | [final] I found the coffeemaker Premium for 99.99, added 2 of them to your cart for a total of 199.98, and checked order www which is currently out for delivery.
- calls emitted (wire): search_products(query='coffeemaker'); add_to_cart(product_id='PROD1', quantity=2); track_order(order_id='www')
- calls recorded by the benchmark: search_products(query='coffeemaker'); add_to_cart(product_id='PROD1', quantity=2); track_order(order_id='www')
- latency: {'input_duration_s': 54.629, 'output_duration_s': 54.629, 'first_speech_s': 33.6}
- kernel: 19 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 3, 'final': 1}; gate holds {}
- decision log: decisions/eval-4330426d.jsonl
### ecommerce_25  [ecommerce_support, hard, FALSE_START]  cause guess: split_turn: the user's request closed 2 turns
- reason: Missing tools: ['track_order']
- expected tools: ['track_order', 'search_products', 'add_to_cart']  actual: ['search_products', 'add_to_cart']
- reference transcript: You know, well, can um I return my never mind, forget the return. Let me focus on what I actually need. Track order C A T for me, then search for cat food because I'm running low and add three of whatever you find to my cart. Everyone's okay, I mean what it means to want to probably pass some sandwiches. What's earth I don't think?
- agent heard (2 turn end(s)): Oh, well, can't... I return my... Never mind, forget the return. Let me focus on what I actually need. Track order CAT for me, then search for cat food because they're running low, and add three of whatever you find to my cart.
- agent said: [speak] Sorry, I didn't quite catch what you'd like me to do — could you say that again? | [speak] I'll search for cat food and add three of whatever I find to your cart. | [final] I searched for cat food and found cat food Premium priced at 99.99 dollars. I then added 3 of them to your cart, bringing your cart total to 299.97 dollars.
- calls emitted (wire): search_products(query='cat food'); add_to_cart(product_id='PROD1', quantity=3)
- calls recorded by the benchmark: search_products(query='cat food'); add_to_cart(product_id='PROD1', quantity=3)
- latency: {'input_duration_s': 49.38, 'output_duration_s': 49.38, 'first_speech_s': 27.35}
- kernel: 17 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 2, 'tool_call': 2, 'final': 1}; gate holds {}
- decision log: decisions/eval-2ad96be4.jsonl
### ecommerce_25  [ecommerce_support, hard, FALSE_START]  cause guess: wrong_args: track_order
- reason: Wrong arguments for: ['track_order']
- expected tools: ['track_order', 'search_products', 'add_to_cart']  actual: ['track_order', 'search_products', 'add_to_cart']
- wrong arguments:
    track_order: expected {'order_id': 'CAT'} got {'order_id': 'ZAT'} (The actual argument 'ZAT' does not match the expected argument 'CAT' for 'order_id'.)
- reference transcript: You know, um, well, can um I return my never mind, uh, forget the return. Let me focus on what I actually need. Track order CAT for me, then search for cat food because I'm running low and add three of whatever you find to my card.
- agent heard (1 turn end(s)): You know, um, well... Can um I return my... Never mind, forget the return. Let me focus on what I actually need. Track order ZAT for me. Then search for cat food because I'm running low. And add three of whatever you find to my cart.
- agent said: [speak] I'll track order ZAT, search for cat food, and add 3 of them to your cart. | [final] Your order ZAT is currently out for delivery. I have found cat food Premium for 99.99 and added 3 of them to your cart, bringing your total to 299.97.
- calls emitted (wire): track_order(order_id='ZAT'); search_products(query='cat food'); add_to_cart(product_id='PROD1', quantity=3)
- calls recorded by the benchmark: track_order(order_id='ZAT'); search_products(query='cat food'); add_to_cart(product_id='PROD1', quantity=3)
- latency: {'input_duration_s': 53.7, 'output_duration_s': 53.7, 'first_speech_s': 29.0}
- kernel: 28 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 3, 'final': 1}; gate holds {}
- decision log: decisions/eval-d5dbe491.jsonl
### finance_07  [finance_billing, easy, FALSE_START]  cause guess: silent: the agent made no calls
- reason: Missing tools: ['modify_autopay']
- expected tools: ['modify_autopay']  actual: []
- reference transcript: Um, I I was gonna ask uh about my account balance, but uh never mind, I'll check online later. But for now, could you change the mortgage auto pay so it pulls from my savings account?
- agent heard (3 turn end(s)): Um, I was gonna ask about my account balance, but... Never mind, I'll check online later. Yep. But for now...
- agent said: [speak] Sorry, I didn't quite catch what you'd like me to do — could you say that again?
- calls emitted (wire): none
- calls recorded by the benchmark: none
- latency: {'input_duration_s': 44.7, 'output_duration_s': 44.7, 'first_speech_s': 39.3}
- kernel: 18 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1}; gate holds {}
- decision log: decisions/eval-aeb2adce.jsonl
### finance_12  [finance_billing, medium, SELF_CORRECTION]  cause guess: split_turn: the user's request closed 3 turns
- reason: Unexpected tools: ['get_exchange_rate']
- expected tools: ['get_exchange_rate']  actual: ['get_exchange_rate', 'get_exchange_rate']
- reference transcript: Well, I want to calculate how much a hundred euros would be in US dollars. Oh, wait, I was looking at the wrong invoice. It's actually 150 euros, not a hundred. So, a hundred and fifty euros to US dollars.
- agent heard (3 turn end(s)): Well, I wanted to calculate how much 100 euros would be in US dollars. Oh, wait. I was like... Looking at the wrong invoice. It's actually 150 euros, not 100, so 150 euros to US dollars.
- agent said: [speak] I'll check the exchange rate for 100 EUR to USD. | [final] The exchange rate for 100 EUR to USD is 1.1, which converts to 110 USD. | [speak] I'll update the amount to 150 euros and convert it to US dollars. | [final] I converted 150 EUR to USD at an exchange rate of 1.1, resulting in 165 USD.
- calls emitted (wire): get_exchange_rate(amount=100, from_currency='EUR', to_currency='USD'); get_exchange_rate(amount=150, from_currency='EUR', to_currency='USD')
- calls recorded by the benchmark: get_exchange_rate(amount=100, from_currency='EUR', to_currency='USD'); get_exchange_rate(amount=150, from_currency='EUR', to_currency='USD')
- latency: {'input_duration_s': 42.9, 'output_duration_s': 42.9, 'first_speech_s': 27.05}
- kernel: 22 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 2, 'tool_call': 2, 'final': 2}; gate holds {'G10:get_exchange_rate': 1}
- decision log: decisions/eval-706cd590.jsonl
### finance_18  [finance_billing, hard, no disfluency]  cause guess: silent: the agent made no calls
- reason: Missing tools: ['get_exchange_rate', 'modify_autopay', 'get_card_benefits']
- expected tools: ['get_exchange_rate', 'modify_autopay', 'get_card_benefits']  actual: []
- reference transcript: Um so alright, so first um I need to know how much thousand US dollars would be in Euros. Then I want to change my credit card or to pay so it pulls from the savings instead. And finally, can you tell me what kind of benefits the premium card has?
- agent heard (0 turn end(s)): 
- agent said: 
- calls emitted (wire): none
- calls recorded by the benchmark: none
- latency: {'input_duration_s': 49.797, 'output_duration_s': 49.797, 'first_speech_s': 49.797}
- kernel: 4 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {}; gate holds {}
- decision log: decisions/eval-35560362.jsonl
### housing_05  [housing_location, easy, HESITATION,PAUSE]  cause guess: wrong_args: search_apartments
- reason: Wrong arguments for: ['search_apartments']
- expected tools: ['search_apartments']  actual: ['search_apartments']
- wrong arguments:
    search_apartments: expected {'city': 'Miami', 'max_price': 1500, 'pets_allowed': True} got {'city': 'Miami', 'bedrooms': 1, 'max_price': 1500} (The 'pets_allowed' argument is missing and 'bedrooms' is an unexpected argument.)
- reference transcript: You know, you know, you know, well, I need um a pet-friendly apartment in Miami, and my budget is about let me check fifteen hundred a month. Is there anything in that range?
- agent heard (1 turn end(s)): Do you know? You know, well, I need, um... a pet-friendly apartment in Miami. And my budget is about, let me check. Fifteen hundred a month. Is there anything in that range?
- agent said: [speak] I'll search for pet-friendly apartments in Miami with a maximum budget of $1500 a month, assuming 1 bedroom. I can't do "filter by pet-friendly" here, though. | [final] I found a one bedroom apartment in Miami, ID APT1, priced at 1400 dollars per month.
- calls emitted (wire): search_apartments(city='Miami', bedrooms=1, max_price=1500)
- calls recorded by the benchmark: search_apartments(city='Miami', bedrooms=1, max_price=1500)
- latency: {'input_duration_s': 48.9, 'output_duration_s': 48.9, 'first_speech_s': 24.95}
- kernel: 21 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {'G10:search_apartments': 1}
- decision log: decisions/eval-30bc713b.jsonl
### housing_05  [housing_location, easy, HESITATION,PAUSE]  cause guess: split_turn: the user's request closed 2 turns
- reason: Wrong arguments for: ['search_apartments']
- expected tools: ['search_apartments']  actual: ['search_apartments']
- wrong arguments:
    search_apartments: expected {'city': 'Miami', 'max_price': 1500, 'pets_allowed': True} got {'city': 'Miami', 'bedrooms': 1, 'max_price': 1500} (The actual arguments are missing 'pets_allowed' and include an unexpected 'bedrooms' argument.)
- reference transcript: You know, um, you know, well, I need um a pet-friendly apartment in Miami, and my budget is about uh let me check. It's uh it's about fifteen hundred a month. Is there anything in that range?
- agent heard (2 turn end(s)): You know... Well, I need a pet-friendly apartment in Miami, and my budget is about, let me check, it's... It's about $1,500 a month. Is there anything in that range? Mhm.
- agent said: [speak] I'll search for pet-friendly apartments in Miami under $1,500 a month, assuming 1 bedroom. | [final] I found a one-bedroom apartment in Miami, ID APT1, priced at $1,400 per month. | [speak] Sorry, I didn't quite catch what you'd like me to do — could you say that again?
- calls emitted (wire): search_apartments(city='Miami', bedrooms=1, max_price=1500)
- calls recorded by the benchmark: search_apartments(city='Miami', bedrooms=1, max_price=1500)
- latency: {'input_duration_s': 50.1, 'output_duration_s': 50.1, 'first_speech_s': 24.6}
- kernel: 25 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 2, 'tool_call': 1, 'final': 1}; gate holds {'G10:search_apartments': 1}
- decision log: decisions/eval-3771584e.jsonl
### housing_08  [housing_location, easy, FALSE_START]  cause guess: wrong_args: update_search_filter
- reason: Wrong arguments for: ['update_search_filter']
- expected tools: ['update_search_filter']  actual: ['update_search_filter']
- wrong arguments:
    update_search_filter: expected {'filter_name': 'pets_allowed', 'value': True} got {'filter_name': 'pets_allowed', 'value': 'true'} (The expected argument for 'value' is a boolean true, but the actual argument is a string 'true'.)
- reference transcript: Okay, so um I want to check the listings in. Actually, before before I do that, could you just update my search filter so that it only shows me places that allow pets? I have a cat.
- agent heard (1 turn end(s)): Okay, so I wanna check listings, and actually, before I do that, could you just update my search filters so that it only shows me places that allow pets? I have a cat.
- agent said: [speak] I'll update your search filter to show places that allow pets. | [final] I have updated your search filter to allow pets.
- calls emitted (wire): update_search_filter(filter_name='pets_allowed', value='true')
- calls recorded by the benchmark: update_search_filter(filter_name='pets_allowed', value='true')
- latency: {'input_duration_s': 45.72, 'output_duration_s': 45.72, 'first_speech_s': 22.55}
- kernel: 11 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-865a4f45.jsonl
### housing_11  [housing_location, medium, SELF_CORRECTION]  cause guess: silent: the agent made no calls
- reason: Missing tools: ['search_apartments']
- expected tools: ['search_apartments']  actual: []
- reference transcript: Uh well, I was thinking a one bedroom under twelve well actually no wait, my partner is moving in with me, so we need a two bedroom and we can go up uh uh up to sixteen hundred a month.
- agent heard (1 turn end(s)): Well, I was thinking a one-bedroom under 1200, actually, no way, my partner is moving in with me, so we need a two-bedroom, and we need to go up to $1,600 a month.
- agent said: [speak] I'll search for two-bedroom apartments with a maximum monthly budget of $1,600. | [clarify] I need a bit more information — what should city be?
- calls emitted (wire): none
- calls recorded by the benchmark: none
- latency: {'input_duration_s': 41.46, 'output_duration_s': 41.46, 'first_speech_s': 21.4}
- kernel: 10 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'clarify': 1}; gate holds {}
- decision log: decisions/eval-9bf5c0d4.jsonl
### housing_13  [housing_location, medium, no disfluency]  cause guess: silent: the agent made no calls
- reason: Missing tools: ['update_search_filter', 'update_search_filter']
- expected tools: ['update_search_filter', 'update_search_filter']  actual: []
- reference transcript: You know, like, you know, let's raise the max price to three thousand per month and also bump up the minimum bedrooms to three. Yeah, I think I need more space than I originally thought.
- agent heard (3 turn end(s)): You know, like, you know... Let's raise the max price to $3,000 per month. And also bump up the minimum bedrooms to three. Yeah, I think I need more space than I originally. Wait on.
- agent said: [speak] I'll search for apartments with at least 3 bedrooms and a maximum price of $3,000 per month. | [clarify] I need a bit more information — what should city be?
- calls emitted (wire): none
- calls recorded by the benchmark: none
- latency: {'input_duration_s': 48.507, 'output_duration_s': 48.507, 'first_speech_s': 26.25}
- kernel: 21 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'clarify': 1}; gate holds {}
- decision log: decisions/eval-e9bb6d08.jsonl
### housing_14  [housing_location, medium, FILLER]  cause guess: split_turn: the user's request closed 2 turns
- reason: Wrong arguments for: ['search_apartments']
- expected tools: ['search_apartments']  actual: ['search_apartments']
- wrong arguments:
    search_apartments: expected {'city': 'Portland', 'bedrooms': 1, 'max_price': 1800, 'pets_allowed': True} got {'city': 'Portland', 'bedrooms': 1, 'max_price': 1800} (The 'pets_allowed' argument is missing in the actual arguments.)
- reference transcript: Like, you know, um, so um, I'm looking for like a one-bedroom apartment in Portland, and I'd want to keep the rent under 1,800. Oh, and it needs to be uh pet-friendly because um I have a dog.
- agent heard (2 turn end(s)): Like, you know, um, so... I'm looking for... Like a one. bedroom apartment in Portland, and I'd want to keep the rent under $1800. Oh, and it needs to be pet-friendly because, um, I have a dog.
- agent said: [speak] I'll search for 1-bedroom apartments in Portland with rent under $1800. I can't do "filter for pet-friendly / dog" here, though. | [final] I found a one bedroom apartment in Portland for $1,700 per month, listing ID APT1.
- calls emitted (wire): search_apartments(city='Portland', bedrooms=1, max_price=1800)
- calls recorded by the benchmark: search_apartments(city='Portland', bedrooms=1, max_price=1800)
- latency: {'input_duration_s': 48.36, 'output_duration_s': 48.36, 'first_speech_s': 29.45}
- kernel: 19 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-63a5413f.jsonl
### housing_14  [housing_location, medium, FILLER]  cause guess: wrong_args: search_apartments
- reason: Wrong arguments for: ['search_apartments']
- expected tools: ['search_apartments']  actual: ['search_apartments']
- wrong arguments:
    search_apartments: expected {'city': 'Portland', 'bedrooms': 1, 'max_price': 1800, 'pets_allowed': True} got {'city': 'Portland', 'bedrooms': 1, 'max_price': 1800} (The 'pets_allowed' argument is missing in the actual arguments.)
- reference transcript: Like, you know, so um, I'm looking for like a one-bedroom apartment in Portland and I'd want to keep the rent under $1,800. Oh, well, and oh, and it needs to be uh pet-friendly because uh I have a dog.
- agent heard (1 turn end(s)): Like, you know, so, um, I'm looking for like a one-bedroom apartment in Portland. And I wanna keep the rent under $1,800, so, well, and it needs to be a pet-friendly because... I have a dog.
- agent said: [speak] I'll search for one-bedroom apartments in Portland under $1,800. I can't do "pet-friendly filter" here, though. | [final] I found a one bedroom apartment in Portland for $1700 per month with the ID APT1.
- calls emitted (wire): search_apartments(city='Portland', bedrooms=1, max_price=1800)
- calls recorded by the benchmark: search_apartments(city='Portland', bedrooms=1, max_price=1800)
- latency: {'input_duration_s': 51.3, 'output_duration_s': 51.3, 'first_speech_s': 31.3}
- kernel: 19 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {'G3:search_apartments': 1}
- decision log: decisions/eval-160b5895.jsonl
### housing_15  [housing_location, medium, FALSE_START]  cause guess: wrong_args: search_apartments
- reason: Wrong arguments for: ['search_apartments']
- expected tools: ['search_apartments']  actual: ['search_apartments']
- wrong arguments:
    search_apartments: expected {'city': 'Atlanta', 'bedrooms': 3, 'pets_allowed': True} got {'city': 'Atlanta', 'bedrooms': 3, 'max_price': 1000000} (The actual arguments are missing 'pets_allowed' and include an unexpected 'max_price' argument.)
- reference transcript: Um so hmm uh I wanted um to check the commute from that one listing. Actually let me skip that for now. Could you just search for a three-bedroom in Atlanta that's pet-friendly? I've got two cats.
- agent heard (1 turn end(s)): I wanted to check the commute from that one listing. Actually, let me skip that for now. Could you just search for a three-bedroom in Atlanta that's pet-friendly? I've got two cats.
- agent said: [speak] I'll search for three-bedroom apartments in Atlanta, assuming a high maximum price. | [final] I found a three-bedroom apartment in Atlanta priced at $999,900 with the ID APT1.
- calls emitted (wire): search_apartments(city='Atlanta', bedrooms=3, max_price=1000000)
- calls recorded by the benchmark: search_apartments(city='Atlanta', bedrooms=3, max_price=1000000)
- latency: {'input_duration_s': 48.42, 'output_duration_s': 48.42, 'first_speech_s': 23.75}
- kernel: 14 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {'G10:search_apartments': 1}
- decision log: decisions/eval-aff30740.jsonl
### housing_15  [housing_location, medium, FALSE_START]  cause guess: silent: the agent made no calls
- reason: Missing tools: ['search_apartments']
- expected tools: ['search_apartments']  actual: []
- reference transcript: Um, so um uh I wanted to I wanted to check the commute from that one listing. Actually, let me skip that for now. Could you just search for a three-bedroom in Atlanta that's pet-friendly? I um I've got two cats too.
- agent heard (2 turn end(s)): I wanted to check the commute from that one listing. Actually, let me skip that for now. Could you just search for a three-bedroom in Atlanta? that's pet-friendly. I've got two cats, too. Mhm. Mhm.
- agent said: [speak] I'll search for three-bedroom apartments in Atlanta, assuming a generous max price since none was specified. I can't do "filter by pet-friendly (cats)" here, though.
- calls emitted (wire): none
- calls recorded by the benchmark: none
- latency: {'input_duration_s': 50.52, 'output_duration_s': 50.52, 'first_speech_s': 31.2}
- kernel: 23 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1}; gate holds {'G3:search_apartments': 8, 'G10:search_apartments': 2}
- decision log: decisions/eval-5f7cd5aa.jsonl
### housing_18  [housing_location, hard, no disfluency]  cause guess: wrong_args: search_apartments
- reason: Wrong arguments for: ['search_apartments']
- expected tools: ['search_apartments', 'calculate_commute']  actual: ['search_apartments', 'calculate_commute']
- wrong arguments:
    search_apartments: expected {'city': 'Portland', 'bedrooms': 1, 'max_price': 1800} got {'city': 'Portland', 'bedrooms': 1, 'max_price': 800} (The 'max_price' argument is outside the acceptable numeric tolerance range of ±5%.)
- reference transcript: Well so first, search for a one-bedroom in Portland that's under $800 per month, then once you find the cheapest option, check how long it would take to bike from there to the coffee shop on 5th Street where I work.
- agent heard (1 turn end(s)): Well, so first, search for a one-bedroom in Portland that's under $800 per month. Then, once you find the cheapest option, check how long it would take to bike from there to the coffee shop on 5th Street where I work.
- agent said: [speak] I'll search for one-bedroom apartments in Portland under $800 per month, and then calculate the biking commute from the cheapest option to the coffee shop on 5th Street. | [final] I found a one bedroom apartment in Portland for $700 per month, ID APT1. The biking commute from APT1 to the coffee shop on 5th Street takes 25 minutes.
- calls emitted (wire): search_apartments(city='Portland', bedrooms=1, max_price=800); calculate_commute(origin_address='APT1', destination_address='the coffee shop on 5th Street', mode='biking')
- calls recorded by the benchmark: search_apartments(city='Portland', bedrooms=1, max_price=800); calculate_commute(origin_address='APT1', destination_address='the coffee shop on 5th Street', mode='biking')
- latency: {'input_duration_s': 47.685, 'output_duration_s': 47.685, 'first_speech_s': 27.3}
- kernel: 14 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 2, 'final': 1}; gate holds {}
- decision log: decisions/eval-2a3ea8fa.jsonl
### housing_20  [housing_location, hard, no disfluency]  cause guess: split_turn: the user's request closed 2 turns
- reason: Missing tools: ['calculate_commute', 'update_search_filter']; Unexpected tools: ['search_apartments']
- expected tools: ['search_apartments', 'calculate_commute', 'update_search_filter']  actual: ['search_apartments', 'search_apartments']
- reference transcript: Uh you know so here's what I'm thinking. Search for places in Austin under 2,000. Then check the commute to my office. If it's under 15 minutes, that's perfect. But if it's longer then raise my budget to 2,500 so uh I can look at places closer to work.
- agent heard (2 turn end(s)): Uh, you know, so here's what I'm thinking. Search for places in Austin under $2000. Then, check the commute to my office. If it's under 15 minutes, that's perfect, but if it's longer, then raise my budget to $2,500 so, uh, I can look at places closer to work.
- agent said: [speak] I'll search for places in Austin under $2000, assuming 1 bedroom. | [clarify] I need a bit more information — what should origin address be?
- calls emitted (wire): search_apartments(city='Austin', bedrooms=1, max_price=2000); search_apartments(city='Austin', bedrooms=1, max_price=2500)
- calls recorded by the benchmark: search_apartments(city='Austin', bedrooms=1, max_price=2000); search_apartments(city='Austin', bedrooms=1, max_price=2500)
- latency: {'input_duration_s': 47.46, 'output_duration_s': 47.46, 'first_speech_s': 24.75}
- kernel: 19 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 2, 'clarify': 1}; gate holds {'G3:search_apartments': 3, 'G10:search_apartments': 2}
- decision log: decisions/eval-808971ec.jsonl
### housing_21  [housing_location, hard, SELF_CORRECTION]  cause guess: silent: the agent made no calls
- reason: Missing tools: ['search_apartments', 'calculate_commute']
- expected tools: ['search_apartments', 'calculate_commute']  actual: []
- reference transcript: So well, so you know I want to search for a place with two bedrooms. Wait, actually, I mean, I meant three bedrooms. We decided we need a home office. Also, check the transit time to the train station. Actually, I'd rather walk, so make that walk-in time.
- agent heard (1 turn end(s)): So, well, so you know, I want to search for a place with two bedrooms. Wait, actually, I mean, I meant three bedrooms. We decided we need a home office. Also check the transit time to the train station. Actually, I'd rather walk, so make that. Walking time.
- agent said: [speak] I'll search for 3-bedroom apartments and calculate the walking commute time to the train station. | [clarify] I need a bit more information — what should city be?
- calls emitted (wire): none
- calls recorded by the benchmark: none
- latency: {'input_duration_s': 49.725, 'output_duration_s': 49.725, 'first_speech_s': 26.05}
- kernel: 14 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'clarify': 1}; gate holds {}
- decision log: decisions/eval-85830b45.jsonl
### housing_22  [housing_location, hard, FILLER]  cause guess: wrong_args: update_search_filter
- reason: Wrong arguments for: ['update_search_filter']
- expected tools: ['update_search_filter', 'search_apartments', 'calculate_commute']  actual: ['update_search_filter', 'search_apartments', 'calculate_commute']
- wrong arguments:
    update_search_filter: expected {'filter_name': 'pets_allowed', 'value': True} got {'filter_name': 'pets_allowed', 'value': 'true'} (The expected argument for 'value' is a boolean true, but the actual argument is a string 'true'.)
- reference transcript: You know, um, can you first update my filter so pets are allowed? Um, I keep forgetting to set that. Then, like, search in Seattle for one bedroom. And then once you find something, uh, check the transit time from there to the stadium because, you know, I go to games pretty often.
- agent heard (1 turn end(s)): Can you first update my filters so pets are allowed? Um, I keep forgetting to set that. Then like search in Seattle for one bedroom. And then once you find something, check the transit time. From there to the stadium, because, you know, I go to games pretty often.
- agent said: [speak] I'll update your filter to allow pets, search for one bedroom apartments in Seattle, and calculate the commute time to the stadium. | [final] I updated your search filter to allow pets and found a 1-bedroom apartment in Seattle priced at $9,900 per month. The commute from APT1 to the stadium by transit takes about 25 minutes.
- calls emitted (wire): update_search_filter(filter_name='pets_allowed', value='true'); search_apartments(city='Seattle', bedrooms=1, max_price=10000); calculate_commute(origin_address='APT1', destination_address='the stadium', mode='transit')
- calls recorded by the benchmark: update_search_filter(filter_name='pets_allowed', value='true'); search_apartments(city='Seattle', bedrooms=1, max_price=10000); calculate_commute(origin_address='APT1', destination_address='the stadium', mode='transit')
- latency: {'input_duration_s': 50.1, 'output_duration_s': 50.1, 'first_speech_s': 24.9}
- kernel: 24 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 3, 'final': 1}; gate holds {}
- decision log: decisions/eval-27720900.jsonl
### housing_24  [housing_location, hard, PAUSE,FILLER]  cause guess: wrong_args: search_apartments
- reason: Wrong arguments for: ['search_apartments', 'calculate_commute']
- expected tools: ['update_search_filter', 'search_apartments', 'calculate_commute']  actual: ['update_search_filter', 'search_apartments', 'calculate_commute']
- wrong arguments:
    search_apartments: expected {'city': 'Dallas'} got {'city': 'Dallas', 'bedrooms': 1, 'max_price': 1500} (The function was called with additional arguments 'bedrooms' and 'max_price' which were not expected.)
    calculate_commute: expected {'origin_address': '$RESULT_1.apartments[0].address', 'destination_address': 'the grocery store', 'mode': 'walking'} got {'origin_address': 'APT1', 'destination_address': 'grocery store', 'mode': 'walking'} (The destination_address 'grocery store' does not match the expected 'the grocery store' due to missing 'the'.)
- reference transcript: Um, so hmm, like, you know, okay. So, first, um, I want to update my max price to $1,500 because I'm on a tighter budget. Then, uh, search for apartments in Dallas that fit that budget, and then check the walking time from whatever you find to the grocery store because I want to be close to one.
- agent heard (1 turn end(s)): Like, you know, okay, so first, um... I want to update my max price to $1500 because I'm on a tighter budget, then search for apartments in Dallas that fit that budget, and then... Check the walking time from whatever you find to the grocery store, because I want to be close to one.
- agent said: [speak] I'll update your max price filter to $1500, search for 1-bedroom apartments in Dallas under $1500, and calculate the walking commute time to the grocery store, assuming 1 bedroom. | [final] I updated your maximum price filter to 1500, found one 1-bedroom apartment in Dallas priced at 1400 dollars, and calculated a 25-minute walking commute to the grocery store.
- calls emitted (wire): update_search_filter(filter_name='max_price', value='1500'); search_apartments(city='Dallas', bedrooms=1, max_price=1500); calculate_commute(origin_address='APT1', destination_address='grocery store', mode='walking')
- calls recorded by the benchmark: update_search_filter(filter_name='max_price', value='1500'); search_apartments(city='Dallas', bedrooms=1, max_price=1500); calculate_commute(origin_address='APT1', destination_address='grocery store', mode='walking')
- latency: {'input_duration_s': 56.1, 'output_duration_s': 56.1, 'first_speech_s': 35.4}
- kernel: 20 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 3, 'final': 1}; gate holds {}
- decision log: decisions/eval-f2e5093f.jsonl
### housing_24  [housing_location, hard, PAUSE,FILLER]  cause guess: wrong_tools: missing ['update_search_filter'] unexpected []
- reason: Missing tools: ['update_search_filter']
- expected tools: ['update_search_filter', 'search_apartments', 'calculate_commute']  actual: ['search_apartments', 'calculate_commute']
- reference transcript: Um so hmm like you know okay so first um I want to update my max price to 1500 because I'm on a tighter budget then uh search for apartments in Dallas that fit that budget and then check the walking time from whatever you find to the grocery store because I want to be close to one
- agent heard (1 turn end(s)): Like, you know, OK. So first, I want to update my max price to $1500. Because I'm on a tighter budget. Then, search for apartments in Dallas that fit that budget. And then... Check the walking time from whatever you find to the grocery store because I wanna be close to one.
- agent said: [speak] I'll search for 1-bedroom apartments in Dallas under $1500, assuming 1 bedroom, and calculate the walking time from the found apartment to the grocery store. | [final] I found a 1-bedroom apartment in Dallas, APT1, for $1,400 per month. The walking commute from APT1 to the grocery store takes 25 minutes.
- calls emitted (wire): search_apartments(city='Dallas', max_price=1500, bedrooms=1); calculate_commute(origin_address='APT1', destination_address='grocery store', mode='walking')
- calls recorded by the benchmark: search_apartments(city='Dallas', max_price=1500, bedrooms=1); calculate_commute(origin_address='APT1', destination_address='grocery store', mode='walking')
- latency: {'input_duration_s': 59.16, 'output_duration_s': 59.16, 'first_speech_s': 36.9}
- kernel: 25 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 2, 'final': 1}; gate holds {}
- decision log: decisions/eval-4d4ab431.jsonl
### housing_25  [housing_location, hard, SELF_CORRECTION]  cause guess: split_turn: the user's request closed 2 turns
- reason: Missing tools: ['search_apartments']
- expected tools: ['update_search_filter', 'update_search_filter', 'search_apartments']  actual: ['update_search_filter', 'update_search_filter']
- reference transcript: You know, you know, alright, first set the filter so pets are allowed and set the max price to 3,000. Then search for places in San Francisco. Wait, actually change the max price to 3500 instead. San Francisco is expensive, so I need more room in the budget.
- agent heard (2 turn end(s)): You know, you know, all right, first set the filters so pets are allowed and set the max price to $3,000. Then search for places in San Francisco. Wait, actually, change the max price to $3,500 instead. San Francisco is expensive, so I need more room in the budget.
- agent said: [speak] I'll update the search filter to allow pets and set the max price filter to $3,000. | [final] I have updated your search filters to allow pets and set the maximum price to 3000.
- calls emitted (wire): update_search_filter(filter_name='pets_allowed', value='true'); update_search_filter(filter_name='max_price', value='3000')
- calls recorded by the benchmark: update_search_filter(filter_name='pets_allowed', value='true'); update_search_filter(filter_name='max_price', value='3000')
- latency: {'input_duration_s': 51.48, 'output_duration_s': 51.48, 'first_speech_s': 26.25}
- kernel: 18 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 2, 'final': 1}; gate holds {'G10:update_search_filter': 1}
- decision log: decisions/eval-42d7051b.jsonl
### travel_02  [travel_identity, easy, no disfluency]  cause guess: stt: the agent heard a different sentence (74% word overlap with the reference transcript)
- reason: Wrong arguments for: ['update_identity_doc']
- expected tools: ['update_identity_doc']  actual: ['update_identity_doc']
- wrong arguments:
    update_identity_doc: expected {'doc_type': 'passport', 'doc_number': 'P9-9-9-90011'} got {'doc_type': 'passport', 'doc_number': 'P88990011'} (The doc_number 'P88990011' does not match the expected format 'P9-9-9-90011' and exceeds the numeric tolerance.)
- reference transcript: Uh, yeah, so my new passport number is P eight eight nine nine zero zero one one. Could you update that in the system for me, please?
- agent heard (1 turn end(s)): Yeah, so my new passport number is P88990011. Could you update that in the system for me, please?
- agent said: [speak] I'll update your identity document with your new passport number P88990011. | [final] Your passport document number has been updated to end in 0011.
- calls emitted (wire): update_identity_doc(doc_type='passport', doc_number='P88990011')
- calls recorded by the benchmark: update_identity_doc(doc_type='passport', doc_number='P88990011')
- latency: {'input_duration_s': 44.52, 'output_duration_s': 44.52, 'first_speech_s': 17.7}
- kernel: 13 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-08474743.jsonl
### travel_07  [travel_identity, easy, no disfluency]  cause guess: split_turn: the user's request closed 4 turns
- reason: Wrong arguments for: ['update_identity_doc']
- expected tools: ['update_identity_doc']  actual: ['update_identity_doc']
- wrong arguments:
    update_identity_doc: expected {'doc_type': 'driver_license', 'doc_number': 'DL555'} got {'doc_type': 'driver_license', 'doc_number': 'F5'} (The actual 'doc_number' argument 'F5' does not match the expected 'DL555' and does not fall within any acceptable toler…)
- reference transcript: Uh, um, the new driver's license number is Dash L dash five dash five dash five. Could you swap out the old one and put this new one in there?
- agent heard (4 turn end(s)): The new driver's license number is D-L-5. Dash five. F-dash-5. Could you swap out the old one and put this new one in there?
- agent said: [speak] I will update your driver's license number to F-dash-5. | [final] Your driver's license number ending in F5 has been successfully updated and confirmed.
- calls emitted (wire): update_identity_doc(doc_type='driver_license', doc_number='F5')
- calls recorded by the benchmark: update_identity_doc(doc_type='driver_license', doc_number='F5')
- latency: {'input_duration_s': 45.0, 'output_duration_s': 45.0, 'first_speech_s': 34.15}
- kernel: 21 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-1ba3706b.jsonl
### travel_07  [travel_identity, easy, no disfluency]  cause guess: wrong_args: update_identity_doc
- reason: Wrong arguments for: ['update_identity_doc']
- expected tools: ['update_identity_doc']  actual: ['update_identity_doc']
- wrong arguments:
    update_identity_doc: expected {'doc_type': 'driver_license', 'doc_number': 'DL555'} got {'doc_type': 'drivers_license', 'doc_number': 'DL555'} (The actual argument 'drivers_license' does not match the expected 'driver_license' due to an extra 's'.)
- reference transcript: Um, the new driver's license number is DL555. Could you swap out the old one and put this new one in there?
- agent heard (1 turn end(s)): The new driver's license number is DL555. Could you swap out the old one and put this new one in there?
- agent said: [speak] I'll update your driver's license number to DL555. | [final] Your driver's license has been successfully updated to the document ending in L555.
- calls emitted (wire): update_identity_doc(doc_type='drivers_license', doc_number='DL555')
- calls recorded by the benchmark: update_identity_doc(doc_type='drivers_license', doc_number='DL555')
- latency: {'input_duration_s': 41.82, 'output_duration_s': 41.82, 'first_speech_s': 16.5}
- kernel: 14 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-856c07be.jsonl
### travel_14  [travel_identity, medium, HESITATION,PAUSE]  cause guess: silent: the agent made no calls
- reason: Missing tools: ['search_flights']
- expected tools: ['search_flights']  actual: []
- reference transcript: Mm, so I want to look at flights to Seoul and the date. Um, I was thinking of it as let me let me think. I'm pretty sure it's March 22nd. Yeah. Yeah, could you search for that?
- agent heard (1 turn end(s)): the dates to so, and the date, um, I was thinking of it is, let me think, I'm pretty sure it's March 22nd. Yeah, yeah, could you search for that?
- agent said: [speak] I'll search for flights on March 22. | [clarify] I need a bit more information — what should destination be?
- calls emitted (wire): none
- calls recorded by the benchmark: none
- latency: {'input_duration_s': 41.541, 'output_duration_s': 41.541, 'first_speech_s': 18.4}
- kernel: 9 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'clarify': 1}; gate holds {}
- decision log: decisions/eval-3cb6229e.jsonl
### travel_19  [travel_identity, hard, SELF_CORRECTION]  cause guess: wrong_args: search_flights
- reason: Wrong arguments for: ['search_flights']
- expected tools: ['search_flights']  actual: ['search_flights']
- wrong arguments:
    search_flights: expected {'destination': 'Milan', 'date': 'June 3'} got {'destination': 'Mulan', 'date': 'June 3'} (The destination argument is incorrect; 'Milan' was expected, but 'Mulan' was provided.)
- reference transcript: Um, okay, I want to look for flights to Rome. No, wait, I changed my mind. Let's do Milan instead. And I was thinking June 1st. Well, wait, but actually, June 3rd works better for me. Sorry about that.
- agent heard (1 turn end(s)): Um, okay, I wanna look for flights to Rome. No way, I changed my mind. Let's do Mulan instead. And I was thinking June 1st. Well, wait, but actually, June 3rd works better for me. Sorry about that.
- agent said: [speak] I'll search for flights to Mulan for June 3rd. | [final] I found a flight to Mulan for June 3rd priced at 450 dollars under flight ID FL123.
- calls emitted (wire): search_flights(destination='Mulan', date='June 3')
- calls recorded by the benchmark: search_flights(destination='Mulan', date='June 3')
- latency: {'input_duration_s': 49.14, 'output_duration_s': 49.14, 'first_speech_s': 23.9}
- kernel: 19 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-9466718b.jsonl
### travel_20  [travel_identity, hard, no disfluency]  cause guess: split_turn: the user's request closed 2 turns
- reason: Unexpected tools: ['update_search_filter']
- expected tools: ['search_flights', 'book_flight', 'update_identity_doc']  actual: ['search_flights', 'update_search_filter', 'book_flight', 'update_identity_doc']
- reference transcript: Here's the thing, I I need to fly to Toronto on July 20th. If there happens to be a flight under $300, go ahead and book it for Riley-Kin. But if everything's too expensive, then just forget the flight and update my driver's license to DL88 instead.
- agent heard (2 turn end(s)): I need to fly to Toronto on July 20th. If the happens to be a flight under $300, go ahead and book it for Riley Kim. But if everything is too expensive, then just forget the flight and update my driver's license to DL88 instead.
- agent said: [speak] I'll search for flights to Toronto on July 20. | [final] I searched for flights to Toronto on July 20 and found flight FL123 for 450 dollars, then updated your maximum price filter to 300 dollars. I also confirmed your flight booking for Riley Kim under reference B789 and updated your driver license to DL88.
- calls emitted (wire): search_flights(destination='Toronto', date='July 20'); update_search_filter(filter_name='max_price', value='300'); book_flight(passenger_name='Riley Kim'); update_identity_doc(doc_type='driver_license', doc_number='DL88')
- calls recorded by the benchmark: search_flights(destination='Toronto', date='July 20'); update_search_filter(filter_name='max_price', value='300'); book_flight(passenger_name='Riley Kim'); update_identity_doc(doc_type='driver_license', doc_number='DL88')
- latency: {'input_duration_s': 46.98, 'output_duration_s': 46.98, 'first_speech_s': 28.8}
- kernel: 20 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 4, 'final': 1}; gate holds {'G3:search_flights': 3, 'G10:search_flights': 1}
- decision log: decisions/eval-fb82c2f8.jsonl
### travel_21  [travel_identity, hard, PAUSE,FILLER]  cause guess: wrong_args: search_flights
- reason: Wrong arguments for: ['search_flights']
- expected tools: ['search_flights', 'book_flight', 'update_identity_doc']  actual: ['search_flights', 'book_flight', 'update_identity_doc']
- wrong arguments:
    search_flights: expected {'destination': 'Las Vegas', 'date': 'August 8'} got {'destination': 'Veigas', 'date': 'August 8'} (The destination 'Veigas' is a misspelling and does not match 'Las Vegas' or its accepted alias 'Vegas'.)
- reference transcript: You know, okay, so um I need to find flights to Vegas. I was thinking around August 8th and then um once you find something book it under the name Quinn Davis oh and uh while you're at it could you please update my visa number to V77
- agent heard (1 turn end(s)): You know... I need to find flights to... Veigas I was thinking around August 8th. And then, um, once you find something, book it under the name Quinn Davis. Oh, and while you're at it, could you please update my visa number to V77?
- agent said: [speak] I'll search for flights to Veigas around August 8, book it under the name Quinn Davis, and update your visa number to V77. | [final] I found flight FL123 to Veigas on August 8 for $450, booked it for Quinn Davis under reference B789, and updated the visa document to V77.
- calls emitted (wire): search_flights(destination='Veigas', date='August 8'); book_flight(passenger_name='Quinn Davis'); update_identity_doc(doc_type='visa', doc_number='V77')
- calls recorded by the benchmark: search_flights(destination='Veigas', date='August 8'); book_flight(passenger_name='Quinn Davis'); update_identity_doc(doc_type='visa', doc_number='V77')
- latency: {'input_duration_s': 53.94, 'output_duration_s': 53.94, 'first_speech_s': 29.35}
- kernel: 26 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 3, 'final': 1}; gate holds {}
- decision log: decisions/eval-fabd8f93.jsonl
### travel_23  [travel_identity, hard, FILLER]  cause guess: split_turn: the user's request closed 2 turns
- reason: Missing tools: ['update_identity_doc']
- expected tools: ['update_identity_doc', 'update_identity_doc']  actual: ['update_identity_doc']
- reference transcript: Hmm. Um, so I need to like update my passport number to P1122 because I just renewed it, and then um, I also got a new driver license. So, could you change that one to D L nine zero nine zero as well?
- agent heard (2 turn end(s)): So I need to, like, update my passport number to P1122. Because I just renewed it. And then, um... I also got a new driver license, so could you change that one to DL9090 as well?
- agent said: [speak] I'll update your passport number to P1122. | [final] I have successfully updated your driver license number ending in 9090.
- calls emitted (wire): update_identity_doc(doc_type='driver_license', doc_number='DL9090')
- calls recorded by the benchmark: update_identity_doc(doc_type='driver_license', doc_number='DL9090')
- latency: {'input_duration_s': 55.32, 'output_duration_s': 55.32, 'first_speech_s': 32.15}
- kernel: 19 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {'G3:update_identity_doc': 3, 'G10:update_identity_doc': 1}
- decision log: decisions/eval-e3d131df.jsonl

## Passing recordings
ecommerce_01, ecommerce_01, ecommerce_02, ecommerce_04, ecommerce_05, ecommerce_06, ecommerce_09, ecommerce_10, ecommerce_11, ecommerce_13, ecommerce_13, ecommerce_14, ecommerce_15, ecommerce_15, ecommerce_16, ecommerce_17, ecommerce_18, ecommerce_19, ecommerce_21, ecommerce_21, ecommerce_23, finance_01, finance_01, finance_02, finance_03, finance_03, finance_04, finance_06, finance_07, finance_08, finance_08, finance_10, finance_11, finance_12, finance_14, finance_15, finance_16, finance_17, finance_19, finance_20, finance_21, finance_22, finance_23, housing_01, housing_02, housing_03, housing_04, housing_06, housing_09, housing_10, housing_17, housing_17, housing_19, travel_01, travel_03, travel_03, travel_05, travel_08, travel_10, travel_11, travel_16, travel_18, travel_21, travel_23, travel_24
