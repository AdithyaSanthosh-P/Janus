# Run digest: 20261025_163419

- Scenarios scored: 100  passed: 81  failed: 19  strict pass rate: 0.81
- Janus commit: `43579bacd254a80e08a1dea76074169c8f0e5e4b`  FDB commit: `3e799c45a045256f47d5f1c9cda90157e2d2ec9e`
- Judge: on (FDB --use-llm)
- Tool metrics: {"tool_selection_acc": 0.95, "argument_acc": 0.86, "response_qual": 0.68, "tool_selection_acc_all": 0.95, "argument_acc_all": 0.86, "note": "*_all includes no-response samples (scored 0); default metrics are turn-taken only"}
- Turn-taking: {"total": 100, "turn_taken": 100, "no_response": 0, "turn_take_rate": 1.0}  Latency: {"total_samples": 100, "interruption_count": 0, "interruption_rate": 0.0, "avg_response_latency_s": 6.194, "std_response_latency_s": 3.874, "min_latency_s": 3.52, "max_latency_s": 26.88, "note": "avg/std/min/max exclude interruption samples; computed on turn-taken samples only"}
- by_domain: {"ecommerce_support": 0.828, "travel_identity": 0.8, "finance_billing": 0.96, "housing_location": 0.654}
- by_difficulty: {"easy": 0.861, "medium": 0.912, "hard": 0.633}
- by_num_tools: {"1": 0.879, "2": 0.722, "3": 0.625}
- by_disfluency_feature: {"FALSE_START": 0.917, "FILLER": 0.897, "HESITATION": 0.9, "SELF_CORRECTION": 0.765, "PAUSE": 0.722}
- by_state_rollback: {"with_rollback": 0.765, "without_rollback": 0.819}
- failure_breakdown: {"wrong_tools": 7, "wrong_arguments": 12}
- Recordings re-streamed after a client abort: 0

## Agent log: top errors (de-duplicated)
- 1702x ERROR:opentelemetry.exporter.otlp.proto.http.trace_exporter:Failed to export span batch code: #, reason: Too Many Requests
- 956x ERROR:opentelemetry.exporter.otlp.proto.http._log_exporter:Failed to export logs batch code: #, reason: Too Many Requests
- 366x ERROR:opentelemetry.exporter.otlp.proto.http.metric_exporter:Failed to export metrics batch code: #, reason: Too Many Requests
- 300x aiohttp.client_exceptions.ClientResponseError: #, message='Too Many Requests', url='https://janus-h#klo#ut.ohyder#.production.livekit.cloud/
- 200x ERROR:livekit.agents:failed to upload the session report to LiveKit Cloud
- 16x ERROR:livekit:livekit::rtc_engine::rtc_session:#:livekit::rtc_engine::rtc_session - publisher data channel '_reliable' closed unexpectedly
- 16x ERROR:livekit:livekit::rtc_engine::rtc_session:#:livekit::rtc_engine::rtc_session - publisher data channel '_lossy' closed unexpectedly
- 16x ERROR:livekit:livekit::rtc_engine::rtc_session:#:livekit::rtc_engine::rtc_session - publisher data channel '_data_track' closed unexpectedly

## Failures by guessed cause (19 total)
- wrong_args: 9
- silent: 4
- wrong_tools: 3
- stt: 2
- split_turn: 1

## Failing recordings

### ecommerce_08  [ecommerce_support, easy, PAUSE]  cause guess: wrong_args: search_products
- reason: Wrong arguments for: ['search_products']
- expected tools: ['search_products']  actual: ['search_products']
- wrong arguments:
    search_products: expected {'query': 'mechanical keyboards', 'max_price': 200} got {'query': 'mechanical keyboard', 'max_price': 200} (The 'query' argument is 'mechanical keyboard' instead of 'mechanical keyboards', which is not a minor formatting differ…)
- reference transcript: Ah, hmm. You know, um, I want a mechanical keyboard and I'm trying, um, to keep my budget under two hundred dollars. Do you have anything like that?
- agent heard (1 turn end(s)): You know, um... I want a mechanical keyboard, and I'm trying um to keep my budget under... Two hundred dollars? Do you have anything like that?
- agent said: [speak] I will search for mechanical keyboards under $200. | [final] I found the mechanical keyboard Premium priced at 190 dollars.
- calls emitted (wire): search_products(query='mechanical keyboard', max_price=200)
- calls recorded by the benchmark: search_products(query='mechanical keyboard', max_price=200)
- latency: {'input_duration_s': 45.78, 'output_duration_s': 45.78, 'first_speech_s': 19.3}
- kernel: 15 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-8dff343c.jsonl
### ecommerce_08  [ecommerce_support, easy, PAUSE]  cause guess: silent: the agent made no calls
- reason: Missing tools: ['search_products']
- expected tools: ['search_products']  actual: []
- reference transcript: Um, yeah, you know, uh, I want a mechanical keyboard, and I'm trying to keep my budget under $200. Do you have anything like that?
- agent heard (1 turn end(s)): Yeah, you know, I want a mechanical keyboard, and I'm trying to keep my budget under $200. Do you have anything like that?
- agent said: [speak] Sorry — "search for mechanical keyboards" isn't something I can do here. I can help with things like search flights, book flight, update identity doc, get card benefits and get exchange rate.
- calls emitted (wire): none
- calls recorded by the benchmark: none
- latency: {'input_duration_s': 43.44, 'output_duration_s': 43.44, 'first_speech_s': 20.65}
- kernel: 11 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1}; gate holds {}
- decision log: decisions/eval-04c4346e.jsonl
### ecommerce_12  [ecommerce_support, medium, HESITATION,PAUSE]  cause guess: split_turn: the user's request closed 2 turns
- reason: Wrong arguments for: ['search_products']
- expected tools: ['search_products']  actual: ['search_products']
- wrong arguments:
    search_products: expected {'query': 'gift', 'category': 'electronics'} got {'query': 'electronics'} (The actual arguments are missing the 'category' argument and the 'query' argument does not match the expected value.)
- reference transcript: Like, you know, um, I'm thinking something in the let me think electronics section of the grid. He's really into gadgets and text stuff.
- agent heard (2 turn end(s)): Like, you know, I'm thinking something in the, let me think, electronics section would be great. He's really into gadgets and tech stuff.
- agent said: [speak] I'll search for products in the electronics section. | [final] I searched for products and found the electronics Premium available for 99.99 with the product ID PROD1.
- calls emitted (wire): search_products(query='electronics')
- calls recorded by the benchmark: search_products(query='electronics')
- latency: {'input_duration_s': 41.264, 'output_duration_s': 41.264, 'first_speech_s': 19.55}
- kernel: 17 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {'G10:search_products': 1}
- decision log: decisions/eval-c3552bca.jsonl
### ecommerce_20  [ecommerce_support, hard, no disfluency]  cause guess: wrong_tools: missing ['add_to_cart'] unexpected ['track_order']
- reason: Missing tools: ['add_to_cart']; Unexpected tools: ['track_order']
- expected tools: ['search_products', 'add_to_cart']  actual: ['search_products', 'track_order']
- reference transcript: So, you know, so search for a coffee maker first. If you find one that's under $50, go ahead and add two to the cart because they make great gifts. But if everything's over $50, I'd just forget the coffee maker and track order WWW for me instead.
- agent heard (1 turn end(s)): So, you know, I... So search for a coffee maker first. If you find one that's under $50, go ahead and add two to the cart because they make great gifts. But if everything's over $50, just forget the coffee maker and track order www for me instead.
- agent said: [speak] I will search for a coffee maker, add two to the cart if one is found under $50, or track order www if everything is over $50. | [final] I searched for a coffee maker and found the coffee maker Premium for $99.99, but I didn't add it to your cart because it wasn't under $50. I also tracked order www, which is currently out for delivery.
- calls emitted (wire): search_products(query='coffee maker'); track_order(order_id='www')
- calls recorded by the benchmark: search_products(query='coffee maker'); track_order(order_id='www')
- latency: {'input_duration_s': 54.629, 'output_duration_s': 54.629, 'first_speech_s': 29.85}
- kernel: 19 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 2, 'final': 1}; gate holds {}
- decision log: decisions/eval-f2f03a4f.jsonl
### ecommerce_25  [ecommerce_support, hard, FALSE_START]  cause guess: wrong_args: track_order
- reason: Wrong arguments for: ['track_order']
- expected tools: ['track_order', 'search_products', 'add_to_cart']  actual: ['track_order', 'search_products', 'add_to_cart']
- wrong arguments:
    track_order: expected {'order_id': 'CAT'} got {'order_id': 'ZAT'} (The actual argument 'order_id' is 'ZAT', which does not match the expected 'CAT'.)
- reference transcript: You know, um, well, can um I return my never mind, uh, forget the return. Let me focus on what I actually need. Track order CAT for me, then search for cat food because I'm running low and add three of whatever you find to my card.
- agent heard (1 turn end(s)): You know, um, well... Can... I return my... Never mind, forget the return. Let me focus on what I actually need. Track order ZAT for me. and search for cat food because I'm running low. and add three of whatever you find to my cart.
- agent said: [speak] I'll track order ZAT, search for cat food, and add 3 of what I find to your cart. | [final] Order ZAT is currently out for delivery. I have also added 3 units of cat food Premium to your cart, bringing your total to 299.97.
- calls emitted (wire): track_order(order_id='ZAT'); search_products(query='cat food'); add_to_cart(product_id='PROD1', quantity=3)
- calls recorded by the benchmark: track_order(order_id='ZAT'); search_products(query='cat food'); add_to_cart(product_id='PROD1', quantity=3)
- latency: {'input_duration_s': 53.7, 'output_duration_s': 53.7, 'first_speech_s': 28.4}
- kernel: 29 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 3, 'final': 1}; gate holds {}
- decision log: decisions/eval-6762714e.jsonl
### finance_20  [finance_billing, hard, no disfluency]  cause guess: wrong_tools: missing ['modify_autopay'] unexpected []
- reason: Missing tools: ['modify_autopay']
- expected tools: ['get_exchange_rate', 'modify_autopay']  actual: ['get_exchange_rate']
- reference transcript: Well, here's my situation. I want to check what 1,000 US dollars is in Euros right now. If the exchange rate looks good to me, then go ahead and change my mortgage auto pay to pull from checking. But if the rate isn't great, just leave everything as is and keep it on the savings.
- agent heard (1 turn end(s)): Well, here's my situation. I wanna check what $1,000 US dollars is in euros right now. If the exchange rate looks good to me, then go ahead and change my mortgage autopay to pull from checking. But if the rate isn't great, just leave everything as is and keep it on the savings.
- agent said: [speak] I'll check the current exchange rate for $1,000 USD to EUR, and if the rate is good, I'll update your mortgage autopay to pull from checking. | [final] The exchange rate from USD to EUR is 0.9, so 1000 USD converts to 900 EUR. I did not update your autopay since you wanted to check the rate first, but let me know if you would like me to modify it now.
- calls emitted (wire): get_exchange_rate(amount=1000, from_currency='USD', to_currency='EUR')
- calls recorded by the benchmark: get_exchange_rate(amount=1000, from_currency='USD', to_currency='EUR')
- latency: {'input_duration_s': 52.576, 'output_duration_s': 52.576, 'first_speech_s': 30.4}
- kernel: 12 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-d6ab2bd0.jsonl
### housing_06  [housing_location, easy, no disfluency]  cause guess: silent: the agent made no calls
- reason: Missing tools: ['calculate_commute']
- expected tools: ['calculate_commute']  actual: []
- reference transcript: So, hmm, I was wondering how long it would take to walk from Oak Street to the gym. I'm trying to figure out if I can walk there in the mornings.
- agent heard (1 turn end(s)): I was wondering how long it would take to walk from Oak Street to the gym. I'm trying to figure out if, um, I can walk there in the mornings.
- agent said: [speak] Sorry — "calculate walking commute time from Oak Street to the gym" isn't something I can do here. I can help with things like search flights, book flight, update identity doc, get card benefits and get exchange rate.
- calls emitted (wire): none
- calls recorded by the benchmark: none
- latency: {'input_duration_s': 44.84, 'output_duration_s': 44.84, 'first_speech_s': 19.25}
- kernel: 8 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1}; gate holds {}
- decision log: decisions/eval-89e5cadd.jsonl
### housing_11  [housing_location, medium, SELF_CORRECTION]  cause guess: silent: the agent made no calls
- reason: Missing tools: ['search_apartments']
- expected tools: ['search_apartments']  actual: []
- reference transcript: Uh well, I was thinking a one bedroom under twelve well actually no wait, my partner is moving in with me, so we need a two bedroom and we can go up uh uh up to sixteen hundred a month.
- agent heard (1 turn end(s)): Well, I was thinking a one-bedroom under 12, well, actually, no, wait, my partner is moving in with me, so we need a two-bedroom, and we need to go up to $1,600 a month.
- agent said: [speak] I'll search for two-bedroom apartments with a maximum price of $1,600 a month. | [clarify] I need a bit more information — what should city be?
- calls emitted (wire): none
- calls recorded by the benchmark: none
- latency: {'input_duration_s': 41.46, 'output_duration_s': 41.46, 'first_speech_s': 14.75}
- kernel: 9 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'clarify': 1}; gate holds {}
- decision log: decisions/eval-0f38b02f.jsonl
### housing_13  [housing_location, medium, no disfluency]  cause guess: wrong_args: update_search_filter
- reason: Wrong arguments for: ['update_search_filter']
- expected tools: ['update_search_filter', 'update_search_filter']  actual: ['update_search_filter', 'update_search_filter']
- wrong arguments:
    update_search_filter: expected {'filter_name': 'min_bedrooms', 'value': 3} got {'filter_name': 'bedrooms', 'value': 3} (The expected argument 'filter_name' is 'min_bedrooms', but the actual argument provided is 'bedrooms'.)
- reference transcript: You know, like, you know, let's raise the max price to three thousand per month and also bump up the minimum bedrooms to three. Yeah, I think I need more space than I originally thought.
- agent heard (1 turn end(s)): You know, like, you know, let's raise the max price to $3,000 per month. And also bump up the minimum bedrooms to three. Mm, yeah, I think I need more space than I originally thought.
- agent said: [speak] I'll update your maximum price filter to $3,000 per month and set the minimum bedrooms filter to 3. | [final] I have updated your search filters to a maximum price of 3000 and three bedrooms.
- calls emitted (wire): update_search_filter(filter_name='max_price', value=3000); update_search_filter(filter_name='bedrooms', value=3)
- calls recorded by the benchmark: update_search_filter(filter_name='max_price', value=3000); update_search_filter(filter_name='bedrooms', value=3)
- latency: {'input_duration_s': 48.507, 'output_duration_s': 48.507, 'first_speech_s': 21.7}
- kernel: 17 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 2, 'final': 1}; gate holds {}
- decision log: decisions/eval-b33e5c6c.jsonl
### housing_18  [housing_location, hard, no disfluency]  cause guess: wrong_args: search_apartments
- reason: Wrong arguments for: ['search_apartments']
- expected tools: ['search_apartments', 'calculate_commute']  actual: ['search_apartments', 'calculate_commute']
- wrong arguments:
    search_apartments: expected {'city': 'Portland', 'bedrooms': 1, 'max_price': 1800} got {'city': 'Portland', 'bedrooms': 1, 'max_price': 800} (The 'max_price' argument is outside the acceptable numeric tolerance. Expected 1800, but got 800, which is not within ±…)
- reference transcript: Well so first, search for a one-bedroom in Portland that's under $800 per month, then once you find the cheapest option, check how long it would take to bike from there to the coffee shop on 5th Street where I work.
- agent heard (1 turn end(s)): Well, so first, search for a one-bedroom in Portland that's under $800 per month. Then, once you find the cheapest option, check how long it would take to bike from there to the coffee shop on 5th Street where I work.
- agent said: [speak] I'll search for a one-bedroom apartment in Portland under $800 per month, and then calculate the biking commute time from the cheapest option to the coffee shop on 5th Street. | [final] I found a one bedroom apartment in Portland for $700 per month with ID APT1. The biking commute from APT1 to the coffee shop on 5th Street takes 25 minutes.
- calls emitted (wire): search_apartments(city='Portland', bedrooms=1, max_price=800); calculate_commute(origin_address='APT1', destination_address='the coffee shop on 5th Street', mode='biking')
- calls recorded by the benchmark: search_apartments(city='Portland', bedrooms=1, max_price=800); calculate_commute(origin_address='APT1', destination_address='the coffee shop on 5th Street', mode='biking')
- latency: {'input_duration_s': 47.685, 'output_duration_s': 47.685, 'first_speech_s': 21.9}
- kernel: 14 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 2, 'final': 1}; gate holds {}
- decision log: decisions/eval-cf7fac37.jsonl
### housing_21  [housing_location, hard, SELF_CORRECTION]  cause guess: silent: the agent made no calls
- reason: Missing tools: ['search_apartments', 'calculate_commute']
- expected tools: ['search_apartments', 'calculate_commute']  actual: []
- reference transcript: So well, so you know I want to search for a place with two bedrooms. Wait, actually, I mean, I meant three bedrooms. We decided we need a home office. Also, check the transit time to the train station. Actually, I'd rather walk, so make that walk-in time.
- agent heard (1 turn end(s)): Well, so you know, I want to search for a place with two bedrooms. Wait, actually, I mean, I meant three bedrooms. We decided we need a home office. Also, check the transit time to the train station. Actually, I'd rather walk, so make that. Walking time.
- agent said: [speak] I'll search for apartments with 3 bedrooms and calculate the walking commute time to the train station. | [clarify] I need a bit more information — what should city be?
- calls emitted (wire): none
- calls recorded by the benchmark: none
- latency: {'input_duration_s': 49.725, 'output_duration_s': 49.725, 'first_speech_s': 24.4}
- kernel: 12 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'clarify': 1}; gate holds {}
- decision log: decisions/eval-f61def2a.jsonl
### housing_22  [housing_location, hard, FILLER]  cause guess: wrong_args: search_apartments
- reason: Wrong arguments for: ['search_apartments', 'calculate_commute']
- expected tools: ['update_search_filter', 'search_apartments', 'calculate_commute']  actual: ['update_search_filter', 'search_apartments', 'calculate_commute']
- wrong arguments:
    search_apartments: expected {'city': 'Seattle', 'bedrooms': 1} got {'city': 'Seattle', 'bedrooms': 1, 'pets_allowed': True} (The actual arguments include an unexpected argument 'pets_allowed' which is not part of the expected arguments.)
    calculate_commute: expected {'origin_address': '$RESULT_1.apartments[0].address', 'destination_address': 'the stadium', 'mode': 'transit'} got {'origin_address': 'APT1', 'destination_address': 'the stadium', 'mode': 'driving'} (The mode of transport is incorrect. Expected 'transit', but got 'driving'.)
- reference transcript: You know, um, can you first update my filter so pets are allowed? Um, I keep forgetting to set that. Then, like, search in Seattle for one bedroom. And then once you find something, uh, check the transit time from there to the stadium because, you know, I go to games pretty often.
- agent heard (1 turn end(s)): You know, um, can you first update my filter so pets are allowed? Um, I keep forgetting to set that. Then, like, search in Seattle for one bedroom. And then once you find something, check the transit time. From there to the stadium, because, you know, I go to games pretty often.
- agent said: [speak] I'll update your filter to allow pets, search for 1 bedroom apartments in Seattle, and calculate the commute time to the stadium for the results. | [final] I updated your filter to allow pets and searched for one-bedroom apartments in Seattle, finding apartment APT1. A driving commute calculation from APT1 to the stadium showed an estimated travel time of 25 minutes.
- calls emitted (wire): update_search_filter(filter_name='pets_allowed', value=True); search_apartments(city='Seattle', bedrooms=1, pets_allowed=True); calculate_commute(origin_address='APT1', destination_address='the stadium')
- calls recorded by the benchmark: update_search_filter(filter_name='pets_allowed', value=True); search_apartments(city='Seattle', bedrooms=1, pets_allowed=True); calculate_commute(origin_address='APT1', destination_address='the stadium', mode='driving')
- latency: {'input_duration_s': 50.1, 'output_duration_s': 50.1, 'first_speech_s': 24.2}
- kernel: 24 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 3, 'final': 1}; gate holds {}
- decision log: decisions/eval-e8ac3bee.jsonl
### housing_24  [housing_location, hard, PAUSE,FILLER]  cause guess: wrong_args: search_apartments
- reason: Wrong arguments for: ['search_apartments']
- expected tools: ['update_search_filter', 'search_apartments', 'calculate_commute']  actual: ['update_search_filter', 'search_apartments', 'calculate_commute']
- wrong arguments:
    search_apartments: expected {'city': 'Dallas'} got {'city': 'Dallas', 'max_price': 1500} (The actual arguments include an extra 'max_price' argument which is not expected.)
- reference transcript: Um, so hmm, like, you know, okay. So, first, um, I want to update my max price to $1,500 because I'm on a tighter budget. Then, uh, search for apartments in Dallas that fit that budget, and then check the walking time from whatever you find to the grocery store because I want to be close to one.
- agent heard (1 turn end(s)): Like, you know. Okay, so first, I want to update my max price to $1500 because I'm on a tighter budget, then search for apartments in Dallas that fit that budget, and then Check the walking time from whatever you find to the grocery store because I want to be close to one.
- agent said: [speak] I'll update your max price filter to $1500, search for apartments in Dallas within that budget, and calculate the walking time from the found apartment to the nearest grocery store. | [final] I updated your maximum price filter to 1500 and found apartment APT1 in Dallas for 1400 dollars per month. The walking commute from APT1 to the grocery store is 25 minutes.
- calls emitted (wire): update_search_filter(filter_name='max_price', value=1500); search_apartments(city='Dallas', max_price=1500); calculate_commute(origin_address='APT1', destination_address='grocery store', mode='walking')
- calls recorded by the benchmark: update_search_filter(filter_name='max_price', value=1500); search_apartments(city='Dallas', max_price=1500); calculate_commute(origin_address='APT1', destination_address='grocery store', mode='walking')
- latency: {'input_duration_s': 56.1, 'output_duration_s': 56.1, 'first_speech_s': 31.25}
- kernel: 22 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 3, 'final': 1}; gate holds {}
- decision log: decisions/eval-f6fccc92.jsonl
### housing_24  [housing_location, hard, PAUSE,FILLER]  cause guess: wrong_args: search_apartments
- reason: Wrong arguments for: ['search_apartments']
- expected tools: ['update_search_filter', 'search_apartments', 'calculate_commute']  actual: ['update_search_filter', 'search_apartments', 'calculate_commute']
- wrong arguments:
    search_apartments: expected {'city': 'Dallas'} got {'city': 'Dallas', 'max_price': 1500} (The actual arguments include an extra argument 'max_price' which is not expected.)
- reference transcript: Um so hmm like you know okay so first um I want to update my max price to 1500 because I'm on a tighter budget then uh search for apartments in Dallas that fit that budget and then check the walking time from whatever you find to the grocery store because I want to be close to one
- agent heard (1 turn end(s)): Like, you know, OK. So first, I want to update my max price to $1500. Because I'm on a tighter budget. Then, search for apartments in Dallas that fit that budget. And then... Check the walking time from whatever you find to the grocery store because I wanna be close to one.
- agent said: [speak] I will update your max price filter to $1500, search for apartments in Dallas within that budget, and calculate the walking time to the grocery store. | [final] I updated your maximum price filter to 1500 and found apartment APT1 in Dallas for 1400 dollars per month. The walking commute from APT1 to the grocery store is calculated at 25 minutes.
- calls emitted (wire): update_search_filter(filter_name='max_price', value=1500); search_apartments(city='Dallas', max_price=1500); calculate_commute(origin_address='APT1', destination_address='grocery store', mode='walking')
- calls recorded by the benchmark: update_search_filter(filter_name='max_price', value=1500); search_apartments(city='Dallas', max_price=1500); calculate_commute(origin_address='APT1', destination_address='grocery store', mode='walking')
- latency: {'input_duration_s': 59.16, 'output_duration_s': 59.16, 'first_speech_s': 33.8}
- kernel: 28 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 3, 'final': 1}; gate holds {}
- decision log: decisions/eval-31649cd6.jsonl
### housing_25  [housing_location, hard, SELF_CORRECTION]  cause guess: wrong_args: search_apartments
- reason: Wrong arguments for: ['search_apartments']
- expected tools: ['update_search_filter', 'update_search_filter', 'search_apartments']  actual: ['update_search_filter', 'update_search_filter', 'search_apartments']
- wrong arguments:
    search_apartments: expected {'city': 'San Francisco'} got {'city': 'San Francisco', 'pets_allowed': True, 'max_price': 3500} (The actual arguments include 'pets_allowed' and 'max_price', which are not expected.)
- reference transcript: You know, you know, alright, first set the filter so pets are allowed and set the max price to 3,000. Then search for places in San Francisco. Wait, actually change the max price to 3500 instead. San Francisco is expensive, so I need more room in the budget.
- agent heard (1 turn end(s)): You know, you know, all right, first set the filter so pets are allowed, and set the max price to $3,000. Then search for places in San Francisco. Wait, actually, change the max price to $3,500 instead. San Francisco is expensive, so I need more room in the budget.
- agent said: [speak] I'll set the filter to allow pets, update the max price filter to $3,500, and search for apartments in San Francisco. | [final] I updated your filters to allow pets and set the maximum price to $3500. I found one apartment in San Francisco matching your criteria, property ID APT1 for $3400 per month.
- calls emitted (wire): update_search_filter(filter_name='pets_allowed', value=True); update_search_filter(filter_name='max_price', value=3500); search_apartments(city='San Francisco', pets_allowed=True, max_price=3500)
- calls recorded by the benchmark: update_search_filter(filter_name='pets_allowed', value=True); update_search_filter(filter_name='max_price', value=3500); search_apartments(city='San Francisco', pets_allowed=True, max_price=3500)
- latency: {'input_duration_s': 51.48, 'output_duration_s': 51.48, 'first_speech_s': 25.15}
- kernel: 17 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 3, 'final': 1}; gate holds {}
- decision log: decisions/eval-9b02d277.jsonl
### travel_02  [travel_identity, easy, no disfluency]  cause guess: stt: the agent heard a different sentence (78% word overlap with the reference transcript)
- reason: Wrong arguments for: ['update_identity_doc']
- expected tools: ['update_identity_doc']  actual: ['update_identity_doc']
- wrong arguments:
    update_identity_doc: expected {'doc_type': 'passport', 'doc_number': 'P9-9-9-90011'} got {'doc_type': 'passport', 'doc_number': 'P88990011'} (The doc_number 'P88990011' does not match the expected format 'P9-9-9-90011' and is not within a minor formatting diffe…)
- reference transcript: Uh, yeah, so my new passport number is P eight eight nine nine zero zero one one. Could you update that in the system for me, please?
- agent heard (1 turn end(s)): Uh, yeah, so my new passport number is P88990011. Could you update that in the system for me, please?
- agent said: [speak] I will update your passport number to P88990011 in the system. | [final] Your passport identity document has been updated to end in 0011.
- calls emitted (wire): update_identity_doc(doc_type='passport', doc_number='P88990011')
- calls recorded by the benchmark: update_identity_doc(doc_type='passport', doc_number='P88990011')
- latency: {'input_duration_s': 44.52, 'output_duration_s': 44.52, 'first_speech_s': 17.85}
- kernel: 12 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-de742519.jsonl
### travel_07  [travel_identity, easy, no disfluency]  cause guess: stt: the agent heard a different sentence (78% word overlap with the reference transcript)
- reason: Wrong arguments for: ['update_identity_doc']
- expected tools: ['update_identity_doc']  actual: ['update_identity_doc']
- wrong arguments:
    update_identity_doc: expected {'doc_type': 'driver_license', 'doc_number': 'DL555'} got {'doc_type': 'driver_license', 'doc_number': 'DLL555'} (The doc_number 'DL555' does not match 'DLL555' due to an extra 'L'.)
- reference transcript: Uh, um, the new driver's license number is Dash L dash five dash five dash five. Could you swap out the old one and put this new one in there?
- agent heard (1 turn end(s)): The new driver's license number is D-LL-5-5-5. Could you swap out the old one and put this new one in there?
- agent said: [speak] I'll update your driver's license number to D-LL-5-5-5. | [final] Your driver's license has been successfully updated to the document ending in L555.
- calls emitted (wire): update_identity_doc(doc_type='driver_license', doc_number='DLL555')
- calls recorded by the benchmark: update_identity_doc(doc_type='driver_license', doc_number='DLL555')
- latency: {'input_duration_s': 45.0, 'output_duration_s': 45.0, 'first_speech_s': 19.1}
- kernel: 11 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-328aa6b6.jsonl
### travel_19  [travel_identity, hard, SELF_CORRECTION]  cause guess: wrong_args: search_flights
- reason: Wrong arguments for: ['search_flights']
- expected tools: ['search_flights']  actual: ['search_flights']
- wrong arguments:
    search_flights: expected {'destination': 'Milan', 'date': 'June 3'} got {'destination': 'Mulan', 'date': 'June 3'} (The destination argument is incorrect; 'Mulan' is not a valid alias or abbreviation for 'Milan'.)
- reference transcript: Um, okay, I want to look for flights to Rome. No, wait, I changed my mind. Let's do Milan instead. And I was thinking June 1st. Well, wait, but actually, June 3rd works better for me. Sorry about that.
- agent heard (1 turn end(s)): Um, okay, I wanna look for flights to Rome. No, wait, I changed my mind. Let's do Mulan instead. And I was thinking June 1st. Well, wait, but actually, June 3rd works better for me. Sorry about that.
- agent said: [speak] I'll search for flights to Mulan for June 3rd. | [final] I found a flight to Mulan on June 3 for 450 dollars, flight ID FL123.
- calls emitted (wire): search_flights(destination='Mulan', date='June 3')
- calls recorded by the benchmark: search_flights(destination='Mulan', date='June 3')
- latency: {'input_duration_s': 49.14, 'output_duration_s': 49.14, 'first_speech_s': 22.2}
- kernel: 20 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 1, 'final': 1}; gate holds {}
- decision log: decisions/eval-4a9eab88.jsonl
### travel_20  [travel_identity, hard, no disfluency]  cause guess: wrong_tools: missing ['book_flight'] unexpected []
- reason: Missing tools: ['book_flight']
- expected tools: ['search_flights', 'book_flight', 'update_identity_doc']  actual: ['search_flights', 'update_identity_doc']
- reference transcript: Here's the thing, I I need to fly to Toronto on July 20th. If there happens to be a flight under $300, go ahead and book it for Riley-Kin. But if everything's too expensive, then just forget the flight and update my driver's license to DL88 instead.
- agent heard (1 turn end(s)): Here's the thing, I need to fly to Toronto on July 20th. If there happens to be a flight under $300, go ahead and book it for Riley King, but if everything's too expensive, then just forget the flight and update my driver's license to DL88 instead.
- agent said: [speak] I'll search for flights to Toronto on July 20th. If there is a flight under $300, I'll book it for Riley King; otherwise, I'll update your driver's license to DL88. | [final] I searched for flights to Toronto on July 20th and found flight FL123 for $450, but I didn't book it because it was not under $300. I also updated your driver's license number to DL88.
- calls emitted (wire): search_flights(destination='Toronto', date='July 20'); update_identity_doc(doc_type='driver_license', doc_number='DL88')
- calls recorded by the benchmark: search_flights(destination='Toronto', date='July 20'); update_identity_doc(doc_type='driver_license', doc_number='DL88')
- latency: {'input_duration_s': 46.98, 'output_duration_s': 46.98, 'first_speech_s': 24.8}
- kernel: 16 kernel steps, 0 step errors, 0 calls invalidated, 0 discarded; emitted {'speak': 1, 'tool_call': 2, 'final': 1}; gate holds {'G10:search_flights': 1}
- decision log: decisions/eval-59d4c852.jsonl

## Passing recordings
ecommerce_01, ecommerce_01, ecommerce_02, ecommerce_04, ecommerce_05, ecommerce_06, ecommerce_07, ecommerce_09, ecommerce_10, ecommerce_11, ecommerce_13, ecommerce_13, ecommerce_14, ecommerce_14, ecommerce_15, ecommerce_15, ecommerce_16, ecommerce_17, ecommerce_18, ecommerce_19, ecommerce_21, ecommerce_21, ecommerce_23, ecommerce_25, finance_01, finance_01, finance_02, finance_03, finance_03, finance_04, finance_06, finance_07, finance_07, finance_08, finance_08, finance_10, finance_11, finance_12, finance_12, finance_14, finance_15, finance_16, finance_17, finance_18, finance_19, finance_21, finance_22, finance_23, housing_01, housing_02, housing_03, housing_04, housing_05, housing_05, housing_08, housing_09, housing_10, housing_14, housing_14, housing_15, housing_15, housing_17, housing_17, housing_19, housing_20, travel_01, travel_03, travel_03, travel_05, travel_07, travel_08, travel_10, travel_11, travel_14, travel_16, travel_18, travel_21, travel_21, travel_23, travel_23, travel_24
