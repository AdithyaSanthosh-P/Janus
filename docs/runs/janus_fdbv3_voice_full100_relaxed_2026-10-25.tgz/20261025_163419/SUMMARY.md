# Janus x FDB-v3 run

- Janus commit: `43579bacd254a80e08a1dea76074169c8f0e5e4b`  FDB commit: `3e799c45a045256f47d5f1c9cda90157e2d2ec9e`
- Janus source SHA-256: `f2523f8b239ae599`
- Judge: on (FDB --use-llm)
- Scenarios: 100  passed: 81  failed: 19
- Strict pass rate: 0.81
- Recordings re-streamed after FDB's client aborted: none

Provider declaration: custom LiveKit agent (Janus). Decisions by the Janus kernel with gemini-3.6-flash (hosted Gemini API, thinking budget 0, temperature 0); speech: gpt-4o-mini-transcribe-2025-12-15 (hosted OpenAI API) (STT), Kokoro-82M (TTS, local), Silero VAD (local).
