# Run digest: 20261019_091753

- Scenarios scored: 4  passed: 4  failed: 0  strict pass rate: 1.0
- Janus commit: `f911a194d5899633830f84cfc3751eaaa5487b82`  FDB commit: `3e799c45a045256f47d5f1c9cda90157e2d2ec9e`
- Judge: on (FDB --use-llm)
- Tool metrics: {"tool_selection_acc": 1.0, "argument_acc": 1.0, "response_qual": 1.0, "tool_selection_acc_all": 1.0, "argument_acc_all": 1.0, "note": "*_all includes no-response samples (scored 0); default metrics are turn-taken only"}
- Turn-taking: {"total": 4, "turn_taken": 4, "no_response": 0, "turn_take_rate": 1.0}  Latency: {"total_samples": 4, "interruption_count": 0, "interruption_rate": 0.0, "avg_response_latency_s": 6.16, "std_response_latency_s": 1.01, "min_latency_s": 5.12, "max_latency_s": 7.28, "note": "avg/std/min/max exclude interruption samples; computed on turn-taken samples only"}
- by_domain: {"ecommerce_support": 1.0, "housing_location": 1.0}
- by_difficulty: {"easy": 1.0}
- by_num_tools: {"1": 1.0}
- by_disfluency_feature: {"HESITATION": 1.0, "PAUSE": 1.0}
- by_state_rollback: {"with_rollback": null, "without_rollback": 1.0}
- failure_breakdown: {"wrong_tools": 0, "wrong_arguments": 0}
- Recordings re-streamed after a client abort: 0

## Agent log: top errors (de-duplicated)
- 2x ERROR:livekit:livekit::rtc_engine::rtc_session:#:livekit::rtc_engine::rtc_session - publisher data channel '_reliable' closed unexpectedly
- 2x ERROR:livekit:livekit::rtc_engine::rtc_session:#:livekit::rtc_engine::rtc_session - publisher data channel '_lossy' closed unexpectedly
- 2x ERROR:livekit:livekit::rtc_engine::rtc_session:#:livekit::rtc_engine::rtc_session - publisher data channel '_data_track' closed unexpectedly

## Failures by guessed cause (0 total)

## Failing recordings


## Passing recordings
ecommerce_01, ecommerce_01, housing_05, housing_05
